-- ModKeys: one shared keybind list for our UE4SS Lua mods, edited in game with the F4 menu (ModKeybinds mod).
-- File: Mods\ModKeybinds\keybinds.txt, one line per action:  Mod.action = Key ; Mod name ; Action
-- Each mod registers its actions at load (missing lines are appended with the default key) and re-reads the
-- file every second, so a rebind applies without a restart.
-- Threading: RegisterKeyBind callbacks run off the game thread, so they only read a pre-filled table
-- (no keys are ever added to it after load) and queue the real work with ExecuteInGameThread.
local M = {}
M.FILE = "ue4ss/Mods/ModKeybinds/keybinds.txt"

-- bindable keys: label (shown + stored), UE4SS Key name, Unreal FKey name (for IsInputKeyDown)
local KEYS, BY = {}, {}
local function add(label, uk, fk)
    if Key and Key[uk] ~= nil then
        local k = { label = label, uk = uk, fk = fk or label }
        KEYS[#KEYS + 1] = k; BY[label] = k
    end
end
for i = 1, 12 do add("F" .. i, "F" .. i) end
for c in ("ABCDEFGHIJKLMNOPQRSTUVWXYZ"):gmatch(".") do add(c, c) end
local WN = { "ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE" }
local FN = { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine" }
for i = 0, 9 do add(tostring(i), WN[i + 1], FN[i + 1]) end
for i = 0, 9 do add("Num" .. i, "NUM_" .. WN[i + 1], "NumPad" .. FN[i + 1]) end
for _, t in ipairs({ { "CapsLock", "CAPS_LOCK" }, { "Tab", "TAB" }, { "Insert", "INS" }, { "Delete", "DEL" },
    { "Home", "HOME" }, { "End", "END" }, { "PageUp", "PAGE_UP" }, { "PageDown", "PAGE_DOWN" },
    { "Tilde", "OEM_THREE" }, { "Mouse4", "XBUTTON_ONE", "ThumbMouseButton" },
    { "Mouse5", "XBUTTON_TWO", "ThumbMouseButton2" } }) do add(t[1], t[2], t[3]) end
-- Shift / Ctrl / Alt on their own. This UE4SS build's Key table has no entry for them (only ModifierKey
-- SHIFT/CONTROL/ALT), so they are bound by their Windows key code (VK_SHIFT 0x10, VK_CONTROL 0x11,
-- VK_MENU 0x12; left and right count as the same key). `mod` = their ModifierKey, see hookKeys.
-- fk = Unreal key polled by hold actions (left key only).
local function addMod(label, vk, fk, mod)
    local k = { label = label, uk = vk, fk = fk, mod = mod }
    KEYS[#KEYS + 1] = k; BY[label] = k
end
if Key then
    addMod("Shift", 0x10, "LeftShift", "SHIFT")
    addMod("Ctrl", 0x11, "LeftControl", "CONTROL")
    addMod("Alt", 0x12, "LeftAlt", "ALT")
end
M.KEYS, M.BY = KEYS, BY

local binds, order = {}, {}   -- id -> { id, key, mod, label }; order = file order
local handlers = {}           -- id -> fn (press actions of this mod)
local active = {}             -- key label -> bool; read off-thread, so pre-filled and never grown
for _, k in ipairs(KEYS) do active[k.label] = false end
M.capture = nil               -- set by the F4 menu while it waits for a key: fn(label) gets the next press

local function log(fmt, ...) print("[ModKeys] " .. string.format(fmt, ...) .. "\n") end

local lastText = nil
function M.read()
    local f = io.open(M.FILE, "r")
    if not f then return order end
    local text = f:read("a")
    f:close()
    if text == lastText then return order end   -- unchanged since the last read (the usual case)
    local list, seen = {}, {}
    for line in text:gmatch("[^\n]+") do
        local id, key, mod, label = line:match("^%s*([%w_]+%.[%w_]+)%s*=%s*([^;]-)%s*;%s*([^;]-)%s*;%s*(.-)%s*$")
        if id and not seen[id] then
            seen[id] = true
            local e = binds[id] or {}
            e.id, e.key, e.mod, e.label = id, key, mod, label
            binds[id] = e; list[#list + 1] = e
        end
    end
    if #list > 0 then order = list; lastText = text end   -- empty = file mid-rewrite: keep what we had
    return order
end

function M.write(list)
    local tmp = M.FILE .. ".tmp"
    local f = io.open(tmp, "w")
    if not f then return false end
    f:write("# Mod keybinds - change them in game with F4.  Mod.action = Key ; Mod ; Action\n")
    for _, e in ipairs(list) do f:write(string.format("%s = %s ; %s ; %s\n", e.id, e.key, e.mod, e.label)) end
    f:close()
    os.remove(M.FILE)
    return os.rename(tmp, M.FILE) and true or false
end

local function refreshActive()
    local want = {}
    for id in pairs(handlers) do local e = binds[id]; if e then want[e.key] = true end end
    for l in pairs(active) do active[l] = want[l] == true end
end

-- Add an action (no-op if the file already has it). Returns its entry.
function M.register(id, mod, label, default)
    M.read()
    if not binds[id] then
        local e = { id = id, key = default, mod = mod, label = label }
        binds[id] = e; order[#order + 1] = e
        local f = io.open(M.FILE, "a")
        if f then f:write(string.format("%s = %s ; %s ; %s\n", id, default, mod, label)); f:close() end
    end
    return binds[id]
end

function M.key(id) local e = binds[id]; return e and e.key end
function M.fkey(id) local k = BY[M.key(id) or ""]; return k and k.fk end

-- While the F4 menu is open it owns the controls: only its own toggle runs. Each mod has its own Lua
-- state, so the menu signals "open" with a flag file (checked only when a bound key is pressed).
M.MENU_FLAG = "ue4ss/Mods/ModKeybinds/menu_open.flag"
function M.menuOpen()
    local f = io.open(M.MENU_FLAG, "r")
    if f then f:close(); return true end
    return false
end

local lastAt = {}   -- a modifier key is registered twice (see hookKeys): ignore the echo
local function press(label)
    local now = os.clock()
    if lastAt[label] and now - lastAt[label] < 0.15 then return end
    lastAt[label] = now
    if M.capture then local c = M.capture; M.capture = nil; local ok, err = pcall(c, label); if not ok then log("capture: %s", tostring(err)) end return end
    local blocked = M.menuOpen()
    for id, fn in pairs(handlers) do
        local e = binds[id]
        if e and e.key == label and not (blocked and id ~= "ModKeybinds.open") then
            local ok, err = pcall(fn)
            if not ok then log("%s: %s", id, tostring(err)) end
        end
    end
end

local looping, hooked = false, false
local function watch()   -- re-read the file every second
    if looping then return end
    looping = true
    LoopInGameThreadWithDelay(1000, function() pcall(M.read); refreshActive() end)
end
local function hookKeys()
    if hooked then return end
    hooked = true
    for _, k in ipairs(KEYS) do
        local label = k.label
        local cb = function()
            if active[label] or M.capture then ExecuteInGameThread(function() press(label) end) end
        end
        local kv = type(k.uk) == "number" and k.uk or Key[k.uk]
        local ok, err = pcall(RegisterKeyBind, kv, cb)
        if not ok then log("could not bind %s: %s", label, tostring(err)) end
        -- UE4SS may skip a plain bind while a modifier is held, and Shift itself is one: also bind it with its own modifier
        if k.mod and ModifierKey and ModifierKey[k.mod] ~= nil then
            ok, err = pcall(RegisterKeyBind, kv, { ModifierKey[k.mod] }, cb)
            if not ok then log("could not bind %s+%s: %s", label, k.mod, tostring(err)) end
        end
    end
end

-- Press action: fn runs on the game thread when the bound key is pressed.
function M.bind(id, mod, label, default, fn)
    M.register(id, mod, label, default)
    handlers[id] = fn
    hookKeys(); watch()
    refreshActive()
end

-- Hold actions (polled with IsInputKeyDown): M.register + M.watch, then read M.fkey(id) each poll.
M.watch = watch
-- The F4 menu: get every key press (for M.capture) without binding anything.
function M.listen() hookKeys(); watch() end

return M
