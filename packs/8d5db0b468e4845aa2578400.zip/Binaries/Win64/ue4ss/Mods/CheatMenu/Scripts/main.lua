-- CheatMenu: F1 cheat menu built from Abiotic Factor's own UI widgets.
--   Unlimited Health   -> player's built-in Invincible flag
--   Unlimited Stamina  -> player's built-in InfiniteStamina flag
--   Drop Rate 1x-10x   -> repeats DropLoot calls (approach from ResourceMultiplier by PieKing1215, MIT)
-- Cheats apply on the host / in single player.

local MOD = "[CheatMenu] "
-- UE4SS's working directory is Binaries\Win64, so paths are relative to that
local SETTINGS_FILE = "ue4ss/Mods/CheatMenu/settings.txt"
local DEBUG_OPEN_ON_START = false   -- dev only: open the menu automatically at startup
local DEBUG_KEYS = false            -- dev only: F2 forces garbage collection

local function log(fmt, ...) print(MOD .. string.format(fmt, ...) .. "\n") end

local function valid(o) return o ~= nil and o.IsValid ~= nil and o:IsValid() end

-- ---------------------------------------------------------------- settings
-- Layout values can be edited in settings.txt (restart the game to apply):
--   menuscale  = size multiplier for the whole menu (0.5 = half size)
--   menux/menuy = distance from the top-left corner of the screen, in pixels
--   maxheight  = tallest the cheat list may get (unscaled px) before it scrolls; 0 = no limit
local settings = { health = false, stamina = false, droprate = 1.0,
                   menuscale = 0.5, menux = 16, menuy = 16, maxheight = 600 }

local function num(v, lo, hi, default)
    local n = tonumber(v)
    if not n then return default end
    return math.max(lo, math.min(hi, n))
end

local function loadSettings()
    local f = io.open(SETTINGS_FILE, "r")
    if not f then return end
    for line in f:lines() do
        local k, v = line:match("^%s*(%w+)%s*=%s*(%S+)")
        if k == "health" or k == "stamina" then settings[k] = (v == "true")
        elseif k == "droprate" then settings.droprate = num(v, 1, 10, 1)
        elseif k == "menuscale" then settings.menuscale = num(v, 0.2, 2, 0.5)
        elseif k == "menux" then settings.menux = num(v, 0, 4000, 16)
        elseif k == "menuy" then settings.menuy = num(v, 0, 4000, 16)
        elseif k == "maxheight" then settings.maxheight = num(v, 0, 4000, 600) end
    end
    f:close()
end

local function saveSettings()
    local f = io.open(SETTINGS_FILE, "w")
    if not f then log("could not write %s", SETTINGS_FILE); return end
    f:write(string.format(
        "health=%s\nstamina=%s\ndroprate=%.2f\nmenuscale=%.2f\nmenux=%d\nmenuy=%d\nmaxheight=%d\n",
        tostring(settings.health), tostring(settings.stamina), settings.droprate,
        settings.menuscale, settings.menux, settings.menuy, settings.maxheight))
    f:close()
end

loadSettings()

-- ---------------------------------------------------------------- helpers
local function getPC()
    local pcs = FindAllOf("PlayerController")
    if not pcs then return nil end
    for _, pc in ipairs(pcs) do
        if valid(pc) and pc:IsLocalController() then return pc end
    end
    return nil
end

local function getPawn()
    local pc = getPC()
    if not valid(pc) then return nil end
    local pawn = pc.Pawn
    if valid(pawn) then return pawn end
    return nil
end

local classCache = {}
local function cls(path)
    local c = classCache[path]
    if valid(c) then return c end
    c = StaticFindObject(path)
    if not valid(c) then
        pcall(LoadAsset, path)
        c = StaticFindObject(path)
    end
    classCache[path] = c
    return c
end

local WBL_PATH = "/Script/UMG.Default__WidgetBlueprintLibrary"
local function wbl() return StaticFindObject(WBL_PATH) end

-- ---------------------------------------------------------------- cheats
local function applyPlayerCheats()
    local pawn = getPawn()
    if not pawn then return end
    -- only touch our own flags when we are the ones who turned them on, so the game's
    -- own cheat menu (or other mods) still work when ours is off
    if settings.health then pawn.Invincible = true end
    if settings.stamina then pawn.InfiniteStamina = true end
end

local function clearPlayerCheat(which)
    local pawn = getPawn()
    if not pawn then return end
    if which == "health" then pawn.Invincible = false end
    if which == "stamina" then pawn.InfiniteStamina = false end
end

-- keep flags applied (respawns, level loads, the game resetting them)
-- Game-thread timers only: LoopAsync/ExecuteWithDelay run Lua on UE4SS's async thread in the same Lua state as
-- our item-lookup hooks, which corrupted it and crashed the game (2026-11-12, host and a joining friend).
LoopInGameThreadWithDelay(500, function()
    if settings.health or settings.stamina then pcall(applyPlayerCheats) end
end)

-- ============================================================================ DROP RATE
-- How the game hands out items (reverse-engineered from the 1.5 blueprints):
--   * Every loot roll goes through Abiotic_Survival_GameMode_C:CalculateItemDrop(entry, ...,
--     DropSuccess&, ItemStruct&, Count&). Callers: GameMode.GenerateLootDrop (crates, desk items,
--     NPCs, corpses, farming, destroyed deployables...), Deployed_Container_ParentBP (container
--     contents), BenchUpgrade_MatterSynthesizer, and ItemFunctionLibrary.TryScrapItemInSlot (salvage).
--   * Each caller first looks up its drop list with the native
--     SalvageHandleFunctionLibrary.GetSalvageRow(RowHandle): real pre-hook (native).
--   * Salvage: Abiotic_PlayerCharacter.Server_TryScrapItem calls the native
--     GlobalItemHandleFunctionLibrary.GetGlobalItemRow(slot item), then
--     ItemFunctionLibrary.TryScrapItemInSlot, which calls GetSalvageRow(item.SalvageData) and rolls.
--     (UE4SS can't hook TryScrapItemInSlot itself: it's called on the library's default object.)
--     So "last item looked up whose SalvageData == the row being rolled" = the item being salvaged.
--   * The salvage preview in the UI reads DT_Salvage directly.
--
-- Rules (what the drop rate multiplies):
--   * Only crafting materials (recipe/upgrade ingredients), never ammo or one-of-a-kind items.
--   * Never anything rolled from a body (NPC kill loot, butchering).
--   * Salvaging a craftable item: vanilla. Salvaging a found-only item: multiplied.
--   * Salvage lists used ONLY by found-only items are scaled inside DT_Salvage itself, so the UI
--     preview shows the multiplied amounts. Lists shared with a craftable item stay vanilla in the
--     table; found-only items using them are multiplied at the roll instead.
local GAMEMODE = "/Game/Blueprints/Meta/Abiotic_Survival_GameMode.Abiotic_Survival_GameMode_C"
local DT_SALVAGE = "/Game/Blueprints/DataTables/DT_Salvage.DT_Salvage"
local DEBUG_DROPS = true   -- log each drop decision (turn off once confirmed)

local craftable = {}            -- item rows that have a recipe
local itemSalvageOf = {}        -- item row -> its salvage row
local itemSalvageRows = {}      -- salvage row -> true if any item uses it
local craftableSalvageRows = {} -- salvage row -> true if a craftable item uses it
local tableScaledRows = {}      -- salvage rows whose quantities we scaled in DT_Salvage
local singleItems = {}          -- item rows with StackSize 1 (never multiplied anywhere)
local materialItems = {}        -- crafting materials: the only items the drop rate multiplies
local materialsKnown = false    -- false if the recipe tables couldn't be read (then multiply nothing)
local currentSalvageRow = nil   -- salvage row being rolled right now
local lastItemRow = nil         -- last item row looked up via GetGlobalItemRow
local salvagedItem = nil        -- item being salvaged (when currentSalvageRow is its salvage row)

local bodyRows = {}              -- butchering lists (DT_NPCList GibInfo.GibSalvage)
local killRows = {}              -- kill loot lists (DT_NPCList PotentialLootWhenKilled)
local forEachRow
function isBodyRow(row)
    return bodyRows[row] or row:find("^gibbed_") ~= nil or row:find("^butcher_") ~= nil
end

-- Which situation a loot list belongs to. MUST match category() in editor/build_editor.py.
local function categoryOf(row)
    if not row then return "world" end
    if isBodyRow(row) then return "butchering" end
    if killRows[row] then return "kill" end
    if itemSalvageRows[row] then return "destroyed" end
    if row:find("^container_") then return "containers" end
    if row:find("^loot_fishtrash") then return "fishing" end
    if row:find("^harvest_") then return "farming" end
    return "world"
end

-- ---- per-item rules, part of the mod itself (Scripts\rules_data.txt).
-- Anthony picks items in his separate rules program, which exports a list; that list is used as
-- the reference to write this file. The program never talks to the mod.
-- Lines: category<TAB>item id<TAB>1|0. Items/categories not listed use the defaults below.
local RULES_FILE = "ue4ss/Mods/CheatMenu/Scripts/rules_data.txt"
local rules = nil
local function loadRules()
    local f = io.open(RULES_FILE, "r")
    if not f then log("drop rules: no rules_data.txt, using built-in defaults"); return end
    rules = {}
    local n = 0
    for line in f:lines() do
        local c, i, v = line:match("^([%w_]+)\t([^\t]+)\t([01])%s*$")
        if c then
            rules[c] = rules[c] or {}
            rules[c][i] = (v == "1")
            n = n + 1
        end
    end
    f:close()
    log("drop rules: %d rules loaded from rules_data.txt", n)
end

forEachRow = function(path, fn)
    pcall(LoadAsset, path)
    local dt = StaticFindObject(path)
    if not valid(dt) then return false end
    dt:ForEachRow(fn)
    return true
end

local function rowKey(rowName)
    if type(rowName) == "string" then return rowName end
    return rowName:ToString()
end

local function scaleCount(c)
    local scaled = c * settings.droprate
    local n = math.floor(scaled)
    if math.random() < (scaled - n) then n = n + 1 end
    return n
end

local function eligible(item)
    return materialsKnown and materialItems[item] and not singleItems[item]
end

-- Should `key` be multiplied in situation `cat`? The editor's file wins; otherwise the defaults
-- (same as the editor's starting checkboxes). For "salvaging" the key is the item being
-- salvaged; for every other category it's the item that drops.
local function shouldMultiply(cat, key)
    local r = rules and rules[cat]
    if r and r[key] ~= nil then return r[key] end
    if cat == "salvaging" then return not craftable[key] end
    if cat == "butchering" or cat == "destroyed" then return false end
    return eligible(key) and true or false
end

local ITEM_TABLES = { "Craftables", "Deployables", "Deployables_CraftingBenches", "Deployables_Small",
    "FoodAndGibs", "Gear", "Global", "Pets", "Pickups", "Plants", "Weapons" }
local RECIPE_TABLES = { "/Game/Blueprints/DataTables/DT_Recipes.DT_Recipes",
    "/Game/Blueprints/DataTables/DT_ChemistryRecipes.DT_ChemistryRecipes" }
local SUBSTITUTES = "/Game/Blueprints/Items/ItemTable_RecipeSubstitutes.ItemTable_RecipeSubstitutes"

-- ---- body loot (DT_NPCList kill loot + butchering, plus gibbed_*/butcher_* rows)
local function collectBodyRows()
    local n = 0
    local function add(name)
        if name and name ~= "None" and not bodyRows[name] then bodyRows[name] = true; n = n + 1 end
    end
    local nKill = 0
    pcall(forEachRow, "/Game/Blueprints/DataTables/DT_NPCList.DT_NPCList", function(_, row)
        pcall(function() add(row.GibInfo.GibSalvage.RowName:ToString()) end)
        pcall(function()
            row.PotentialLootWhenKilled:ForEach(function(_, h)
                local name = h:get().RowName:ToString()
                if name ~= "None" and not killRows[name] then killRows[name] = true; nKill = nKill + 1 end
            end)
        end)
    end)
    log("NPC loot: %d butchering lists, %d kill-loot lists", n, nKill)
end

-- ---- crafting materials (ingredients of recipes, chemistry, bench and item upgrades)
local function collectMaterials()
    local groups = {}
    pcall(forEachRow, SUBSTITUTES, function(rowName, row)
        local list = {}
        pcall(function() row.ItemsOfType:ForEach(function(_, h) list[#list + 1] = h:get().RowName:ToString() end) end)
        groups[rowKey(rowName)] = list
    end)
    local function addInputs(arr)
        pcall(function()
            arr:ForEach(function(_, inputRef)
                local input = inputRef:get()
                local name = input.Item.RowName:ToString()
                local tbl = 0
                pcall(function() tbl = input.Item.Table end)
                if tbl == 1 and groups[name] then
                    for _, m in ipairs(groups[name]) do materialItems[m] = true end
                elseif name ~= "None" then
                    materialItems[name] = true
                end
            end)
        end)
    end
    for _, path in ipairs(RECIPE_TABLES) do
        pcall(forEachRow, path, function(_, row) addInputs(row.RecipeItems) end)
    end
    pcall(forEachRow, "/Game/Blueprints/DataTables/DT_BenchUpgrades.DT_BenchUpgrades",
        function(_, row) addInputs(row.RequiredItems) end)
    pcall(forEachRow, "/Game/Blueprints/DataTables/DT_ItemUpgrades.DT_ItemUpgrades", function(_, row)
        pcall(function() row.Upgrades:ForEach(function(_, e) addInputs(e:get().RequiredItems) end) end)
    end)
    for name in pairs(materialItems) do   -- ammo never counts (every ammo row is ammo_*)
        if name:lower():find("^ammo_") then materialItems[name] = nil end
    end
    local n = 0
    for _ in pairs(materialItems) do n = n + 1 end
    log("crafting materials: %d item types", n)
    return n
end

-- ---- items: recipes, salvage rows, stack sizes
local function collectItems()
    local nCraftable = 0
    for _, path in ipairs(RECIPE_TABLES) do
        pcall(forEachRow, path, function(_, row)
            local ok, item = pcall(function() return row.ItemToCreate.RowName:ToString() end)
            if ok and item and item ~= "None" and not craftable[item] then
                craftable[item] = true; nCraftable = nCraftable + 1
            end
        end)
    end
    local nSingle = 0
    for _, t in ipairs(ITEM_TABLES) do
        local path = "/Game/Blueprints/Items/ItemTable_" .. t .. ".ItemTable_" .. t
        local ok, err = pcall(forEachRow, path, function(rowName, row)
            local item = rowKey(rowName)
            local okT, st = pcall(function() return row.StackSize end)
            if okT and type(st) == "number" and st <= 1 and not singleItems[item] then
                singleItems[item] = true; nSingle = nSingle + 1
            end
            local okR, salvage = pcall(function() return row.SalvageData.RowName:ToString() end)
            if not okR or not salvage or salvage == "None" then return end
            itemSalvageOf[item] = salvage
            itemSalvageRows[salvage] = true
            if craftable[item] then craftableSalvageRows[salvage] = true end
        end)
        if not ok then log("could not read item table %s: %s", t, tostring(err)) end
    end
    log("items: %d craftable, %d one-of-a-kind", nCraftable, nSingle)
    return nCraftable
end

-- ---- scale DT_Salvage for salvage lists where EVERY item using the list is set to multiply
-- (so the salvage preview shows the real amounts). Mixed lists stay vanilla in the table and the
-- checked items are multiplied at the roll instead.
local salvageOriginals = {}   -- row -> { [index] = {min, max} } captured once
local function salvageListAllOn(row)
    local any = false
    for item, srow in pairs(itemSalvageOf) do
        if srow == row then
            any = true
            if not shouldMultiply("salvaging", item) then return false end
        end
    end
    return any
end

-- Vanilla amounts of every salvage list, captured once before we touch the table:
-- salvageEntries[row] = { {item=, min=, max=}, ... } in table order (used by the tooltip).
local salvageEntries = nil
local function captureSalvageEntries()
    if salvageEntries then return end
    salvageEntries = {}
    pcall(forEachRow, DT_SALVAGE, function(rowName, row)
        local list = {}
        row.SalvageDropItems:ForEach(function(_, e)
            local d = e:get()
            list[#list + 1] = { item = d.ItemDataTable.RowName:ToString(), min = d.QuantityMin, max = d.QuantityMax }
        end)
        salvageEntries[rowKey(rowName)] = list
    end)
end

-- The vanilla tooltip shows salvage results as icons only (it hard-codes a stack of 1 and hides
-- the number - see W_InventoryItemSlot_Tooltip.RefreshTooltipInformation). After it builds them,
-- write the real amount, including the drop-rate multiplier, into each icon's stack text.
local function amountLabel(min, max)
    if min == max then return "x" .. max end
    return min .. "-" .. max
end

local function decorateTooltip(tooltip)
    if not salvageEntries then return end
    local item = tooltip.ItemRowName:ToString()
    local row = itemSalvageOf[item]
    local list = row and salvageEntries[row]
    if not list then return end
    local mult = settings.droprate > 1.0 and shouldMultiply("salvaging", item)
    if DEBUG_DROPS and CheatMenu_LastTip ~= item then
        CheatMenu_LastTip = item
        log("tooltip: %s (list %s) multiplied=%s craftable=%s", item, row, tostring(mult), tostring(craftable[item] == true))
    end
    local box = tooltip.Hbox_SalvageItems
    local n = box:GetChildrenCount()
    for i = 0, n - 1 do
        local e = list[i + 1]
        local slot = box:GetChildAt(i)
        if e and valid(slot) then
            local min, max = e.min, e.max
            if mult and not singleItems[e.item] then
                min = math.floor(min * settings.droprate + 0.5)
                max = math.floor(max * settings.droprate + 0.5)
            end
            pcall(function()
                slot.StackText:SetText(FText(amountLabel(min, max)))
                slot.StackText:SetVisibility(3)   -- HitTestInvisible
            end)
        end
    end
end

-- The game does NOT read DT_Salvage values we write at runtime when it rolls (verified 2026-11-09:
-- the table said 3 per item but the roll gave 1), so salvage results are multiplied at the roll
-- (onCalculateItemDrop) and the tooltip shows the numbers via decorateTooltip. We only capture the
-- vanilla amounts here.
local function applySalvageTable()
    captureSalvageEntries()
    log("salvage amounts captured for the tooltip (%d lists)", (function() local n = 0 for _ in pairs(salvageEntries or {}) do n = n + 1 end return n end)())
end
-- Called when the cheat menu closes, so a changed drop rate updates the salvage table.
CheatMenu_ApplySalvageTable = function()
    applySalvageTable()
end

-- ---- the roll itself (post-hook: out params already hold the result)
local function onCalculateItemDrop(DropSuccess, ItemStruct, Count)
    if settings.droprate <= 1.0 then return end
    local okS, success = pcall(function() return DropSuccess:get() end)
    if okS and success == false then return end
    local c = Count:get()
    if type(c) ~= "number" or c <= 0 then return end
    local item = "?"
    pcall(function() item = ItemStruct:get().RowName:ToString() end)
    local row = currentSalvageRow
    local function keep(why)
        if DEBUG_DROPS then log("roll %s x%d kept (%s)", item, c, why) end
    end
    local cat, key
    if salvagedItem then
        cat, key = "salvaging", salvagedItem
        if singleItems[item] then return keep("one-of-a-kind result") end
    else
        cat, key = categoryOf(row), item
    end
    if row and tableScaledRows[row] then return keep("already scaled in salvage table " .. row) end
    if not shouldMultiply(cat, key) then return keep(cat .. ": " .. key .. " is set to normal") end
    local n = scaleCount(c)
    if n ~= c then
        Count:set(n)
        if DEBUG_DROPS then log("roll %s %d -> %d (%.1fx, %s: %s)", item, c, n, settings.droprate, cat, key) end
    end
end

-- Installed as early as possible (at startup): containers such as lockers roll their contents
-- while the level is loading. Falls back to the first in-world player spawn.
local dropHooksInstalled = false
local function installDropHooks(when)
    if dropHooksInstalled then return end
    local ok, err = pcall(function()
        LoadAsset(GAMEMODE)
        RegisterHook(GAMEMODE .. ":CalculateItemDrop",
            function(self, ItemDropStruct, IgnoreTags, GameplayTags, ExtraLootChance, DropSuccess, ItemStruct, Count)
                local okM, errM = pcall(onCalculateItemDrop, DropSuccess, ItemStruct, Count)
                if not okM then log("drop roll failed: %s", tostring(errM)) end
            end)
        RegisterHook(GAMEMODE .. ":GenerateLootDrop", function()
            currentSalvageRow = nil
            salvagedItem = nil
        end)
    end)
    if ok then
        dropHooksInstalled = true
        log("drop rate hook installed (%s)", when)
    else
        log("drop rate hook failed (%s): %s", when, tostring(err))
        return
    end
    pcall(loadRules)
    pcall(collectItems)
    pcall(collectBodyRows)
    local okMat, nMat = pcall(collectMaterials)
    materialsKnown = okMat and type(nMat) == "number" and nMat > 0
    if not materialsKnown then log("crafting materials could not be read; drop rate will multiply nothing") end
    -- native lookups: real pre-hooks
    local okI, errI = pcall(function()
        RegisterHook("/Script/AbioticFactor.GlobalItemHandleFunctionLibrary:GetGlobalItemRow",
            function(self, RowHandle)
                local okN, name = pcall(function() return RowHandle:get().RowName:ToString() end)
                if okN then lastItemRow = name end
            end)
    end)
    if not okI then log("item lookup hook failed: %s", tostring(errI)) end
    local okG, errG = pcall(function()
        RegisterHook("/Script/AbioticFactor.SalvageHandleFunctionLibrary:GetSalvageRow",
            function(self, RowHandle)
                local okN, name = pcall(function() return RowHandle:get().RowName:ToString() end)
                currentSalvageRow = okN and name or nil
                salvagedItem = nil
                if currentSalvageRow and lastItemRow and itemSalvageOf[lastItemRow] == currentSalvageRow then
                    salvagedItem = lastItemRow
                end
            end)
    end)
    if not okG then log("salvage row hook failed: %s", tostring(errG)) end
    pcall(applySalvageTable)
    local okT, errT = pcall(function()
        local TOOLTIP = "/Game/Blueprints/Widgets/Inventory/W_InventoryItemSlot_Tooltip.W_InventoryItemSlot_Tooltip_C"
        LoadAsset(TOOLTIP)
        RegisterHook(TOOLTIP .. ":RefreshTooltipInformation", function(self)
            local okD, errD = pcall(decorateTooltip, self:get())
            if not okD and DEBUG_DROPS then log("tooltip amounts failed: %s", tostring(errD)) end
        end)
    end)
    if not okT then log("tooltip hook failed: %s", tostring(errT)) end
end

ExecuteInGameThread(function() installDropHooks("startup") end)

-- ---------------------------------------------------------------- UI
local ESlateVisibility = { Visible = 0, Collapsed = 1, Hidden = 2, HitTestInvisible = 3, SelfHitTestInvisible = 4 }

local W = {
    UserWidget  = "/Script/UMG.UserWidget",
    WidgetTree  = "/Script/UMG.WidgetTree",
    Canvas      = "/Script/UMG.CanvasPanel",
    Border      = "/Script/UMG.Border",
    VBox        = "/Script/UMG.VerticalBox",
    TextBlock   = "/Script/UMG.TextBlock",
    Title       = "/Game/Blueprints/Widgets/MenuSystem/W_MenuTitleBig.W_MenuTitleBig_C",
    -- NOTE: W_GameCommand / W_GameCommandEntry_* widgets crash the game without a GameCommands row, and
    -- W_Settings_Boolean's checkbox has no style outside the settings page; don't use them.
    -- W_MainMenuButton renders blank and huge inside a row, so toggles use a plain CheckBox.
    CheckBox    = "/Script/UMG.CheckBox",
    SizeBox     = "/Script/UMG.SizeBox",
    ScrollBox   = "/Script/UMG.ScrollBox",
    Slider      = "/Game/Blueprints/Widgets/MenuSystem/Settings_Buttons/W_Settings_SliderBar.W_Settings_SliderBar_C",
}

local menu = nil        -- root UserWidget
local controls = {}     -- { health = CheckBox, stamina = CheckBox, droprate = SpinBox }
local rows = {}         -- { {row=W_GameCommand, title=, desc=} } texts re-applied after Construct
local menuOpen = false
-- widgets can't be built until the engine has finished starting and a player exists;
-- set by the ClientRestart hook (fires at the main menu and on every level load)
local gameReady = false
local controlsReady = false  -- true once controls show our settings; until then don't read them

local function construct(path, outer, name)
    return StaticConstructObject(cls(path), outer, FName(name))
end

-- Nothing in the game holds a UPROPERTY reference to widgets we create from Lua, so Unreal's
-- garbage collector frees them while they're still on screen (crash in SObjectWidget::OnPaint).
-- Construct the root with the RootSet internal flag so it (and everything under it) stays alive.
local ROOTSET = (EInternalObjectFlags and EInternalObjectFlags.RootSet) or 0x40000000
local RF_NoFlags = 0

local function constructRooted(path, outer, name)
    return StaticConstructObject(cls(path), outer, FName(name), RF_NoFlags, ROOTSET)
end

local function createGameWidget(path, pc)
    return wbl():Create(pc, cls(path), pc)
end

-- Rows are built from plain UMG pieces styled like the game's command rows (dark panel,
-- yellow title, the game's TeX Gyre Adventor font). The game's own W_GameCommand row is
-- backed by native code that expects a DT_GameCommands row and destabilises the renderer.
local FONT_PATH = "/Game/Blueprints/Widgets/Fonts/texgyreadventor_Font.texgyreadventor_Font"
local YELLOW = { SpecifiedColor = { R = 1.0, G = 0.92, B = 0.5, A = 1.0 }, ColorUseRule = 0 }

local function gameFont(size)
    local f = cls(FONT_PATH)
    return {
        FontObject = f,
        TypefaceFontName = FName("Default"),
        Size = size,
        LetterSpacing = 0,
        SkewAmount = 0.0,
        bForceMonospaced = false,
        bMaterialIsStencil = false,
        MonospacedWidth = 1.0,
    }
end

local function makeText(tree, name, text, size)
    local tb = construct(W.TextBlock, tree, name)
    -- Only set plain fields: passing whole Slate structs (FSlateFontInfo, FSlateColor) from Lua
    -- tables corrupted memory under UE4SS 3.0.1 and crashed the game.
    tb:SetText(FText(text))
    return tb
end

local rowCount = 0
local function addRow(tree, vbox, title, desc, contentWidget)
    rowCount = rowCount + 1
    local panel = construct(W.Border, tree, "CheatMenu_Row" .. rowCount)
    panel:SetBrushColor({ R = 0.16, G = 0.16, B = 0.16, A = 1.0 })
    panel:SetPadding({ Left = 10, Top = 6, Right = 10, Bottom = 8 })
    local inner = construct(W.VBox, tree, "CheatMenu_RowBox" .. rowCount)
    panel:SetContent(inner)
    inner:AddChildToVerticalBox(makeText(tree, "CheatMenu_RowTitle" .. rowCount, title, 22))
    inner:AddChildToVerticalBox(makeText(tree, "CheatMenu_RowDesc" .. rowCount, desc, 13))
    local cslot = inner:AddChildToVerticalBox(contentWidget)
    pcall(function() cslot:SetPadding({ Left = 0, Top = 6, Right = 0, Bottom = 0 }) end)
    local slot = vbox:AddChildToVerticalBox(panel)
    pcall(function() slot:SetPadding({ Left = 0, Top = 0, Right = 0, Bottom = 6 }) end)
end

local function applyRowTexts() end

local function syncControlsFromSettings()
    pcall(function() controls.health:SetIsChecked(settings.health) end)
    pcall(function() controls.stamina:SetIsChecked(settings.stamina) end)
    pcall(function()
        local s = controls.droprate
        s:SetMinValue(1.0); s:SetMaxValue(10.0)
        s:SetMinSliderValue(1.0); s:SetMaxSliderValue(10.0)
        s:SetDelta(0.5)
        s:SetValue(settings.droprate)
    end)
end

-- plain UMG checkbox (engine style), scaled up and tinted to match the game's teal slider
local function makeCheckBox(tree, name)
    return construct(W.CheckBox, tree, name)
end

local menuCount = 0

local function buildMenu(pc)
    rows, controls = {}, {}
    local gi = FindFirstOf("GameInstance")
    menuCount = menuCount + 1
    local root = constructRooted(W.UserWidget, gi, "CheatMenu_Root" .. menuCount)
    local rooted = false
    pcall(function() rooted = root:HasAnyInternalFlags(ROOTSET) end)
    log("menu root created (kept alive: %s)", tostring(rooted))
    root.WidgetTree = construct(W.WidgetTree, root, "CheatMenu_Tree")
    local tree = root.WidgetTree

    local canvas = construct(W.Canvas, tree, "CheatMenu_Canvas")
    tree.RootWidget = canvas

    local border = construct(W.Border, tree, "CheatMenu_Border")
    border:SetBrushColor({ R = 0.02, G = 0.025, B = 0.03, A = 0.92 })
    border:SetPadding({ Left = 24, Top = 16, Right = 24, Bottom = 20 })
    -- pinned to the top-left corner
    local cslot = canvas:AddChildToCanvas(border)
    cslot:SetAutoSize(true)
    cslot:SetAnchors({ Minimum = { X = 0, Y = 0 }, Maximum = { X = 0, Y = 0 } })
    cslot:SetAlignment({ X = 0, Y = 0 })
    cslot:SetPosition({ X = settings.menux, Y = settings.menuy })
    -- shrink the whole menu around its top-left corner (mouse clicks follow the scaling)
    pcall(function() border:SetRenderTransformPivot({ X = 0, Y = 0 }) end)
    pcall(function() border:SetRenderScale({ X = settings.menuscale, Y = settings.menuscale }) end)

    -- layout: title stays put; the cheat list below it scrolls once it's taller than maxheight
    local outer = construct(W.VBox, tree, "CheatMenu_Outer")
    border:SetContent(outer)

    local title = createGameWidget(W.Title, pc)
    if valid(title) then
        pcall(function() title.TitleText = FText("CHEAT MENU") end)
        outer:AddChildToVerticalBox(title)
    end

    local sizer = construct(W.SizeBox, tree, "CheatMenu_Sizer")
    if settings.maxheight > 0 then pcall(function() sizer:SetMaxDesiredHeight(settings.maxheight) end) end
    outer:AddChildToVerticalBox(sizer)
    local scroll = construct(W.ScrollBox, tree, "CheatMenu_Scroll")
    pcall(function() scroll:SetAlwaysShowScrollbar(false) end)
    sizer:SetContent(scroll)
    local vbox = construct(W.VBox, tree, "CheatMenu_List")
    scroll:AddChild(vbox)

    controls.health = makeCheckBox(tree, "CheatMenu_Health")
    addRow(tree, vbox, "Unlimited Health", "You take no damage.", controls.health)

    controls.stamina = makeCheckBox(tree, "CheatMenu_Stamina")
    addRow(tree, vbox, "Unlimited Stamina", "Sprinting, jumping and swinging never tire you.", controls.stamina)

    local dr = createGameWidget(W.Slider, pc)
    controls.droprate = dr.SettingSpinBox
    addRow(tree, vbox, "Drop Rate", "Multiplies loot from containers, NPCs and corpses (1x to 10x).", dr)

    return root
end

-- Input: remember how the game had the mouse set up before we opened, and put it back
-- exactly on close. At the main menu (or in any game menu) the cursor is already visible and
-- UI input must stay on; forcing GameOnly there is what loses the mouse.
-- If a game menu already has the cursor (main menu, pause, inventory) we leave input alone.
-- Only during normal gameplay do we switch to UI input and switch back on close.
-- (Never pass nil widgets to SetInputMode_*: UE4SS doesn't turn nil into nullptr reliably.)
local weChangedInput = false

local function setInputForMenu(pc, open)
    local lib = wbl()
    if open then
        weChangedInput = false
        if pc.bShowMouseCursor then return end
        weChangedInput = true
        pcall(function() lib:SetInputMode_GameAndUIEx(pc, menu, 0, false) end)
        pc.bShowMouseCursor = true
        pcall(function() pc:SetIgnoreLookInput(true) end)   -- keep the camera still
    elseif weChangedInput then
        weChangedInput = false
        pcall(function() pc:ResetIgnoreLookInput() end)
        pcall(function() lib:SetInputMode_GameOnly(pc, true) end)
        pc.bShowMouseCursor = false
    end
end

local function openMenu()
    local pc = getPC()
    if not valid(pc) then log("no local player controller yet"); return end
    if not gameReady then log("game still starting, F1 ignored"); return end
    if not valid(menu) then
        local ok, res = pcall(buildMenu, pc)
        if not ok or not valid(res) then log("failed to build menu: %s", tostring(res)); return end
        local added, err = pcall(function() res:AddToViewport(500) end)
        if not added then
            log("could not show menu yet: %s", tostring(err))
            pcall(function() res:RemoveFromParent() end)
            return
        end
        menu = res
    else
        local shown = pcall(function() menu:SetVisibility(ESlateVisibility.Visible) end)
        if not shown then menu = nil; return end
    end
    menuOpen = true
    controlsReady = false
    -- widgets run Construct when they're shown; set our texts/values right after that,
    -- twice, in case a widget's own Construct/Tick resets its value a frame later
    for _, delay in ipairs({ 50, 300 }) do
        ExecuteInGameThreadWithDelay(delay, function()
            applyRowTexts()
            syncControlsFromSettings()
            if delay == 300 then controlsReady = true end
        end)
    end
    setInputForMenu(pc, true)
    log("menu opened (changed input: %s)", tostring(weChangedInput))
end

local function closeMenu()
    if valid(menu) then pcall(function() menu:SetVisibility(ESlateVisibility.Collapsed) end) end
    menuOpen = false
    controlsReady = false
    local pc = getPC()
    if valid(pc) then setInputForMenu(pc, false) end
    saveSettings()
    -- drop rate may have changed: rescale the salvage table so the salvage preview stays right
    if CheatMenu_ApplySalvageTable then pcall(CheatMenu_ApplySalvageTable) end
    log("menu closed")
end

-- read the controls while the menu is open (avoids binding UMG delegates from Lua)
LoopInGameThreadWithDelay(150, function()
    if not menuOpen or not controlsReady then return end
    pcall(function()
        if not valid(menu) then menuOpen = false; return end
        if not controlsReady then return end
        for _, which in ipairs({ "health", "stamina" }) do
            local ok, on = pcall(function() return controls[which]:IsChecked() end)
            if ok and type(on) == "boolean" and on ~= settings[which] then
                settings[which] = on
                if on then applyPlayerCheats() else clearPlayerCheat(which) end
                log("%s = %s", which, tostring(on))
            end
        end
        local ok, d = pcall(function() return controls.droprate:GetValue() end)
        if ok and type(d) == "number" then
            d = math.max(1.0, math.min(10.0, d))
            if math.abs(d - settings.droprate) > 0.001 then
                settings.droprate = d
                log("drop rate set to %.1fx", d)
            end
        end
    end)
    return false
end)

local lastF1 = 0
RegisterKeyBind(Key.F1, function()
    local now = os.clock()
    if now - lastF1 < 0.3 then return end   -- ignore key repeat / double taps
    lastF1 = now
    ExecuteInGameThread(function()
        if menuOpen then closeMenu() else openMenu() end
    end)
end)

-- A new level (or the main menu finishing loading) gives us a fresh player controller.
-- Our old widget is gone with the old world, so forget it and rebuild on the next F1.
local function onNewPlayer()
    if valid(menu) then pcall(function() menu:RemoveFromParent() end) end
    menu = nil
    menuOpen = false
    controlsReady = false
    weChangedInput = false
    gameReady = false
    ExecuteInGameThreadWithDelay(2000, function()
        gameReady = true
        pcall(function()
            local inWorld = false
            pcall(function()
                local pc = getPC()
                inWorld = valid(pc) and not pc:GetWorld():GetFullName():find("MainMenu")
            end)
            log("new player controller (in world: %s)", tostring(inWorld))
            if inWorld then installDropHooks("in world") end
        end)
    end)
end

RegisterHook("/Script/Engine.PlayerController:ClientRestart", onNewPlayer)
-- fallback in case ClientRestart already fired before this mod loaded
ExecuteInGameThreadWithDelay(30000, function() gameReady = true end)

if DEBUG_KEYS then
    -- F2 forces a full garbage collection, to prove the menu survives it
    RegisterKeyBind(Key.F2, function()
        ExecuteInGameThread(function()
            local pc = getPC()
            local ksl = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
            ksl:ExecuteConsoleCommand(pc, "obj gc", pc)
            log("debug: forced garbage collection")
        end)
    end)
end

if DEBUG_OPEN_ON_START then
    -- hands-free soak test: open, toggle, force GC, close, reopen; logs each step
    local function step(ms, name, fn)
        ExecuteInGameThreadWithDelay(ms, function()
            pcall(function()
                local ok, err = pcall(fn)
                log("selftest %s: %s", name, ok and "ok" or tostring(err))
            end)
        end)
    end
    local function gc()
        local pc = getPC()
        StaticFindObject("/Script/Engine.Default__KismetSystemLibrary"):ExecuteConsoleCommand(pc, "obj gc", pc)
    end
    step(40000, "open", openMenu)
    step(43000, "read", function()
        log("slider=%s health=%s", tostring(controls.droprate:GetValue()), tostring(controls.health:IsChecked()))
        controls.stamina:SetIsChecked(true)
    end)
    step(50000, "gc1", gc)
    step(70000, "gc2", gc)
    step(80000, "close", closeMenu)
    step(85000, "gc3", gc)
    step(90000, "reopen", openMenu)
    step(100000, "gc4", gc)
    step(130000, "still alive", function() end)
    step(131000, "final close", function() controls.stamina:SetIsChecked(false); end)
    step(132000, "close2", closeMenu)
end

log("loaded (F1 opens the menu). health=%s stamina=%s droprate=%.1fx",
    tostring(settings.health), tostring(settings.stamina), settings.droprate)
