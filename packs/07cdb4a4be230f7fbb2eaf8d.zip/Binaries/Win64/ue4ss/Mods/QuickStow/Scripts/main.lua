-- QuickStow v7 (Stow and Swap Item Wheel)
-- One key (unbound by default; set it in the F4 "Mod Keybinds" menu):
--   * TAP  = the item in your hand (current hotbar slot) goes back to the backpack slot it came from (if free), else the first free slot.
--            Backpack full -> it stays and "Inventory is full" pops up.
--   * HOLD = the game's radial wheel opens with every item in your backpack (one entry per item type).
--            Point at one and let go: it swaps into your current hotbar slot (what was there goes into
--            the backpack slot it came from, or its own remembered slot if that is free).
--   * Remembers the backpack slot each item was taken from with the wheel (origins.txt); tapping puts it
--     back there if empty (even a favorited/"locked" slot). Other empty favorited slots are skipped.
-- How (see NOTES.md):
--  * Moves = Player.Request_TrySwapItems(inv1, idx1, inv2, idx2), the game's own drag-and-drop swap.
--  * Wheel = W_RadialWheel_Medical_C (its "Get Wheel Data" shows any item row's icon + name), opened with
--    Player.EnterRadialWheel(class) and closed with TryCloseRadialWheel(false, class) so its own "use item"
--    commit never runs. A post-hook on its "Get Wheel Categories" writes our rows into EntryList; the hook
--    only acts on the wheel this mod opened, so the vanilla medical wheel is untouched.
--   * Optional keys (F4 menu, unbound by default): sort the inventory under the mouse, delete the item under
--     the mouse; Ctrl+Z restores the last 2 deleted items (single player / host).
-- Hooks owned (no other Lua mod may hook these): W_RadialWheel_Medical_C:Get Wheel Categories
-- Timers: game thread only (LoopInGameThreadWithDelay). Key polled with IsInputKeyDown (no RegisterKeyBind).

local MOD = "[QuickStow] "
local function log(fmt, ...) print(MOD .. string.format(fmt, ...) .. "\n") end
local function valid(o) return o ~= nil and o.IsValid ~= nil and o:IsValid() end

-- ---------------------------------------------------------------- settings (Mods\QuickStow\settings.txt)
local settings = { key = "", holdms = 250, poll = 30, debug = true }
do
    local f = io.open("ue4ss/Mods/QuickStow/settings.txt", "r")
    if f then
        for line in f:lines() do
            local k, v = line:match("^%s*(%w+)%s*=%s*(%S+)")
            if k and settings[k] ~= nil then
                if type(settings[k]) == "boolean" then settings[k] = (v == "true" or v == "1")
                elseif type(settings[k]) == "number" then settings[k] = tonumber(v) or settings[k]
                else settings[k] = v end
            end
        end
        f:close()
    end
end
local function dbg(fmt, ...) if settings.debug then log(fmt, ...) end end

local KEY_ID = "QuickStow.key"
local okMK, MK = pcall(require, "ModKeys")
if okMK then MK.register(KEY_ID, "Quick Stow", "Tap: stow held item / Hold: backpack wheel", settings.key); MK.watch()
else log("ModKeys not found (%s), using key %s", tostring(MK), settings.key) end
-- unbound by default (no conflicts); nil = no key set yet
local function theKey()
    if okMK then return MK.fkey(KEY_ID) end
    return settings.key ~= "" and settings.key or nil
end

local function gtLoop(ms, fn)
    local h
    local ok, res = pcall(LoopInGameThreadWithDelay, ms, function()
        local ok2, stop = pcall(fn)
        if not ok2 then log("loop: %s", tostring(stop)); stop = false end
        if stop and h then pcall(CancelDelayedAction, h) end
    end)
    if ok then h = res else log("LoopInGameThreadWithDelay unavailable: %s", tostring(res)) end
end

-- ---------------------------------------------------------------- game paths
local WHEEL_PKG  = "/Game/Blueprints/Widgets/TextChat/W_RadialWheel_Medical"
local WHEEL_CLS  = WHEEL_PKG .. ".W_RadialWheel_Medical_C"
local HOOK_CATS  = WHEEL_CLS .. ":Get Wheel Categories"
local PLAYER_CLS = "/Game/Blueprints/Characters/Abiotic_PlayerCharacter.Abiotic_PlayerCharacter_C"
local SEL_INV = "Inventory_2_B69CD60741EFD551F09ED5AFF44B1E46"   -- CurrentHotbarSlotSelected fields
local SEL_IDX = "Index_5_6BDC7B3944A5DE0B319F9FA20720872F"

local function addr(o) return valid(o) and o:GetAddress() or 0 end
local function rowOf(slot)
    local ok, r = pcall(function() return slot.ItemDataTable.RowName:ToString() end)
    if ok and r and r ~= "" and r ~= "None" then return r end
    return nil
end

local cachedPC
local function getPC()
    if valid(cachedPC) then return cachedPC end
    cachedPC = nil
    for _, pc in ipairs(FindAllOf("PlayerController") or {}) do
        if valid(pc) then
            local ok, isLocal = pcall(function() return pc:IsLocalController() end)
            if ok and isLocal then cachedPC = pc; return pc end
        end
    end
end
local keyStructs = {}   -- FKey structs built once per key name (polled every 30 ms)
local function keyDown(pc, name)
    if not name then return false end
    local k = keyStructs[name]
    if not k then k = { KeyName = FName(name) }; keyStructs[name] = k end
    local ok, v = pcall(function() return pc:IsInputKeyDown(k) end)
    return ok and v == true
end

local function popup(p, text)
    if not pcall(function() p:Client_DisplayItemErrorNotify(FText(text), true) end) then
        pcall(function() p:Client_DisplayWarningMessage(FText(text), 1, true) end)
    end
end

local function swap(p, inv1, i1, inv2, i2)
    dbg("Request_TrySwapItems(%s %d <-> %s %d)", inv1:GetFName():ToString(), i1, inv2:GetFName():ToString(), i2)
    local ok, err = pcall(function() p:Request_TrySwapItems(inv1, i1, inv2, i2) end)
    if not ok then log("swap failed: %s", tostring(err)) end
end

-- current hotbar slot (0-based), held item or not
local function hotbarIndex(p)
    local hot = p.CharacterHotbarInventory
    if not valid(hot) then return nil end
    local idx
    pcall(function()
        local sel = p.CurrentHotbarSlotSelected
        if addr(sel[SEL_INV]) == addr(hot) then idx = sel[SEL_IDX] end
    end)
    if type(idx) ~= "number" or idx < 0 then idx = p.LastSelectedHotbarSlot end
    if type(idx) ~= "number" or idx < 0 or idx >= hot.CurrentInventory:GetArrayNum() then return nil end
    return hot, idx
end

-- favorited ("locked") slots are left alone like the game does, unless it is the item's own remembered slot
local function favorited(inv, idx)
    local ok, r = pcall(function()
        local o = {}
        local ret = inv["IsSlotFavorited?"](inv, idx, o)
        if type(ret) == "boolean" then return ret end
        return o.Favorited == true
    end)
    return ok and r == true
end
local function slotEmpty(inv, idx)
    local arr = inv.CurrentInventory
    return idx >= 0 and idx < arr:GetArrayNum() and rowOf(arr[idx + 1]) == nil
end
local function firstEmpty(inv)
    local arr = inv.CurrentInventory
    for i = 1, arr:GetArrayNum() do if rowOf(arr[i]) == nil and not favorited(inv, i - 1) then return i - 1 end end
end

-- backpack slot each item row was taken from with the wheel (Mods\QuickStow\origins.txt: "row slot")
local ORIGINS = "ue4ss/Mods/QuickStow/origins.txt"
local origins = {}
do
    local f = io.open(ORIGINS, "r")
    if f then
        for line in f:lines() do
            local r, i = line:match("^%s*(%S+)%s+(%d+)")
            if r then origins[r] = tonumber(i) end
        end
        f:close()
    end
end
local function saveOrigins()
    local f = io.open(ORIGINS, "w")
    if not f then log("could not write %s", ORIGINS); return end
    for r, i in pairs(origins) do f:write(r, " ", i, "\n") end
    f:close()
end
-- where a row should go in the backpack: its remembered slot if free, else the first free normal slot
local function homeSlot(bag, row)
    local o = origins[row]
    if o and slotEmpty(bag, o) then return o end
    return firstEmpty(bag)
end

-- ---------------------------------------------------------------- tap: stow held item
local function stow(p)
    if not valid(p.ItemInHand_BP) then dbg("tap: nothing in hand"); return end
    local hot, idx = hotbarIndex(p)
    if not hot or not rowOf(hot.CurrentInventory[idx + 1]) then dbg("tap: held item is not in a hotbar slot"); return end
    local bag = p.CharacterInventory
    local free = valid(bag) and homeSlot(bag, rowOf(hot.CurrentInventory[idx + 1]))
    if not free then popup(p, "Inventory is full"); dbg("tap: backpack full"); return end
    swap(p, hot, idx, bag, free)
end

-- ---------------------------------------------------------------- hold: backpack wheel
local S = { open = false, opening = false, w = nil, wAddr = 0, p = nil, list = {}, cls = nil,
            pending = false, t0 = 0, wasDown = false }

local function wheelClass()
    if valid(S.cls) then return S.cls end
    pcall(function() LoadAsset(WHEEL_PKG) end)   -- load before lookup: a StaticFindObject miss scans unsafely
    local c = StaticFindObject(WHEEL_CLS)
    S.cls = valid(c) and c or nil
    return S.cls
end
local function isOurs(w) return S.opening or (S.open and addr(w) == S.wAddr) end

-- Item names like ItemFunctionLibrary.GetItemFullName: soup bowl = "{Item} ({Soup})" with the soup row as the
-- first comma-separated ingredient in PlayerMadeString; teleporter = "{Item} ({Bench})"; pets = their name;
-- "{CookedState}" in a food name = its cooking state (dynamic property 18, states 1-5 only, like the game).
local GL_CDO = "/Script/AbioticFactor.Default__GlobalItemHandleFunctionLibrary"   -- native CDO, always loaded
-- Names never cost a lookup during play (GetGlobalItemRow copies a whole 40+ field item row into Lua,
-- which hitched the game):
--  * names_base.txt ships the names of ~1000 items, taken from the game's item tables offline;
--  * any other row shows its row id until the wheel itself shows it: the wheel's own SelectionChanged writes
--    the item's name into EntryName, we learn it from there (main loop) and keep it in names.txt;
--  * the soup in a bowl is the one exception: looked up once per soup type at wheel open, then kept.
local gl, rowInfo = nil, {}
local NAMES = "ue4ss/Mods/QuickStow/names.txt"
for _, file in ipairs({ "ue4ss/Mods/QuickStow/names_base.txt", NAMES }) do
    local f = io.open(file, "r")
    if f then
        for line in f:lines() do
            local row, pet, name = line:match("^([^\t]+)\t([01])\t(.*)$")
            if row then rowInfo[row] = { name = name, pet = pet == "1" } end
        end
        f:close()
    end
end
local function str(v) local ok, r = pcall(function() return v:ToString() end); return ok and r or "" end
local function learn(row, r)
    rowInfo[row] = r
    local f = io.open(NAMES, "a")
    if f then f:write(row, "\t", r.pet and "1" or "0", "\t", (r.name:gsub("[\r\n\t]", " ")), "\n"); f:close() end
end
-- known name of a row; lookup = true allows the slow game lookup (soups only)
local function info(row, lookup)
    local r = rowInfo[row]
    if r then return r end
    if not lookup then return { name = row, pet = false } end
    r = { name = row, pet = false }
    local ok = pcall(function()
        if not valid(gl) then gl = StaticFindObject(GL_CDO) end
        local d, rp = {}, {}
        gl:GetGlobalItemRow({ RowName = FName(row) }, d, rp)
        local data = d.ItemName and d or d.Data   -- UE4SS unpacks the out struct into the table passed
        local n = str(data.ItemName)
        if n ~= "" then r.name = n end
    end)
    if ok then learn(row, r) end   -- a failed lookup is retried next time
    return r
end
-- everything that makes two items of one row different (all of ChangeableData except AssetID and stack size)
local DP_COOKING = 18
local COOKED = { "Cooked", "Carefully Cooked", "Well Cooked", "Beautifully Cooked", "Expertly Cooked" }  -- ECookingState 1-5
local LIQUID = { "Water", "Feces", "Radioactive Waste", "Molten Material", "Fuel", "Vomit", "Battery Acid", "Blood",
                 "Antejuice", "Tainted Water", "Soup", "Laser", "Ink" }   -- ELiquidType 1-13
local function itemState(slot)
    local st = { dyn = {} }
    pcall(function()
        local c = slot.ChangeableData
        st.pms = str(c.PlayerMadeString)
        st.dur, st.maxDur = c.CurrentItemDurability, c.MaxItemDurability
        st.ammo, st.liquid, st.level = c.CurrentAmmoInMagazine, c.CurrentLiquid, c.LiquidLevel
        pcall(function() st.tex = str(c.TextureVariantRow.RowName) end)
        pcall(function()
            local t, tags = {}, c.GameplayTags.GameplayTags
            for i = 1, tags:GetArrayNum() do t[#t + 1] = str(tags[i].TagName) end
            table.sort(t); st.tags = table.concat(t, ",")
        end)
        local dp = c.DynamicProperties
        for i = 1, dp:GetArrayNum() do st.dyn[#st.dyn + 1] = { k = dp[i].Key, v = dp[i].Value } end
    end)
    local parts = {}
    for _, f in ipairs({ "pms", "dur", "maxDur", "ammo", "liquid", "level", "tex", "tags" }) do
        local v = st[f]; if type(v) == "number" then v = string.format("%.3f", v) end
        parts[#parts + 1] = tostring(v)
    end
    local d = {}
    for _, e in ipairs(st.dyn) do d[#d + 1] = tostring(e.k) .. "=" .. tostring(e.v) end
    table.sort(d)
    st.key = table.concat(parts, "|") .. "|" .. table.concat(d, ",")
    return st
end
local function cookedState(st)
    for _, e in ipairs(st.dyn) do if e.k == DP_COOKING then return e.v end end
    return 0
end
local function fullName(row, st)
    local i = info(row)
    local name = i.name
    if name:find("{CookedState}", 1, true) then
        local cs = COOKED[cookedState(st)]
        name = cs and name:gsub("{CookedState}", cs) or name:gsub("{CookedState}%s*", "")
        name = name:gsub("^%s+", "")
    end
    local pms = st.pms or ""
    if pms == "" then return name end
    if row:lower() == "soupbowl" then
        local soup = pms:match("^%s*([^,]+)")
        if soup then return string.format("%s (%s)", name, (info(soup, true).name:gsub("{CookedState}%s*", ""))) end
    elseif row == "PersonalTeleporter" then
        local bench = pms:match(",%s*(.-)%s*$")
        if bench and bench ~= "" then return string.format("%s (%s)", name, bench) end
    elseif i.pet then
        return pms
    end
    return name
end
local function shownName(e) return fullName(e.row, e.st) .. e.extra end
local disambiguate

-- one wheel entry per unique item: same row AND same state (only stack size may differ) = same entry.
-- { row, slot (0-based), key, st, extra }; entries whose names clash get their difference in `extra`.
local function collect(p)
    local list, seen = {}, {}
    local bag = p.CharacterInventory
    if not valid(bag) then return list end
    local arr = bag.CurrentInventory
    for i = 1, arr:GetArrayNum() do
        local r = rowOf(arr[i])
        if r then
            local st = itemState(arr[i])
            local key = r .. "|" .. st.key
            if not seen[key] then
                seen[key] = true
                list[#list + 1] = { row = r, slot = i - 1, key = key, st = st, extra = "" }
            end
        end
    end
    disambiguate(list)
    return list
end

-- entries whose names clash get their difference in `extra` (liquid, durability %, ammo), then "#slot".
-- Run again whenever a name is learned, so a placeholder clash does not leave a stale suffix.
function disambiguate(list)
    local function clashes()
        local n = {}
        for _, e in ipairs(list) do local k = shownName(e); n[k] = (n[k] or 0) + 1 end
        return n
    end
    for _, e in ipairs(list) do e.extra = "" end
    local n = clashes()
    for _, e in ipairs(list) do
        if n[shownName(e)] > 1 then
            local st, extra = e.st, {}
            if (st.liquid or 0) > 0 and LIQUID[st.liquid] and e.row:lower() ~= "soupbowl" then extra[#extra + 1] = LIQUID[st.liquid] end
            if type(st.maxDur) == "number" and st.maxDur > 0 and type(st.dur) == "number" then
                extra[#extra + 1] = string.format("%d%%", math.floor(st.dur / st.maxDur * 100 + 0.5))
            end
            if (st.ammo or 0) > 0 then extra[#extra + 1] = st.ammo .. " ammo" end
            if #extra > 0 then e.extra = " (" .. table.concat(extra, ", ") .. ")" end
        end
    end
    n = clashes()
    for _, e in ipairs(list) do if n[shownName(e)] > 1 then e.extra = e.extra .. " #" .. (e.slot + 1) end end
end

local function canOpen(pc, p)
    if not valid(p) or not p:IsA(StaticFindObject(PLAYER_CLS)) then return false end
    local blocked = false
    pcall(function() if pc.bShowMouseCursor then blocked = true end end)   -- inventory, menus, map...
    pcall(function() if pc.IsTextChatOpen then blocked = true end end)
    pcall(function() if valid(p.RadialWheel) then blocked = true end end)
    pcall(function()
        if StaticFindObject("/Script/Engine.Default__GameplayStatics"):IsGamePaused(pc) then blocked = true end
    end)
    return not blocked
end

local function decorate(w)
    pcall(function() w.Text_MedicalTarget:SetVisibility(1) end)   -- "Using on <player>" line of the medical wheel
    if #S.list == 0 then pcall(function() w.EntryName:SetText(FText("Backpack is empty")) end); return end
    local n = 0
    pcall(function() n = w.SelectionWheel.Children:GetArrayNum() end)
    local sc = n > 12 and math.max(0.45, 12 / n) or 1   -- shrink icons on a crowded wheel
    for i = 1, n do
        pcall(function()
            local icon = w.SelectionWheel.Children[i]
            icon:SetIsEnabled(true)   -- medical wheel greys out items that have no "use" animation
            if sc < 1 then icon:SetRenderScale({ X = sc, Y = sc }) end
        end)
    end
end

local function openWheel(p)
    local cls = wheelClass()
    if not cls then log("wheel class %s not found", WHEEL_CLS); return end
    local t0 = os.clock()
    S.list = collect(p)
    local t1 = os.clock()
    S.p, S.opening = p, true
    local ok, err = pcall(function() p:EnterRadialWheel(cls) end)
    S.opening = false
    S.ms = { (t1 - t0) * 1000, (os.clock() - t1) * 1000 }
    if not ok then log("EnterRadialWheel failed: %s", tostring(err)); return end
    local w = p.RadialWheel
    if not valid(w) or not w:IsA(cls) then dbg("wheel did not open"); return end
    S.w, S.wAddr, S.open = w, w:GetAddress(), true
    dbg("wheel open: %d item(s), our list %.1f ms, game wheel %.1f ms", #S.list, S.ms[1], S.ms[2])
    decorate(w)
end

local function resetState() S.open, S.w, S.wAddr, S.p, S.list = false, nil, 0, nil, {} end

local function closeWheel()
    local p, w, list = S.p, S.w, S.list
    local idx = -1
    pcall(function() idx = w.SelectionWheel.Index end)
    pcall(function() p:TryCloseRadialWheel(false, S.cls, {}) end)
    resetState()
    local e = list[(idx or -1) + 1]
    if not e or not valid(p) then dbg("no selection (index %s)", tostring(idx)); return end
    local row = e.row
    local bag = p.CharacterInventory
    local hot, hidx = hotbarIndex(p)
    if not hot or not valid(bag) then log("no hotbar slot selected"); return end
    local arr = bag.CurrentInventory
    local function same(i) local r = rowOf(arr[i]); return r == row and (r .. "|" .. itemState(arr[i]).key) == e.key end
    local from = same(e.slot + 1) and e.slot or nil
    if not from then   -- moved since the wheel opened: find the same item again
        for i = 1, arr:GetArrayNum() do if same(i) then from = i - 1; break end end
    end
    if not from then log("%s is no longer in your backpack", shownName(e)); return end
    local outRow = rowOf(hot.CurrentInventory[hidx + 1])   -- what was in the hotbar slot (may be nil)
    origins[row] = from; saveOrigins()
    swap(p, bag, from, hot, hidx)
    -- the item that left the hotbar landed in slot `from`; move it on to its own remembered slot if that is free
    local o = outRow and origins[outRow]
    if o and o ~= from and slotEmpty(bag, o) then swap(p, bag, from, bag, o) end
end

-- ---------------------------------------------------------------- hook
local hooked = false
local function tryHook()
    if not valid(FindFirstOf("Abiotic_PlayerCharacter_C")) then return end   -- player class loaded first
    if not valid(StaticFindObject(PLAYER_CLS)) or not wheelClass() then return end
    hooked = true
    local ok, e = pcall(RegisterHook, HOOK_CATS, function(ctx, entryList, hasList)
        local w = ctx:get()
        if not isOurs(w) then return end
        local ok2, err = pcall(function()
            local arr = entryList:get()
            arr:Empty()
            for i, e in ipairs(S.list) do arr[i] = FName(e.row) end
            hasList:set(#S.list > 0)
            w.SelectionWheel:UpdateSegments(#S.list)
        end)
        if not ok2 then log("could not fill the wheel: %s", tostring(err)) end
    end)
    if not ok then log("hook Get Wheel Categories failed: %s", tostring(e)) end
end

-- ---------------------------------------------------------------- inventory keys: sort / delete / undo
-- Press actions through ModKeys (RegisterKeyBind reads the keyboard directly, so they work while the
-- inventory screen has focus). Both start unbound. They only act while a game screen shows the cursor
-- and the mouse is over an inventory slot / grid.
--  * Sort   = PlayerController.Request_SortInventory(inv) (the game's own sort, server side).
--  * Delete = Player.Request_DropOrDestroySpecificItem(inv, true, n, idx) (game's destroy, server side).
--    Before deleting, a full copy of the slot goes into a private 2-slot inventory component
--    (inv:UpdateInventorySlot copies the whole struct engine side: durability, liquid, names...).
--  * Ctrl+Z = put the newest copy back with Player.Server_UpdateInventorySlot (same slot if still empty,
--    else the first free slot). That function is not a network request, so undo needs authority
--    (single player / host); a client gets "Undo only works in your own world".
local INVCOMP_PKG = "/Game/Blueprints/Characters/Abiotic_InventoryComponent"
local INVCOMP = INVCOMP_PKG .. ".Abiotic_InventoryComponent_C"
local UNDO_MAX = 2

local function screenOpen(pc) local s = false; pcall(function() s = pc.bShowMouseCursor == true end); return s end
local function localPlayer()
    local pc = getPC()
    if not valid(pc) or not screenOpen(pc) then return nil end
    local p = pc.Pawn
    if not valid(p) then return nil end
    return pc, p
end

local function hoveredSlot()
    for _, w in ipairs(FindAllOf("W_InventoryItemSlot_C") or {}) do
        local ok, hit = pcall(function() return w:IsHovered() end)
        if ok and hit then
            local inv, idx
            pcall(function()
                if w.RepresentationOnly then return end   -- crafting previews, journal icons...
                inv, idx = w.ParentInventoryGrid.MainInventoryComponent, w.SlotIndex
            end)
            if valid(inv) and type(idx) == "number" then return inv, idx end
        end
    end
end
local function hoveredInventory()
    local inv = hoveredSlot()
    if inv then return inv end
    for _, g in ipairs(FindAllOf("W_InventoryGrid_C") or {}) do
        local ok, hit = pcall(function() return g:IsHovered() end)
        if ok and hit then
            local c
            pcall(function() c = g.MainInventoryComponent end)
            if valid(c) then return c end
        end
    end
end

local function sortHovered()
    local pc, p = localPlayer()
    if not p then return end
    local inv = hoveredInventory()
    if not inv then dbg("sort: mouse is not over an inventory"); return end
    dbg("sort %s", inv:GetFName():ToString())
    local ok, err = pcall(function() pc:Request_SortInventory(inv) end)
    if not ok then log("sort failed: %s", tostring(err)) end
end

local undo, buffer = {}, nil   -- undo: newest last, { inv, idx, k (buffer slot), row }
local function undoBuffer()
    if valid(buffer) then return buffer end
    pcall(function() LoadAsset(INVCOMP_PKG) end)   -- loaded before lookup (StaticFindObject miss rule)
    local c = StaticFindObject(INVCOMP)
    if not valid(c) then return nil end
    local ROOTSET = (EInternalObjectFlags and EInternalObjectFlags.RootSet) or 0x40000000
    local ok, b = pcall(StaticConstructObject, c, FindFirstOf("GameInstance"),
        FName(string.format("QuickStow_Undo_%x", os.time())), 0, ROOTSET)
    if not ok or not valid(b) then log("undo buffer: %s", tostring(b)); return nil end
    pcall(function() b:UpdateInventorySlotCount(UNDO_MAX, false, { X = 0, Y = 0, Z = 0 }) end)
    buffer = b
    return b
end

local function deleteHovered()
    local pc, p = localPlayer()
    if not p then return end
    local inv, idx = hoveredSlot()
    if not inv then dbg("delete: mouse is not over an item"); return end
    local slot = inv.CurrentInventory[idx + 1]
    local row = rowOf(slot)
    if not row then return end
    local b, rec = undoBuffer(), nil
    if b then
        if #undo >= UNDO_MAX then table.remove(undo, 1) end   -- forget the oldest
        local used, k = {}, nil
        for _, u in ipairs(undo) do used[u.k] = true end
        for i = 0, UNDO_MAX - 1 do if not used[i] then k = i; break end end
        local ok, err = pcall(function() b:UpdateInventorySlot(k, slot) end)
        if ok and rowOf(b.CurrentInventory[k + 1]) == row then
            rec = { inv = inv, idx = idx, k = k, row = row }
            undo[#undo + 1] = rec
        else log("could not keep a copy of %s for undo (%s)", row, tostring(err)) end
    end
    local ok, err = pcall(function() p:Request_DropOrDestroySpecificItem(inv, true, 99999, idx) end)
    if not ok then
        log("delete failed: %s", tostring(err))
        if rec and undo[#undo] == rec then table.remove(undo) end
        return
    end
    dbg("deleted %s from %s %d", row, inv:GetFName():ToString(), idx)
end

local function undoDelete()
    if okMK and MK.menuOpen and MK.menuOpen() then return end
    local pc, p = localPlayer()
    if not p then return end
    local u = undo[#undo]
    if not u then popup(p, "Nothing to undo"); return end
    local auth = false
    pcall(function() auth = p:HasAuthority() end)
    if not auth then popup(p, "Undo only works in your own world"); return end
    local b = undoBuffer()
    local data = b and b.CurrentInventory[u.k + 1]
    if not data or rowOf(data) ~= u.row then table.remove(undo); log("undo copy of %s was lost", u.row); return end
    local inv, idx = u.inv, u.idx
    if not valid(inv) then inv, idx = p.CharacterInventory, nil end
    if idx and not slotEmpty(inv, idx) then idx = nil end
    idx = idx or firstEmpty(inv)
    if not idx and addr(inv) ~= addr(p.CharacterInventory) then inv = p.CharacterInventory; idx = firstEmpty(inv) end
    if not idx then popup(p, "Inventory is full"); return end
    local ok, err = pcall(function() p:Server_UpdateInventorySlot(inv, data, idx, nil, -1) end)
    if not ok then ok, err = pcall(function() p:Server_UpdateInventorySlot(inv, data, idx, CreateInvalidObject(), -1) end) end
    if not ok then log("undo failed: %s", tostring(err)); return end
    table.remove(undo)
    dbg("restored %s to %s %d", u.row, inv:GetFName():ToString(), idx)
end

if okMK and MK.bind then   -- older ModKeys without bind: keys just stay unavailable
    MK.bind("QuickStow.sort", "Sort Inventory", "Sort the inventory under the mouse", "", sortHovered)
    MK.bind("QuickStow.delete", "Delete Key", "Delete the item under the mouse (Ctrl+Z undoes the last 2)", "", deleteHovered)
end
pcall(function()
    RegisterKeyBind(Key.Z, { ModifierKey.CONTROL }, function()
        if #undo > 0 then ExecuteInGameThread(function() local ok, e = pcall(undoDelete); if not ok then log("undo: %s", tostring(e)) end end) end
    end)
end)

-- ---------------------------------------------------------------- main loop (game thread)
local hookWait = 0
gtLoop(settings.poll, function()
    if not hooked then
        hookWait = hookWait + settings.poll
        if hookWait >= 2000 then hookWait = 0; pcall(tryHook) end
        return false
    end
    local pc = getPC()
    if not valid(pc) then if S.open then resetState() end; S.pending, S.wasDown = false, false; return false end
    local down = keyDown(pc, theKey())
    if S.open then
        if not (valid(S.w) and valid(S.p) and addr(S.p.RadialWheel) == S.wAddr) then
            dbg("wheel was closed by the game"); resetState()
        elseif not down then closeWheel()
        else
            pcall(function()
                local e = S.list[S.w.SelectionWheel.Index + 1]
                if not e then return end
                local cur = S.w.EntryName:GetText():ToString()
                if cur == e.shown then return end
                -- not our text: the wheel just wrote this item's plain name -> learn it if we did not know it
                if cur ~= "" and cur ~= S.lastShown and not rowInfo[e.row] then
                    learn(e.row, { name = cur, pet = false })
                    disambiguate(S.list)
                end
                e.shown = shownName(e)
                S.lastShown = e.shown
                if cur ~= e.shown then S.w.EntryName:SetText(FText(e.shown)) end
            end)
        end
    elseif S.pending then
        local p = pc.Pawn
        if not down then
            S.pending = false
            if canOpen(pc, p) then stow(p) end
        elseif (os.clock() - S.t0) * 1000 >= settings.holdms then
            S.pending = false
            if canOpen(pc, p) then
                local ok, err = pcall(openWheel, p)
                if not ok then log("open failed: %s", tostring(err)); S.opening = false end
            end
        end
    elseif down and not S.wasDown and canOpen(pc, pc.Pawn) then
        S.pending, S.t0 = true, os.clock()
    end
    S.wasDown = down
    return false
end)

log("loaded (key %s: tap = stow, hold = wheel)", theKey() or "not set - bind it with F4")
