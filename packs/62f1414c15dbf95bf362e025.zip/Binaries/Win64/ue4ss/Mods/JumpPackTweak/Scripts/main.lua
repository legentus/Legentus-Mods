-- JumpPackTweak: Jump Pack and Long Jump Pack get 38 slots and 60% weight reduction.
-- Edits just those two rows in memory, so it survives backpack-mod and game updates with no rebuild.
-- v1 edited only the ItemTable_Gear asset: the log showed it being unloaded and reloaded while the
-- game kept using the old numbers, so the game reads a different (runtime) table. v2 patches EVERY
-- loaded DataTable that has these rows, and logs which tables those are. Rechecked every 5 s.
local MOD = "[JumpPackTweak] "
local PATCH = {  -- row = { slots, weight reduction }
    backpack_jetpack      = { 38, 0.6 },
    backpack_longjumppack = { 38, 0.6 },
}
local function log(fmt, ...) print(MOD .. string.format(fmt, ...) .. "\n") end
local seenTables = {}
local lastCount = -1

local function patchTable(dt)
    local full = dt:GetFullName()
    local hits = 0
    dt:ForEachRow(function(rowName, row)
        local name = type(rowName) == "string" and rowName or rowName:ToString()
        local want = PATCH[name]
        if not want then return end
        hits = hits + 1
        local eq = row.EquipmentData
        if eq.ContainerCapacity ~= want[1] or math.abs(eq.ContainerWeightReduction - want[2]) > 1e-6 then
            local old, oldW = eq.ContainerCapacity, eq.ContainerWeightReduction
            eq.ContainerCapacity = want[1]
            eq.ContainerWeightReduction = want[2]
            log("%s in %s: %d slots / %.0f%% -> %d / %.0f%% (readback %d)", name, full, old, oldW * 100, want[1], want[2] * 100, eq.ContainerCapacity)
        end
    end)
    if hits > 0 and not seenTables[full] then seenTables[full] = true; log("table with jump pack rows: %s (%d rows)", full, hits) end
end

local function apply()
    local tables = FindAllOf("DataTable") or {}
    for _, cls in ipairs({ "AbioticModDataTable", "CompositeDataTable" }) do
        for _, t in ipairs(FindAllOf(cls) or {}) do tables[#tables + 1] = t end
    end
    local itemTables = 0
    for _, dt in ipairs(tables) do
        -- only item tables (row struct AbioticInventoryItem); keeps the 5 s check cheap
        local okS, isItem = pcall(function() return dt.RowStruct:GetFName():ToString() == "AbioticInventoryItem" end)
        if dt:IsValid() and okS and isItem then
            itemTables = itemTables + 1
            local ok, err = pcall(patchTable, dt)
            if not ok then log("skip %s: %s", dt:GetFullName(), tostring(err)) end
        end
    end
    if itemTables ~= lastCount then lastCount = itemTables; log("%d data tables loaded, %d are item tables", #tables, itemTables) end
end

LoopInGameThreadWithDelay(5000, function()
    local ok, err = pcall(apply)
    if not ok then log("error: %s", tostring(err)) end
end)
log("loaded")
