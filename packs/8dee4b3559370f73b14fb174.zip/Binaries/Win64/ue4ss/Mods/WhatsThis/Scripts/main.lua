-- WhatsThis v2: game-native tooltip info + Recipes window (sources: tools\ui_v2.lua tooltip part, tools\menu_v2.lua)
--   Hover item + hold Ctrl: where-to-get info inside the game tooltip (wheel scrolls)
--   Right-click item > Recipes: window with how to craft it + recipes that use it (click lines to drill in)
--
--

local MOD = "[WhatsThis] "
local function log(fmt, ...) print(MOD .. string.format(fmt, ...) .. "\n") end
local function valid(o) return o ~= nil and o.IsValid ~= nil and o:IsValid() end

-- ---------------------------------------------------------------- settings
local SETTINGS_FILE = "ue4ss/Mods/WhatsThis/settings.txt"
local settings = { menux = 40, menuy = 60, tipoffx = 28, tipoffy = 18, debug = true }
do
    local f = io.open(SETTINGS_FILE, "r")
    if f then
        for line in f:lines() do
            local k, v = line:match("^%s*(%w+)%s*=%s*(%S+)")
            if k == "debug" then settings.debug = (v == "true")
            elseif settings[k] ~= nil and tonumber(v) then settings[k] = tonumber(v) end
        end
        f:close()
    end
end

-- ---------------------------------------------------------------- data
local okD, D = pcall(require, "data")
if not okD or type(D) ~= "table" then
    log("could not load data.lua: %s", tostring(D))
    return
end

local function nameOf(id)
    local it = D.items[id]
    if it then return it.n end
    local g = D.groups[id]
    if g then return g.n end
    return id
end

-- loot/container/node table ids -> plain English ("container_woodcrate_mf" -> "Wooden crate (Manufacturing)")
local WORDS = {
    officelocker = "office locker", woodcrate = "wooden crate", filingcabinet = "filing cabinet", minecrate = "mine crate",
    labcabinet = "lab cabinet", securitylocker = "security locker", trashbin = "trash bin", kitchencupboard = "kitchen cupboard",
    magazinestand = "magazine stand", ["1sttoolbox"] = "first aid toolbox", inqcrate = "Inquisitor crate", securitycrate = "security crate",
    ornatecrate = "ornate crate", runiccrate = "runic crate", orderammocrate = "ammo order crate", gymbike = "exercise bike",
    hightechmonitor = "high-tech monitor", hydropanel = "hydroponics panel", xmasgift = "holiday gift", powerleech = "power leech",
    heatshield = "heat shield", spontaneous = "random world loot", fishtrash = "", allitems = "", random = "",
    swimmingpool = "swimming pool", nightrealm = "Night Realm", cavewater = "cave water", eelwater = "eel water",
    radioactive = "radioactive water", distantshore = "Distant Shore", is31poolrooms = "IS-31 pool rooms", antejuice = "Ante juice",
    onlytrash = "junk only", generic = "anywhere", tomatoplant = "tomato plant", potatoplant = "potato plant", cornplant = "corn plant",
    wheatplant = "wheat plant", ropeplant = "rope plant", supertomatoplant = "super tomato plant", photocopier = "photocopier",
    mf = "(Manufacturing)", votv = "(VOTV)", vsignal = "(signal)", vsuomi = "(Suomi)", vwinter = "(winter)",
    reactors = "(Reactors)", security = "(Security)", office = "(Offices)", defense = "(Defense)", plant = "(Plant)",
    bvt = "BVT", t2 = "(tier 2)", t3 = "(tier 3)", t4 = "(tier 4)", t5 = "(tier 5)",
}
local function prettify(s)
    s = tostring(s or "")
    if D.items[s] and D.items[s].n ~= s then return D.items[s].n end
    s = s:gsub("^Deployable_", ""):gsub("^loot_", ""):gsub("^container_", ""):gsub("^salvage_", "")
         :gsub("^resourcenode_", ""):gsub("^harvest_", ""):gsub("^gibbed_", ""):gsub("^butcher_", "")
    local out = {}
    for w in s:gmatch("[^_]+") do
        local r = WORDS[w:lower()]
        if r == nil then r = w:gsub("(%l)(%u)", "%1 %2"):lower() end
        if r ~= "" then out[#out + 1] = r end
    end
    s = table.concat(out, " ")
    return (s:gsub("^%l", string.upper))
end

local function amount(lo, hi)
    if lo == nil then return "" end
    if hi == nil or lo == hi then return tostring(lo) end
    return lo .. "-" .. hi
end
local function pct(ch)
    if ch == nil or ch >= 0.999 then return "" end
    return string.format(" %d%%", math.floor(ch * 100 + 0.5))
end

local function clip(s, n)
    if #s > n then return s:sub(1, n - 2) .. ".." end
    return s
end

-- recipes by result, and "used in" index (groups expand to their members)
local byResult, usedIdx = {}, {}
for i, r in ipairs(D.recipes) do
    if r.r then
        byResult[r.r] = byResult[r.r] or {}
        table.insert(byResult[r.r], i)
    end
    local seen = {}
    for _, ing in ipairs(r.i) do
        local id = ing[1]
        local members = (ing[3] and D.groups[id]) and D.groups[id].i or { id }
        for _, m in ipairs(members) do
            if not seen[m] then
                seen[m] = true
                usedIdx[m] = usedIdx[m] or {}
                table.insert(usedIdx[m], i)
            end
        end
    end
end

local function recipeLabel(r)
    return r.r and nameOf(r.r) or ("[" .. prettify(r.id) .. "]")
end

-- ---------------------------------------------------------------- view building
-- A line is { text = "...", target = { v = "item"|"used"|"group", id = "..." } or nil, head = bool }

local function benchText(r)
    if not r.b or #r.b == 0 then return "" end
    local t = {}
    for _, b in ipairs(r.b) do t[#t + 1] = prettify(b) end
    return " at the " .. table.concat(t, " or ")
end

-- ---- CheatMenu drop rate: show amounts the way CheatMenu will actually give them.
-- Reads CheatMenu's settings.txt (droprate) and Scripts\rules_data.txt (per-item rules), re-read every few
-- seconds so a change in the F1 menu shows up. Mirrors CheatMenu shouldMultiply(): rules file first, then
-- salvaging = found-only items multiplied (craftables vanilla), butchering/destroyed = vanilla,
-- everything else = crafting materials only. Stack-size-1 items are never multiplied.
local CM = { rate = 1, rules = {}, at = -100 }
local function cmLoad()
    if os.clock() - CM.at < 3 then return end
    CM.at = os.clock()
    CM.rate = 1
    local f = io.open("ue4ss/Mods/CheatMenu/settings.txt", "r")
    if f then
        for line in f:lines() do
            local v = line:match("^droprate=([%d%.]+)")
            if v then CM.rate = math.max(1, math.min(10, tonumber(v) or 1)) end
        end
        f:close()
    end
    local en = io.open("ue4ss/Mods/CheatMenu/enabled.txt", "r")   -- CheatMenu off -> vanilla amounts
    if en then en:close() else CM.rate = 1 end
    CM.rules = {}
    f = io.open("ue4ss/Mods/CheatMenu/Scripts/rules_data.txt", "r")
    if f then
        for line in f:lines() do
            local c, i, v = line:match("^([%w_]+)\t([^\t]+)\t([01])%s*$")
            if c then CM.rules[c] = CM.rules[c] or {}; CM.rules[c][i] = (v == "1") end
        end
        f:close()
    end
end
local function cmSingle(item) local it = D.items[item]; return it and it.s == 1 end
local function cmMultiplies(cat, key)
    local r = CM.rules[cat]
    if r and r[key] ~= nil then return r[key] end
    if cat == "salvaging" then return not byResult[key] end
    if cat == "butchering" or cat == "destroyed" then return false end
    return usedIdx[key] ~= nil and not cmSingle(key)
end
local CM_CAT = { npc_kill = "kill", butchering = "butchering", container = "containers", fishing = "fishing",
    ["farming/harvest"] = "farming", salvage = "salvaging" }
-- lo, hi for source s of item `item`, after the drop rate
local function scaleLoHi(s, item)
    if not s.lo then return s.lo, s.hi end
    cmLoad()
    if CM.rate <= 1 then return s.lo, s.hi end
    local cat = CM_CAT[s.k] or ((s.t or ""):find("^salvage_") and "destroyed" or "world")
    local key = cat == "salvaging" and s.f or item
    if not key or not cmMultiplies(cat, key) or (cat == "salvaging" and cmSingle(item)) then return s.lo, s.hi end
    local hi = s.hi or s.lo
    return math.floor(s.lo * CM.rate), math.ceil(hi * CM.rate)
end

local function sourceLines(id, forTip)
    local lines = {}
    local src = D.sources[id] or {}
    local seenLabel, order = {}, {}
    local function add(text, target)
        local key = text .. (target and target.id or "")
        if seenLabel[key] then seenLabel[key].n = seenLabel[key].n + 1; return end
        local e = { text = text, target = target, n = 1 }
        seenLabel[key] = e
        order[#order + 1] = e
    end
    for _, s in ipairs(src) do
        local am, ch = amount(scaleLoHi(s, id)), pct(s.ch)
        local a = (am ~= "" and ("x" .. am) or "") .. (ch ~= "" and ((am ~= "" and "," or "") .. ch .. " chance") or "")
        a = a ~= "" and ("  (" .. a .. ")") or ""
        local npc = s.npc and s.npc:gsub("(%l)(%u)", "%1 %2") or "unknown creature"
        -- source link: opens the source view (wiki summary + everything found there)
        local src = { v = "source", k = s.k, id = s.npc or s.t, name = s.npc and npc or prettify(s.t) }
        if s.k == "npc_kill" then add("Dropped by " .. npc .. a, src)
        elseif s.k == "butchering" then add("Butchering a " .. npc .. a, src)
        elseif s.k == "container" then
            local c = prettify(s.t):lower():gsub("^inquisitor", "Inquisitor")
            add("Found in " .. (c:match("^[aeiouAEIOU]") and "an " or "a ") .. c .. a, src)
        elseif s.k == "crate_or_world_loot" then add("Found in " .. prettify(s.t) .. a, src)
        elseif s.k == "fishing" then add("Fishing: " .. prettify(s.t) .. a, src)
        elseif s.k == "farming/harvest" then add("Harvested from " .. prettify(s.t) .. a, src)
        elseif s.k == "salvage" then
            add("Salvaged from " .. nameOf(s.f or "?") .. a, s.f and { v = "item", id = s.f } or nil)
        end
    end
    for _, e in ipairs(order) do
        if e.n > 1 then e.text = e.text .. "  x" .. e.n end
        lines[#lines + 1] = { text = e.text, target = e.target }
    end
    return lines
end

local function buildItemView(id)
    local v = { title = "How to get: " .. nameOf(id), lines = {} }
    local L = v.lines
    local rs = byResult[id]
    if rs then
        for _, i in ipairs(rs) do
            local r = D.recipes[i]
            L[#L + 1] = { text = "Craft " .. (r.c or 1) .. (benchText(r) ~= "" and benchText(r) or " by hand") .. " from:", head = true }
            for _, ing in ipairs(r.i) do
                local isG = ing[3] and D.groups[ing[1]]
                L[#L + 1] = {
                    text = "    " .. ing[2] .. "x " .. nameOf(ing[1]) .. (isG and "  (any of several)" or ""),
                    target = { v = isG and "group" or "item", id = ing[1] },
                }
            end
        end
    end
    local sl = sourceLines(id, false)
    if #sl > 0 then
        L[#L + 1] = { text = "Where to find it:", head = true }
        for _, l in ipairs(sl) do l.text = "    " .. l.text; L[#L + 1] = l end
    end
    if #L == 0 then
        L[#L + 1] = { text = "No known source. It may be a quest reward, an unlock or a special item." }
    end
    if usedIdx[id] then
        L[#L + 1] = { text = "USED IN " .. #usedIdx[id] .. " RECIPES  >", target = { v = "used", id = id }, head = true }
    end
    return v
end

local function buildGroupView(gid)
    local g = D.groups[gid]
    local v = { title = (g and g.n or gid) .. " - any one of:", lines = {} }
    for _, m in ipairs(g and g.i or {}) do
        v.lines[#v.lines + 1] = { text = "    " .. nameOf(m), target = { v = "item", id = m } }
    end
    return v
end

local function buildUsedView(id)
    local v = { title = nameOf(id) .. " is used in:", lines = {} }
    local list = {}
    for _, i in ipairs(usedIdx[id] or {}) do list[#list + 1] = i end
    table.sort(list, function(a, b)
        local la, lb = recipeLabel(D.recipes[a]):lower(), recipeLabel(D.recipes[b]):lower()
        if la ~= lb then return la < lb end
        return a < b
    end)
    for _, i in ipairs(list) do
        local r = D.recipes[i]
        local need
        for _, ing in ipairs(r.i) do
            local members = (ing[3] and D.groups[ing[1]]) and D.groups[ing[1]].i or { ing[1] }
            for _, m in ipairs(members) do if m == id then need = ing[2] end end
        end
        local text = "    " .. recipeLabel(r) .. (r.r and (" x" .. (r.c or 1)) or "") .. "   (uses " .. (need or 1) .. ")" .. benchText(r)
        v.lines[#v.lines + 1] = { text = text, target = r.r and { v = "item", id = r.r } or nil }
    end
    if #list == 0 then v.lines[1] = { text = "Not used in any recipe." } end
    return v
end

local function buildView(t)
    if t.v == "used" then return buildUsedView(t.id) end
    if t.v == "group" then return buildGroupView(t.id) end
    return buildItemView(t.id)
end


-- ---------------------------------------------------------------- v2: shared helpers + Ctrl trigger
-- No timers, no FindAllOf: everything runs from game hooks. Widget work that adds widgets or loads assets is
-- always queued with ExecuteInGameThread, never done inside a hook.
local CTXMENU = "/Game/Blueprints/Widgets/Inventory/W_Inventory_ItemContextMenu.W_Inventory_ItemContextMenu_C"
local TOOLTIP = "/Game/Blueprints/Widgets/Inventory/W_InventoryItemSlot_Tooltip.W_InventoryItemSlot_Tooltip_C"
local function key(name) return { KeyName = FName(name) } end
local function keyDown(p, name)
    local ok, v = pcall(function() return p:IsInputKeyDown(key(name)) end)
    return ok and v == true
end
local function owner(w)
    local p = w:GetOwningPlayer()
    if valid(p) then return p end
end
local function itemKey(row)
    if D.items[row] then return row end
    local l = row:lower()
    if D.items[l] then return l end
    return row
end
local logged = {}
local function logOnce(tag, fmt, ...) if not logged[tag] then logged[tag] = true; log(fmt, ...) end end

-- Ctrl pressed while the vanilla item tooltip is up -> pin the info panel for that item (set in the menu part)
local onCtrlItem
local ctrlWas = false
local function tipTick(t)
    local p = owner(t)
    if not p then return end
    local ctrl = keyDown(p, "S")   -- info key (was Ctrl; Anthony asked for S, 2026-11-10)
    if ctrl and not ctrlWas and onCtrlItem then
        local row = t.ItemRowName:ToString()
        if row ~= "" and row ~= "None" then onCtrlItem(p, itemKey(row)) end
    end
    ctrlWas = ctrl
end

-- ---- info panel (Ctrl) + Recipes window (right-click), one window built from vanilla menu buttons
-- Look: rows are REAL vanilla context-menu buttons taken from hidden "donor" copies of W_Inventory_ItemContextMenu
-- (engine-created, nothing copied through Lua). Each donor button is HitTestInvisible (its vanilla click handler can
-- never fire); an invisible plain Button laid over it (opacity 0) takes hover/press, read with IsHovered/IsPressed.
-- Crash/freeze rules learned 2026-11-09: no struct copies into engine calls (fonts/styles), no template constructs,
-- no widget adding inside a widget Tick, never reuse a donor button later (its donor may be garbage collected),
-- no LoadAsset inside a hook (queue it with ExecuteInGameThread).
local WBL = "/Script/UMG.Default__WidgetBlueprintLibrary"
local WLL = "/Script/UMG.Default__WidgetLayoutLibrary"
local WAYPOINT_TICK = "/Game/Blueprints/Meta/PlayerController_WaypointManagerComponent.PlayerController_WaypointManagerComponent_C:ReceiveTick"
local ROWS = 100000      -- no paging: everything is in one scroll box
local SCALE = 0.8        -- window render scale (smaller than the vanilla menu)
local WIDTH = 440        -- window content width before scaling
local WRAP = 40          -- characters per summary row (the summary is split into rows)
local TEXTW = WIDTH - 80 -- row text wraps at this width (leaves room for the icon)
local ORIG_BUTTONS = { "Button_ApplyCoating", "Button_Drop", "Button_Favorite", "Button_PourOut", "Button_PrimaryUse", "Button_Recharge",
    "Button_Rename", "Button_Repair", "Button_SplitStack", "Button_Take", "Button_UnloadMagazine" }
local OP_NORMAL, OP_HOVER, OP_DIM, OP_TEXT = 0.85, 1.0, 0.45, 0.75
local LOADTAG = string.format("%x%04x", os.time() % 0xFFFFFF, math.random(0, 0xFFFF))
local seq = 0
local function cls(path) return StaticFindObject(path) end
local function construct(path, outer, flags)
    seq = seq + 1
    return StaticConstructObject(cls(path), outer, FName("WhatsThis_" .. LOADTAG .. "_" .. seq), 0, flags or 0)
end
local ROOTSET = (EInternalObjectFlags and EInternalObjectFlags.RootSet) or 0x40000000

-- generated data: icons/names (build_icons.py) and wiki summaries (wiki_build.py) -----------------------------
local okI, GEN = pcall(require, "icons")
if not okI or type(GEN) ~= "table" then log("icons.lua missing: %s", tostring(GEN)); GEN = {} end
local ICONS = GEN.icons or {}
do -- the game's own display names replace raw ids the handoff data left unnamed
    local lower = {}
    for k, n in pairs(GEN.names or {}) do lower[k:lower()] = n end
    for k, it in pairs(D.items) do
        local n = lower[k:lower()]
        if n and (it.n == k or it.n == "") then it.n = n end
    end
    for k, n in pairs(GEN.names or {}) do if not D.items[k] then D.items[k] = { n = n, s = 0 } end end
end
local okW, WIKI = pcall(require, "wiki")
if not okW or type(WIKI) ~= "table" then log("wiki.lua missing: %s", tostring(WIKI)); WIKI = {} end
-- wiki summary for a display name: exact, then without "(...)", then dropping trailing words ("Grunt Sniper" -> "Grunt")
local WIKI_SIG
local function wikiFor(name)
    if not name then return nil end
    local k = name:lower()
    if WIKI[k] then return WIKI[k] end
    k = k:gsub("%s*%b()", ""):gsub("%s+$", "")
    if WIKI[k] then return WIKI[k] end
    local function sig(s) -- same words in any order; "bot" ~ "robot"
        local t = {}
        for w in s:gmatch("%S+") do t[#t + 1] = (w == "bot" and "robot" or w) end
        table.sort(t); return table.concat(t, " ")
    end
    if not WIKI_SIG then
        WIKI_SIG = {}
        for wk, wv in pairs(WIKI) do local s = sig(wk); WIKI_SIG[s] = WIKI_SIG[s] or wv end
    end
    if WIKI_SIG[sig(k)] then return WIKI_SIG[sig(k)] end
    while k:find(" ") do
        k = k:gsub("%s*%S+$", "")
        if WIKI[k] then return WIKI[k] end
    end
end
-- summary written from our own data when the wiki has no page (what it's made from, what uses it, how to get it)
local function autoSummary(id)
    local n, s = nameOf(id), {}
    local rs = byResult[id]
    if rs and D.recipes[rs[1]] then
        local r, ing = D.recipes[rs[1]], {}
        for _, i in ipairs(r.i or {}) do ing[#ing + 1] = i[2] .. " " .. nameOf(i[1]) end
        s[#s + 1] = n .. " is crafted" .. (benchText(r) ~= "" and benchText(r) or " by hand") .. " from " .. table.concat(ing, ", ") .. "."
    end
    local u = usedIdx[id]
    if u and #u > 0 then
        local names, seen = {}, {}
        for _, ri in ipairs(u) do
            local r = D.recipes[ri]
            local rn = r and nameOf(r.r)
            if rn and not seen[rn] then seen[rn] = true; names[#names + 1] = rn end
            if #names >= 3 then break end
        end
        s[#s + 1] = "It is an ingredient in " .. #u .. " recipe" .. (#u == 1 and "" or "s") .. (#names > 0 and (", including " .. table.concat(names, ", ")) or "") .. "."
    end
    local ok, sl = pcall(sourceLines, id, false)
    if ok and #sl > 0 then
        local t = {}
        for i = 1, math.min(3, #sl) do t[#t + 1] = (sl[i].text:gsub("^%s+", "")) end
        s[#s + 1] = "You can get it: " .. table.concat(t, "; ") .. "."
    end
    if #s == 0 then return "There is no wiki page for this item yet." end
    return table.concat(s, " ")
end
local function wrapInto(L, text)
    L[#L + 1] = { text = text, plain = true }
    do return end
    local line = ""
    for w in text:gmatch("%S+") do
        if line ~= "" and #line + #w + 1 > WRAP then L[#L + 1] = { text = line, plain = true }; line = w
        else line = line == "" and w or (line .. " " .. w) end
    end
    if line ~= "" then L[#L + 1] = { text = line, plain = true } end
end

-- views ---------------------------------------------------------------------------------------------------------
local function buildRecipesView(id)
    local v = { title = "Recipes: " .. nameOf(id), lines = {}, icon = id }
    wrapInto(v.lines, wikiFor(nameOf(id)) or autoSummary(id))
    if WT_linkLines then WT_linkLines(v.lines, nameOf(id), 2) end
    local L = v.lines
    L[#L + 1] = { text = "HOW TO CRAFT", head = true }
    local rs = byResult[id]
    if rs then
        for _, i in ipairs(rs) do
            local r = D.recipes[i]
            L[#L + 1] = { text = "Makes " .. (r.c or 1) .. (benchText(r) ~= "" and benchText(r) or " by hand"), head = true }
            for _, ing in ipairs(r.i) do
                local isG = ing[3] and D.groups[ing[1]]
                L[#L + 1] = { text = "    " .. ing[2] .. "x " .. nameOf(ing[1]) .. (isG and "  (any of)" or ""),
                    target = { v = isG and "group" or "recipes", id = ing[1] } }
            end
        end
    else
        L[#L + 1] = { text = "    Can't be crafted" }
    end
    if WT_distillLines then for _, l in ipairs(WT_distillLines(id)) do L[#L + 1] = l end end
    local sl = sourceLines(id, false)   -- found / dropped / salvaged / harvested (same as the Ctrl panel)
    if #sl > 0 then
        L[#L + 1] = { text = "WHERE TO FIND IT", head = true }
        for _, l in ipairs(sl) do l.text = "    " .. l.text; L[#L + 1] = l end
    end
    L[#L + 1] = { text = "USED IN " .. (usedIdx[id] and #usedIdx[id] or 0) .. " RECIPES", head = true }
    for _, l in ipairs(buildUsedView(id).lines) do
        if l.target then l.target = { v = "recipes", id = l.target.id } end
        L[#L + 1] = l
    end
    return v
end

-- info view: wiki summary, how to craft, where to find (each source is a link), recipes link
local buildInfoView
function buildInfoView(id)
    local v = { title = nameOf(id), lines = {} }
    local L = v.lines
    wrapInto(L, wikiFor(nameOf(id)) or autoSummary(id))
    for _, l in ipairs(buildItemView(id).lines) do
        if l.target and l.target.v == "used" then
            v.footer = { text = "Recipes that use it (" .. #(usedIdx[id] or {}) .. ")  >", target = { v = "recipes", id = id } }
            l = nil
        end
        L[#L + 1] = l
    end
    return v
end

-- traders (trades.lua, built from the wiki's Trade tables by tools/trade_build.py): "Buy from X: cost"
local okT, TRADES = pcall(require, "trades")
if not okT or type(TRADES) ~= "table" then log("trades.lua missing: %s", tostring(TRADES)); TRADES = {} end
local idByName
local function idOfName(n)
    if not idByName then
        idByName = {}
        for k in pairs(D.items) do idByName[nameOf(k):lower()] = idByName[nameOf(k):lower()] or k end
    end
    return idByName[n:lower()]
end
-- wiki links: pages named in a summary (wikilinks.lua from wiki_build.py), shown as link rows under it
local okL, WLINKS = pcall(require, "wikilinks")
if not okL or type(WLINKS) ~= "table" then log("wikilinks.lua missing: %s", tostring(WLINKS)); WLINKS = {} end
local okF, FISH = pcall(require, "fishing")
if not okF or type(FISH) ~= "table" then log("fishing.lua missing: %s", tostring(FISH)); FISH = {} end
local okD, WDROPS = pcall(require, "wikidrops")
if not okD or type(WDROPS) ~= "table" then log("wikidrops.lua missing: %s", tostring(WDROPS)); WDROPS = {} end
local okP, LOCS = pcall(require, "locations")
if not okP or type(LOCS) ~= "table" then log("locations.lua missing: %s", tostring(LOCS)); LOCS = {} end
local srcByName  -- name -> drop source (filled by linkLines, below)
local LBYTEXT
local linkLines -- defined after buildSourceView (needs its source index)
local function linksFor(name)
    if not LBYTEXT then
        LBYTEXT = {}
        for k, lst in pairs(WLINKS) do if WIKI[k] then LBYTEXT[WIKI[k]] = lst end end
    end
    local s = name and wikiFor(name)
    return s and LBYTEXT[s] or nil
end
-- distilling (distill.lua from the wiki DistillRecipes table): result name -> { {i=ingredient, n=amount}, ... }
local okS, DIST = pcall(require, "distill")
if not okS or type(DIST) ~= "table" then log("distill.lua missing: %s", tostring(DIST)); DIST = {} end
for k, it in pairs(D.items) do   -- the game tables have no English names for the distillations
    local w = k:match("^distillation_(%a+)$")
    if w and (it.n == k or it.n == "") then
        it.n = w == "noxious" and "Noxious Sludge" or w == "wildcard" and "Any Distillation"
            or (w:sub(1, 1):upper() .. w:sub(2) .. " Distillation")
    end
end
local function distillFrom(name, cap)
    local parts = {}
    for i, e in ipairs(DIST[name:lower()] or {}) do
        if i > cap then parts[#parts + 1] = "and " .. (#DIST[name:lower()] - cap) .. " more"; break end
        parts[#parts + 1] = e.i .. " (" .. e.n .. ")"
    end
    return table.concat(parts, ", ")
end
-- "How to distill" lines for item `id`: what distills into it, or (for a concoction) into each distillation it needs
WT_distillLines = function(id)
    local out, name = {}, nameOf(id)
    if DIST[name:lower()] then
        out[#out + 1] = { text = "How to distill:", head = true }
        out[#out + 1] = { text = "Put one of these in a Distillation Station (amount made in brackets):", plain = true }
        for _, e in ipairs(DIST[name:lower()]) do
            local iid = idOfName(e.i)
            out[#out + 1] = { text = "    " .. e.i .. "  (makes " .. e.n .. ")", target = iid and { v = "info", id = iid } or nil }
        end
        return out
    end
    local seen = {}
    for _, ri in ipairs(byResult[id] or {}) do
        for _, ing in ipairs(D.recipes[ri].i) do
            local nm = nameOf(ing[1])
            if ing[1]:find("^distillation_") and not seen[ing[1]] then
                seen[ing[1]] = true
                if #out == 0 then
                    out[#out + 1] = { text = "How to distill:", head = true }
                    out[#out + 1] = { text = "Distill these first (item, amount made), then combine them as shown above:", plain = true }
                end
                local n = 0
                for _, i2 in ipairs(D.recipes[ri].i) do if i2[1] == ing[1] then n = n + i2[2] end end
                if ing[1] == "distillation_wildcard" then
                    out[#out + 1] = { text = n .. "x Any Distillation: any kind works", plain = true }
                else
                    out[#out + 1] = { text = n .. "x " .. nm .. "  >", target = { v = "info", id = ing[1] }, icon = ing[1] }
                    out[#out + 1] = { text = "From " .. distillFrom(nm, 8), plain = true }
                end
            end
        end
    end
    return out
end
local buildInfoView0 = buildInfoView
buildInfoView = function(id)
    local v = buildInfoView0(id)
    v.icon = v.icon or id
    linkLines(v.lines, nameOf(id), 2)
    do  -- How to distill goes right after How to craft (before "Where to find it")
        local at = #v.lines + 1
        for i, l in ipairs(v.lines) do if l.text == "Where to find it:" then at = i; break end end
        for _, l in ipairs(WT_distillLines(id)) do table.insert(v.lines, at, l); at = at + 1 end
    end
    -- wiki drop tables (wikidrops.lua) for sources the game-data dump missed, then the wiki's Locations section
    local have = {}
    for _, l in ipairs(v.lines) do if l.text then have[#have + 1] = l.text:lower() end end
    local function known(name)
        name = name:lower()
        for _, t in ipairs(have) do if t:find(name, 1, true) then return true end end
    end
    local wd, added = WDROPS[nameOf(id):lower()], false
    for _, e in ipairs(wd or {}) do
        if not known(e.p) then
            if not added then v.lines[#v.lines + 1] = { text = "Also found in:", head = true }; added = true end
            local lo, hi = e.q:match("^(%d+)%s*%-%s*(%d+)$")
            lo, hi = tonumber(lo or e.q:match("^(%d+)$")), tonumber(hi)
            if lo then lo, hi = scaleLoHi({ k = "crate_or_world_loot", t = e.p, lo = lo, hi = hi or lo }, id) end
            local a = lo and ("x" .. lo .. ((hi and hi ~= lo) and ("-" .. hi) or "")) or ""
            if e.c ~= "" and e.c ~= "100%" then a = a .. (a ~= "" and ", " or "") .. e.c .. " chance" end
            local src = srcByName and srcByName[e.p:lower()]
            v.lines[#v.lines + 1] = { text = "    " .. e.p .. (a ~= "" and ("  (" .. a .. ")") or ""),
                target = { v = "source", k = src and src.k or "wiki", id = src and src.id or e.p, name = e.p } }
        end
    end
    local locs = LOCS[nameOf(id):lower()]
    if locs then
        v.lines[#v.lines + 1] = { text = "Known locations:", head = true }
        local bare = {}
        for _, e in ipairs(locs) do
            if e.t == "" then bare[#bare + 1] = e.s
            else v.lines[#v.lines + 1] = { text = (e.s ~= "" and (e.s .. ": ") or "") .. e.t, plain = true } end
        end
        if #bare > 0 then v.lines[#v.lines + 1] = { text = "Sectors: " .. table.concat(bare, ", "), plain = true } end
    end
    local fish = FISH[nameOf(id):lower()]   -- fishing.lua (wiki Fishing page): where / when it bites
    if fish then
        v.lines[#v.lines + 1] = { text = "Catch it by fishing:", head = true }
        for _, f in ipairs(fish) do
            local t = f.l
            if f.t ~= "" then t = t .. " (best at " .. f.t .. ")" end
            if f.n ~= "" then t = t .. ". " .. f.n:sub(1, 1):upper() .. f.n:sub(2) end
            v.lines[#v.lines + 1] = { text = t, plain = true }
        end
    end
    local list = TRADES[nameOf(id):lower()]
    if list then
        v.lines[#v.lines + 1] = { text = "Buy it from a trader:", head = true }
        for _, e in ipairs(list) do
            local cost = {}
            for _, c in ipairs(e.c) do cost[#cost + 1] = c[2] .. " " .. c[1] end
            local t = e.t .. ": " .. e.q .. " for " .. table.concat(cost, " + ")
            if e.s ~= "" then t = t .. " (stock " .. e.s .. ")" end
            if e.u ~= "" then t = t .. ". Unlocked by: " .. e.u end
            local cid = e.c[1] and idOfName(e.c[1][1])
            v.lines[#v.lines + 1] = { text = t, target = cid and { v = "info", id = cid } or nil }
        end
    end
    return v
end

-- source view: wiki summary of the creature/container/place + every item it gives
local srcIdx
local function buildSourceView(t)
    if not srcIdx then
        srcIdx = {}
        for item, lst in pairs(D.sources) do
            for _, s in ipairs(lst) do
                local k = s.npc or s.t
                if k then
                    srcIdx[k] = srcIdx[k] or {}
                    table.insert(srcIdx[k], { item = item, s = s })
                end
            end
        end
    end
    local v = { title = t.name or t.id, lines = {}, icon = t.name and idOfName(t.name) or nil }
    local L = v.lines
    wrapInto(L, wikiFor(t.name) or "No wiki summary for this.")
    if t.name then linkLines(L, t.name, 2) end
    local list = srcIdx[t.id] or {}
    table.sort(list, function(a, b) return nameOf(a.item):lower() < nameOf(b.item):lower() end)
    if #list > 0 then L[#L + 1] = { text = (t.k == "npc_kill" and "DROPS " or t.k == "butchering" and "BUTCHERING GIVES " or "ITEMS HERE ") .. "(" .. #list .. ")", head = true } end
    local seen = {}
    for _, e in ipairs(list) do
        if not seen[e.item] then
            seen[e.item] = true
            local s = e.s
            local lo, hi = scaleLoHi(s, e.item)   -- after CheatMenu's drop rate
            local am = lo and ((hi and hi ~= lo) and (lo .. "-" .. hi) or tostring(lo)) or ""
            local ch = (s.ch and s.ch < 0.999) and string.format(", %d%%", math.floor(s.ch * 100 + 0.5)) or ""
            L[#L + 1] = { text = "    " .. nameOf(e.item) .. (am ~= "" and ("  x" .. am) or "") .. ch, target = { v = "info", id = e.item } }
        end
    end
    return v
end

-- link rows for the pages a summary mentions; a page that is also a drop source opens with its drops
linkLines = function(L, name, at)
    local lst = linksFor(name)

    if not srcByName then
        if not srcIdx then pcall(buildSourceView, { id = "" }) end
        srcByName = {}
        for k, items in pairs(srcIdx or {}) do
            local s = items[1] and items[1].s or {}
            local nm = (s.npc and k:gsub("(%l)(%u)", "%1 %2") or prettify(k)):lower()
            srcByName[nm] = srcByName[nm] or { id = k, k = s.k }
        end
    end
    for _, page in ipairs(lst or {}) do
        local src = srcByName[page:lower()]
        local iid = idOfName(page)   -- an item opens its full item page (craft, where to find, traders)
        local tgt = iid and { v = "info", id = iid } or { v = "source", k = src and src.k or "wiki", id = src and src.id or page, name = page }
        table.insert(L, at, { text = page .. "  >", target = tgt, icon = idOfName(page) })
        at = at + 1
    end
end

WT_linkLines = linkLines   -- for buildRecipesView, which is defined before linkLines

local function viewOf(t)
    local v
    if t.v == "recipes" then v = buildRecipesView(t.id)
    elseif t.v == "info" or t.v == "item" then v = buildInfoView(t.id)
    elseif t.v == "source" then v = buildSourceView(t)
    else v = buildView(t) end
    v.icon = v.icon or ((t.v ~= "source") and t.id or nil)
    for _, l in ipairs(v.lines) do
        if l.target and l.target.v == "item" then l.target = { v = "info", id = l.target.id } end
    end
    return v
end

-- rows ----------------------------------------------------------------------------------------------------------
-- takes n styled {button, text} pairs from fresh donors; the caller must place every one it uses right away
local function donorPairs(p, n)
    local out, TB = {}, cls("/Script/UMG.TextBlock")
    while #out < n do
        local d = cls(WBL):Create(p, cls(CTXMENU), p)
        for _, nm in ipairs(ORIG_BUTTONS) do
            local b = d[nm]
            local ok, t = pcall(function() return b:GetChildAt(0) end)
            if ok and valid(t) and t:IsA(TB) then out[#out + 1] = { b, t } end
        end
    end
    return out
end
local function makeRow(tree, pair, label)
    local b, tb = pair[1], pair[2]
    local box = construct("/Script/UMG.Overlay", tree)
    local hit = construct("/Script/UMG.Button", tree)
    hit:SetRenderOpacity(0)
    b:SetVisibility(3)
    tb.AutoWrapText = false
    tb.WrapTextAt = TEXTW
    tb:SetText(FText(label))
    -- the vanilla button's content becomes [icon][gap][its own text], so the icon sits beside the text, never under it
    local hb = construct("/Script/UMG.HorizontalBox", tree)
    local isz = construct("/Script/UMG.SizeBox", tree)
    isz:SetWidthOverride(32); isz:SetHeightOverride(32)
    local img = construct("/Script/UMG.Image", tree)
    isz:AddChild(img)
    hb:AddChildToHorizontalBox(isz):SetVerticalAlignment(2)
    local gap = construct("/Script/UMG.SizeBox", tree)
    gap:SetWidthOverride(10)
    hb:AddChildToHorizontalBox(gap)
    hb:AddChildToHorizontalBox(tb):SetVerticalAlignment(2)
    local cs = b:SetContent(hb)
    pcall(function() cs:SetHorizontalAlignment(1); cs:SetVerticalAlignment(2) end)
    isz:SetVisibility(1); gap:SetVisibility(1)
    local s1 = box:AddChildToOverlay(b)
    s1:SetHorizontalAlignment(0); s1:SetVerticalAlignment(0)
    local s2 = box:AddChildToOverlay(hit)
    s2:SetHorizontalAlignment(0); s2:SetVerticalAlignment(0)
    return { box = box, hit = hit, tb = tb, op = nil, down = false, icon = isz, gap = gap, img = img }
end
local function iconTex(id)
    local path = id and ICONS[id:lower()]
    if not path then return nil end
    local t = StaticFindObject(path)
    if not valid(t) then pcall(LoadAsset, path); t = StaticFindObject(path) end
    if valid(t) then return t end
end
-- shows the icon of item `id` on row r (or hides it) and sets the text
local function setRow(r, id, text)
    local tex = iconTex(id)
    if tex then
        r.img:SetBrushFromTexture(tex, false)
        r.icon:SetVisibility(3); r.gap:SetVisibility(3)  -- HitTestInvisible
    else
        r.icon:SetVisibility(1); r.gap:SetVisibility(1)
    end
    r.tb:SetText(FText(text))
end
local function setOp(r, o) if r.op ~= o then r.op = o; r.box:SetRenderOpacity(o) end end
local function hovered(r) local ok, v = pcall(function() return r.hit:IsHovered() end) return ok and v == true end
-- true once per press (IsPressed rising edge)
local function pressed(r)
    local ok, v = pcall(function() return r.hit:IsPressed() end)
    v = ok and v == true
    local edge = v and not r.down
    r.down = v
    return edge
end

-- window --------------------------------------------------------------------------------------------------------
-- Layout: each section ("category": title, wiki text, a header and its lines...) is ONE vanilla button frame whose
-- content is a list of lines, so lines of the same section have no frame between them. Sections are rebuilt on
-- every render from fresh donors (old ones are dropped, never reused). Nav rows (More/Back/Close) are fixed.
local win = { root = nil, open = false, lineRows = {} }
local function buildWindow(p)
    local gi = FindFirstOf("GameInstance")
    local root = construct("/Script/UMG.UserWidget", gi, ROOTSET)
    root.WidgetTree = construct("/Script/UMG.WidgetTree", root)
    local tree = root.WidgetTree
    local canvas = construct("/Script/UMG.CanvasPanel", tree)
    tree.RootWidget = canvas
    local bg = construct("/Script/UMG.Border", tree)
    bg:SetBrushColor({ R = 0.02, G = 0.03, B = 0.035, A = 0.96 })
    local cs = canvas:AddChildToCanvas(bg)
    cs:SetAutoSize(true)
    -- a bit smaller than the vanilla menu; scaled from the top-left so placement maths stay simple
    bg:SetRenderTransformPivot({ X = 0, Y = 0 })
    bg:SetRenderScale({ X = SCALE, Y = SCALE })
    local size = construct("/Script/UMG.SizeBox", tree)
    size:SetMinDesiredWidth(WIDTH)
    size:SetMaxDesiredWidth(WIDTH)
    bg:AddChild(size)
    local vbox = construct("/Script/UMG.VerticalBox", tree)
    size:AddChild(vbox)
    -- search box (only shown on the search page; plain UMG text box, default style - no style structs from Lua)
    local sbox = construct("/Script/UMG.EditableTextBox", tree)
    pcall(function() sbox:SetHintText(FText("Type to search items...")) end)
    -- grey box, game-teal text (#78C6BF sampled from the game's item text; values are linear). Only plain colour
    -- fields are written, before the Slate widget exists (no whole style/font structs - those crashed before).
    pcall(function() sbox.WidgetStyle.BackgroundColor.SpecifiedColor = { R = 0.05, G = 0.05, B = 0.05, A = 1 } end)
    pcall(function() sbox.WidgetStyle.BackgroundImageNormal.TintColor.SpecifiedColor = { R = 0.05, G = 0.05, B = 0.05, A = 1 } end)
    pcall(function() sbox.WidgetStyle.BackgroundImageHovered.TintColor.SpecifiedColor = { R = 0.07, G = 0.07, B = 0.07, A = 1 } end)
    pcall(function() sbox.WidgetStyle.BackgroundImageFocused.TintColor.SpecifiedColor = { R = 0.07, G = 0.07, B = 0.07, A = 1 } end)
    pcall(function() sbox:SetForegroundColor({ R = 0.19, G = 0.57, B = 0.53, A = 1 }) end)
    pcall(function() sbox.WidgetStyle.ForegroundColor.SpecifiedColor = { R = 0.19, G = 0.57, B = 0.53, A = 1 } end)
    pcall(function() sbox.WidgetStyle.FocusedForegroundColor.SpecifiedColor = { R = 0.19, G = 0.57, B = 0.53, A = 1 } end)
    vbox:AddChildToVerticalBox(sbox)
    sbox:SetVisibility(1)
    win.search = sbox
    local body = construct("/Script/UMG.VerticalBox", tree)
    local ssize = construct("/Script/UMG.SizeBox", tree)   -- body scrolls; height capped to the screen in place()
    vbox:AddChildToVerticalBox(ssize)
    local scroll = construct("/Script/UMG.ScrollBox", tree)
    ssize:AddChild(scroll)
    scroll:AddChild(body)
    local sres = construct("/Script/UMG.VerticalBox", tree)   -- search results: fixed rows, filled in place while typing
    scroll:AddChild(sres)
    sres:SetVisibility(1)
    win.sres = sres
    win.scroll, win.ssize = scroll, ssize
    local pairs_ = donorPairs(p, 5)
    local function row(i, label)
        local r = makeRow(tree, pairs_[i], label)
        vbox:AddChildToVerticalBox(r.box)
        return r
    end
    win.up = row(1, "^  Previous")
    win.down = row(2, "v  More")
    win.foot = row(5, "Recipes that use it  >")   -- fixed under the scroll list, above Back
    win.back = row(3, "<  Back")
    win.close = row(4, "X  Close")
    win.root, win.slot, win.bg, win.body, win.tree = root, cs, bg, body, tree
    log("window built")
end

-- one line inside a section: [icon][gap][donor text] (+ an invisible hit Button when it is a link)
local function lineWidget(tb, l)
    local tree = win.tree
    local ov = construct("/Script/UMG.Overlay", tree)
    local hb = construct("/Script/UMG.HorizontalBox", tree)
    local tex = iconTex(l.icon)
    if tex then
        local isz = construct("/Script/UMG.SizeBox", tree)
        isz:SetWidthOverride(32); isz:SetHeightOverride(32)
        local img = construct("/Script/UMG.Image", tree)
        img:SetBrushFromTexture(tex, false)
        isz:AddChild(img)
        hb:AddChildToHorizontalBox(isz):SetVerticalAlignment(2)
        local gap = construct("/Script/UMG.SizeBox", tree)
        gap:SetWidthOverride(10)
        hb:AddChildToHorizontalBox(gap)
    end
    tb.AutoWrapText = false
    tb.WrapTextAt = TEXTW
    tb:SetText(FText(l.text))
    tb:SetVisibility(3)
    hb:AddChildToHorizontalBox(tb):SetVerticalAlignment(2)
    hb:SetVisibility(3)
    local s1 = ov:AddChildToOverlay(hb)
    s1:SetHorizontalAlignment(0); s1:SetVerticalAlignment(0)
    local r = { box = ov, line = l, down = false }
    if l.target then
        r.hit = construct("/Script/UMG.Button", tree)
        r.hit:SetRenderOpacity(0)
        local s2 = ov:AddChildToOverlay(r.hit)
        s2:SetHorizontalAlignment(0); s2:SetVerticalAlignment(0)
    end
    return r
end

-- Places the window from its measured size: next to the mouse point (Ctrl panel) or centred (Recipes), flipped
-- to the left of the mouse when there is no room on the right, and always clamped inside the screen.
-- Needs the window in the viewport (it measures the laid-out size).
local function place()
    local p, lib = win.p, cls(WLL)
    local vs, sc = lib:GetViewportSize(p), lib:GetViewportScale(p)
    local w, h = vs.X / sc, vs.Y / sc
    win.ssize:SetMaxDesiredHeight(math.max(200, (h - 16) / SCALE - 110))   -- leave room for Back/Close
    win.root:ForceLayoutPrepass()
    local d = win.bg:GetDesiredSize()
    local dw, dh = d.X * SCALE, d.Y * SCALE
    local x, y
    if win.anchor then
        x = win.anchor.X + 24
        if x + dw > w - 8 then x = win.anchor.X - 24 - dw end   -- no room on the right: open to the left
        y = win.anchor.Y - 20
    else
        x, y = (w - dw) / 2, (h - dh) / 2
        if win.view and win.view.search then y = h * 0.08 end   -- search grows downward while typing: pin the top
    end
    x = math.max(8, math.min(x, w - dw - 8))
    y = math.max(8, math.min(y, h - dh - 8))
    local s = win.slot
    s:SetAnchors({ Minimum = { X = 0, Y = 0 }, Maximum = { X = 0, Y = 0 } })
    s:SetAlignment({ X = 0, Y = 0 })
    s:SetPosition({ X = x, Y = y })
end

-- call only from the ExecuteInGameThread queue (adds widgets, loads icons)
local function render()
    local v = win.view
    if v.search and WT_fillSearch then   -- search page: fixed rows (built once), only their text/icons change
        win.body:ClearChildren()
        win.lineRows = {}
        win.sres:SetVisibility(4)
        WT_fillSearch(win.lastQ or "")
        win.up.box:SetVisibility(1); win.down.box:SetVisibility(1); win.foot.box:SetVisibility(1)
        win.back.box:SetVisibility(#win.stack > 0 and 0 or 1)
        if valid(win.search) then win.search:SetVisibility(0) end
        return
    end
    if valid(win.sres) then win.sres:SetVisibility(1) end
    local n = #v.lines
    win.off = math.max(0, math.min(win.off, math.max(0, n - ROWS)))
    local page = { { text = v.title .. (n > ROWS and ("   (" .. (win.off + 1) .. "-" .. math.min(n, win.off + ROWS) .. " of " .. n .. ")") or ""),
        icon = v.icon, title = true } }
    for i = win.off + 1, math.min(n, win.off + ROWS) do
        local l = v.lines[i]
        page[#page + 1] = { text = (l.text:gsub("^%s+", "")), target = l.target, head = l.head, plain = l.plain, sep = l.sep,
            icon = l.icon or (l.target and l.target.v ~= "source" and l.target.id or nil) }
    end
    -- sections: a new one at the title, after the title, at every header / separator, and where wiki text starts or ends
    local secs, cur, prev = {}, nil, nil
    for _, l in ipairs(page) do
        if not cur or l.title or prev.title or l.head or l.sep or (l.plain and true or false) ~= cur.plain then
            cur = { plain = l.plain and true or false, lines = {} }
            secs[#secs + 1] = cur
        end
        table.insert(cur.lines, l)
        prev = l
    end
    local pairs_ = donorPairs(win.p, math.max(#secs, #page))
    win.body:ClearChildren()
    win.lineRows = {}
    local k = 0
    for si, sec in ipairs(secs) do
        local vb = construct("/Script/UMG.VerticalBox", win.tree)
        for _, l in ipairs(sec.lines) do
            k = k + 1
            local r = lineWidget(pairs_[k][2], l)
            vb:AddChildToVerticalBox(r.box)
            if l.target then
                win.lineRows[#win.lineRows + 1] = r
                setOp(r, OP_NORMAL)
            else
                setOp(r, l.title and 1.0 or (l.plain and OP_TEXT or OP_DIM))
            end
        end
        local frame = pairs_[si][1]
        frame:SetVisibility(4)                                   -- SelfHitTestInvisible: lines inside stay clickable
        local cs = frame:SetContent(vb)
        pcall(function() cs:SetHorizontalAlignment(0) end)
        win.body:AddChildToVerticalBox(frame)
    end
    win.up.box:SetVisibility(win.off > 0 and 0 or 1)
    win.down.box:SetVisibility(win.off + ROWS < n and 0 or 1)
    win.back.box:SetVisibility(#win.stack > 0 and 0 or 1)
    if valid(win.search) then win.search:SetVisibility(v.search and 0 or 1) end
    win.foot.box:SetVisibility(v.footer and 0 or 1)
    if v.footer then win.foot.tb:SetText(FText(v.footer.text)) end
    pcall(function() win.scroll:ScrollToStart() end)
end

-- Escape: the game's EscapeMenu handler (Abiotic_PlayerController) first calls CloseBetaNotice, which removes every
-- W_BetaEndNotice widget and, if it found one, STOPS (no inventory close, no escape menu). So while our window is
-- open we keep a hidden, logic-free W_BetaEndNotice in the viewport: Escape eats it instead of closing the menus,
-- and windowTick closes our window when it is gone.
local BETA = "/Game/Blueprints/Widgets/MenuSystem/W_BetaEndNotice.W_BetaEndNotice_C"
local function armEscape(p)
    if valid(win.esc) and win.esc:IsInViewport() then return end
    local c = StaticFindObject(BETA)
    if not valid(c) then pcall(LoadAsset, "/Game/Blueprints/Widgets/MenuSystem/W_BetaEndNotice"); c = StaticFindObject(BETA) end
    if not valid(c) then logOnce("nobeta", "W_BetaEndNotice not found; Escape will also close the game menu") return end
    win.esc = cls(WBL):Create(p, c, p)
    if valid(win.esc) then
        win.esc:SetVisibility(1)
        win.esc:AddToViewport(-1000)
        win.escArmed = true
    end
end
-- The inventory/crafting screens handle Escape themselves (W_PlayerInventory_Main OnKeyDown -> WidgetAction_CloseMenu),
-- and that action first checks IsSplitStackOpen (W_SplitStackMenu visible): if so it only hides the split-stack box
-- and stops. So we also make the split-stack box "visible" at render scale 0 (draws nothing, no hit area): Escape
-- hides it instead of closing the menu, and windowTick sees that and closes our window.
local function armSplitGuard(p)
    if valid(win.ss) then return end
    local ok, ss = pcall(function() return p.PlayerHUDRef.W_PlayerInventory_Main.W_SplitStackMenu end)
    if not ok or not valid(ss) then logOnce("noss", "split-stack menu not found; Escape may close the inventory") return end
    if ss:GetVisibility() == 0 then return end   -- a real split is open: leave it alone
    local sc = ss.RenderTransform.Scale
    win.ssScale = { X = sc.X, Y = sc.Y }
    ss:SetRenderScale({ X = 0, Y = 0 })
    ss:SetVisibility(0)
    win.ss = ss
end
local function disarmSplitGuard()
    local ss = win.ss
    win.ss = nil
    if not valid(ss) then return end
    pcall(function()
        if ss:GetVisibility() == 0 then ss:SetVisibility(1) end
        ss:SetRenderScale(win.ssScale or { X = 1, Y = 1 })
    end)
end
local function disarmEscape()
    disarmSplitGuard()
    if valid(win.esc) then pcall(function() win.esc:RemoveFromParent() end) end
    win.esc, win.escArmed, win.escAt = nil, false, nil
end

local function closeWindow()
    disarmEscape()
    if win.searchMode then   -- give the keyboard/mouse back the way the game had it
        win.searchMode = false
        local p = win.p
        pcall(function()
            local wbl, ch = cls(WBL), p.MyPlayerCharacter
            if valid(ch) and ch.IsInventoryOpen and valid(ch.InventoryReference) then
                wbl:SetInputMode_GameAndUIEx(p, ch.InventoryReference, 0, true, false)   -- same call the game uses
                ch.InventoryReference:SetFocus()
            elseif valid(ch) and win.hookTickAt and os.clock() - win.hookTickAt < 1 then   -- in the world: back to playing
                wbl:SetInputMode_GameOnly(p, false)
                p.bShowMouseCursor = false
            end   -- main menu (no character / no world tick): leave its UI input and mouse as they are
        end)
    end
    if win.open and valid(win.root) then pcall(function() win.root:RemoveFromParent() end) end
    win.open = false
end

-- call only from the ExecuteInGameThread queue (builds widgets, loads icons)
local function openWindow(p, target, anchored)
    if not valid(win.root) then buildWindow(p) end
    win.view, win.stack, win.off = viewOf(target), {}, 0
    win.p, win.anchor = p, nil
    if anchored then
        local m = cls(WLL):GetMousePositionOnViewport(p)
        win.anchor = { X = m.X, Y = m.Y }
    end
    render()
    if not win.open then win.root:AddToViewport(500) end
    win.open = true
    pcall(armEscape, p)
    pcall(armSplitGuard, p)
    place()
    log("opened %s:%s (%d lines)", target.v, tostring(target.id), #win.view.lines)
end
local function queueOpen(p, target, anchored)
    ExecuteInGameThread(function()
        local ok, err = pcall(openWindow, p, target, anchored)
        if not ok then log("open error: %s", tostring(err)) end
    end)
end
onCtrlItem = function(p, id) queueOpen(p, { v = "info", id = id }, true) end

-- ---- item search (F2): a search page in the same window; results open the normal item pages
local SEARCH_KEY = "F2"
local searchNames
-- Candidate pool for a query, so most keystrokes check only a handful of names:
--  * typing more letters (q extends the last query): only the last query's matches can still match
--  * otherwise: a bigram index (every 2-letter pair -> names containing it); the rarest pair in q gives the pool
local searchLast, bigrams
local function searchPool(q)
    if searchLast and #q > #searchLast.q and q:sub(1, #searchLast.q) == searchLast.q then return searchLast.list end
    if #q < 2 then return searchNames end
    if not bigrams then
        bigrams = {}
        for _, e in ipairs(searchNames) do
            local seen = {}
            for i = 1, #e.l - 1 do
                local b = e.l:sub(i, i + 1)
                if not seen[b] then seen[b] = true; local t = bigrams[b] or {}; bigrams[b] = t; t[#t + 1] = e end
            end
        end
    end
    local best
    for i = 1, #q - 1 do
        local t = bigrams[q:sub(i, i + 1)]
        if not t then return {} end
        if not best or #t < #best then best = t end
    end
    return best or searchNames
end
local function buildSearchView(q)
    if not searchNames then
        searchNames = {}
        for k in pairs(D.items) do
            local n = nameOf(k)
            if n and n ~= k and not n:find("{") and (D.sources[k] or byResult[k] or usedIdx[k] or WIKI[n:lower()]) then
                searchNames[#searchNames + 1] = { id = k, n = n, l = n:lower() }
            end
        end
        table.sort(searchNames, function(a, b) return a.l < b.l end)
    end
    local v = { title = "Item search", lines = {}, search = true, q = q }
    q = (q or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    if q == "" then
        v.lines[1] = { text = "Type an item name above, then click a result to see what it is, how to make it, where to find it and what uses it.", plain = true }
        return v
    end
    local starts, has, seen = {}, {}, {}
    for _, e in ipairs(searchPool(q)) do
        if not seen[e.l] then
            local i = e.l:find(q, 1, true)
            if i then seen[e.l] = true; table.insert(i == 1 and starts or has, e) end
        end
    end
    local all = {}
    for _, e in ipairs(starts) do all[#all + 1] = e end
    for _, e in ipairs(has) do all[#all + 1] = e end
    searchLast = { q = q, list = all }
    -- the matching itself is ~1,600 string finds (well under 1 ms); the cost is building rows (vanilla donor
    -- widgets + icon loads), so only the best 25 are shown
    local CAP = 25
    v.lines[1] = { text = #all .. " result" .. (#all == 1 and "" or "s") .. (#all > CAP and (" (best " .. CAP .. " shown, keep typing to narrow)") or ""), head = true }
    v.key = q .. "|" .. #all
    for i = 1, math.min(CAP, #all) do
        v.lines[#v.lines + 1] = { text = all[i].n .. "  >", target = { v = "info", id = all[i].id } }
    end
    return v
end
-- fixed result rows: built once from donors (placed in our rooted tree right away, so they are never collected),
-- then each keystroke only changes text/icons/visibility - no widgets created while typing.
local SROWS = 25
local function ensureSearchRows(p)
    if win.srows then return end
    local pairs_ = donorPairs(p, SROWS + 1)
    win.shead = makeRow(win.tree, pairs_[1], "")
    win.sres:AddChildToVerticalBox(win.shead.box)
    setOp(win.shead, OP_DIM)
    win.srows = {}
    for i = 1, SROWS do
        local r = makeRow(win.tree, pairs_[i + 1], "")
        win.sres:AddChildToVerticalBox(r.box)
        r.box:SetVisibility(1)
        win.srows[i] = r
    end
end
win.iconQ = {}
WT_fillSearch = function(q)
    if not win.srows then return end
    local v = buildSearchView(q)
    v.lines[1].text = v.lines[1].text:gsub(" %(best 25 shown, keep typing to narrow%)", " (best 25 shown)")
    win.view.q, win.view.lines = q, v.lines
    win.shead.tb:SetText(FText(v.lines[1].text))
    win.iconQ = {}
    for i, r in ipairs(win.srows) do
        local l = v.lines[i + 1]
        r.line = l
        if l then
            r.tb:SetText(FText(l.text))
            local path = ICONS[l.target.id:lower()]
            local t = path and StaticFindObject(path)
            if valid(t) then
                r.img:SetBrushFromTexture(t, false); r.icon:SetVisibility(3); r.gap:SetVisibility(3)
            else
                r.icon:SetVisibility(1); r.gap:SetVisibility(1)
                if path then win.iconQ[#win.iconQ + 1] = r end
            end
            r.box:SetVisibility(0)
        else
            r.box:SetVisibility(1)
        end
    end
end
-- icons not loaded yet: a few per tick, loaded on the game-thread queue (never LoadAsset inside a hook)
local function drainIcons()
    if win.iconBusy or #win.iconQ == 0 then return end
    local batch = {}
    for i = 1, math.min(4, #win.iconQ) do batch[i] = table.remove(win.iconQ, 1) end
    win.iconBusy = true
    ExecuteInGameThread(function()
        for _, r in ipairs(batch) do
            pcall(function()
                if r.line then
                    local t = iconTex(r.line.target.id)
                    if t then r.img:SetBrushFromTexture(t, false); r.icon:SetVisibility(3); r.gap:SetVisibility(3) end
                end
            end)
        end
        win.iconBusy = false
    end)
end
local function searchTick()
    local ok, q = pcall(function() return win.search:GetText():ToString() end)
    if ok and q ~= win.lastQ then
        win.lastQ = q
        WT_fillSearch(q)   -- instant: text + icons only
    end
    drainIcons()
    for _, r in ipairs(win.srows or {}) do
        if r.line then
            setOp(r, hovered(r) and OP_HOVER or OP_NORMAL)
            if pressed(r) then
                win.stack[#win.stack + 1] = { view = win.view, off = 0 }
                win.view, win.off = viewOf(r.line.target), 0
                return "open"
            end
        end
    end
end
WT_searchTick = searchTick
local function openSearch(p)
    if not valid(p) then return end
    if not valid(win.root) then buildWindow(p) end
    win.view, win.stack, win.off = buildSearchView(""), {}, 0
    win.p, win.anchor = p, nil
    pcall(function() win.search:SetText(FText("")) end)
    win.lastQ, win.qAt = "", nil
    ensureSearchRows(p)
    render()
    if not win.open then win.root:AddToViewport(500) end
    win.open = true
    pcall(armSplitGuard, p)
    place()
    -- typing goes to our box only (no walking while you type); the mouse is shown for clicking results
    win.searchMode = true
    p.bShowMouseCursor = true
    pcall(function() cls(WBL):SetInputMode_UIOnlyEx(p, win.search, 0, false) end)
    pcall(function() win.search:SetKeyboardFocus() end)
    log("search opened")
    -- read the box every ~16 ms (the window tick we hook runs less often than every frame, which felt laggy);
    -- the check itself is queued onto the game thread and only touches our own text box
    if not win.searchLoop then
        -- game-thread loop (LoopAsync runs Lua off the game thread and can corrupt the Lua state)
        win.searchLoop = LoopInGameThreadWithDelay(16, function()
            if not (win.open and win.searchMode) then
                local h = win.searchLoop; win.searchLoop = nil
                if h then pcall(CancelDelayedAction, h) end
                return
            end
            -- main menu: the in-game tick we hook doesn't run there, so drive the window (clicks, Close) from here
            if (not win.hookTickAt or os.clock() - win.hookTickAt > 0.25) and WT_windowTick then
                local ok, err = pcall(WT_windowTick, true)
                if not ok then logOnce("wl" .. tostring(err), "window loop error: %s", tostring(err)) end
            end
            pcall(function()
                if win.open and win.view and win.view.search and valid(win.search) then
                    local q = win.search:GetText():ToString()
                    if q ~= win.lastQ then win.lastQ = q; WT_fillSearch(q) end
                end
            end)
        end)
    end
end
pcall(RegisterKeyBind, Key[SEARCH_KEY], function()
    ExecuteInGameThread(function()
        local ok, err = pcall(function()
            if win.open and win.searchMode then closeWindow() return end
            openSearch(FindFirstOf("Abiotic_PlayerController_C"))
        end)
        if not ok then log("search error: %s", tostring(err)) end
    end)
end)

-- render() adds widgets and may LoadAsset icons: never call it inside a hook (froze the game), only from the queue
local function later()
    ExecuteInGameThread(function()
        local t0 = os.clock()
        local ok, err = pcall(function() render(); place() end)
        log("render %d lines in %.0f ms", win.view and #win.view.lines or 0, (os.clock() - t0) * 1000)
        if not ok then log("render error: %s", tostring(err)) end
    end)
end

-- Escape closes the window (UE4SS key bind: runs off the game thread, so queue the close)
pcall(RegisterKeyBind, Key.ESCAPE, function()
    -- don't close here (removing the guard too early would let the game close its menus); windowTick closes
    -- when the guard is eaten, or after a few ticks if Escape went somewhere that doesn't call CloseBetaNotice
    if win.open then win.escAt = 0 end
end)

local function windowTick(fromLoop)
    if not fromLoop then win.hookTickAt = os.clock() end
    if not win.open then return end
    if not valid(win.root) then win.open = false return end
    if win.escArmed and not (valid(win.esc) and win.esc:IsInViewport()) then closeWindow() return end   -- Escape ate the guard
    if win.ss and (not valid(win.ss) or win.ss:GetVisibility() ~= 0) then closeWindow() return end   -- Escape hid the guard
    if win.view and win.view.search and valid(win.search) and WT_searchTick then
        if win.escAt then win.escAt = win.escAt + 1; if win.escAt > 3 then closeWindow() return end end
        if WT_searchTick() == "open" then later() end
        for _, r in ipairs({ win.back, win.close }) do setOp(r, hovered(r) and OP_HOVER or OP_NORMAL) end
        if pressed(win.close) then closeWindow() end
        return
    end
    if false then   -- (old debounced search, replaced by the instant fixed-row search above)
        local ok, q = pcall(function() return win.search:GetText():ToString() end)
        if ok and q ~= win.lastQ then win.lastQ, win.qAt = q, 0
        elseif win.qAt then
            win.qAt = win.qAt + 1
            if win.qAt >= 12 then
                win.qAt = nil
                local nv = buildSearchView(win.lastQ)
                local same = nv.key and win.view.key == nv.key   -- e.g. a trailing space: nothing to rebuild
                if not same then
                    for i = 2, #nv.lines do if nv.lines[i].target.id ~= (win.view.lines[i] and win.view.lines[i].target and win.view.lines[i].target.id) then same = false break end same = true end
                end
                if not same then win.view = nv; later() end
                return
            end
        end
    end
    if win.escAt then
        win.escAt = win.escAt + 1
        if win.escAt > 3 then closeWindow() return end
    end
    for _, r in ipairs(win.lineRows) do setOp(r, hovered(r) and OP_HOVER or OP_NORMAL) end
    for _, r in ipairs({ win.up, win.down, win.foot, win.back, win.close }) do setOp(r, hovered(r) and OP_HOVER or OP_NORMAL) end
    if pressed(win.close) then closeWindow() return end
    if pressed(win.up) then win.off = win.off - ROWS; later() return end
    if pressed(win.down) then win.off = win.off + ROWS; later() return end
    if pressed(win.foot) and win.view.footer then
        win.stack[#win.stack + 1] = { view = win.view, off = win.off }
        win.view, win.off = viewOf(win.view.footer.target), 0
        later()
        return
    end
    if pressed(win.back) and #win.stack > 0 then
        local prev = table.remove(win.stack)
        win.view, win.off = prev.view, prev.off
        later()
        return
    end
    for _, r in ipairs(win.lineRows) do
        if pressed(r) then
            win.stack[#win.stack + 1] = { view = win.view, off = win.off }
            win.view, win.off = viewOf(r.line.target), 0
            log("open %s:%s", r.line.target.v, tostring(r.line.target.id))
            later()
            return
        end
    end
end

-- the Recipes entry in the vanilla right-click menu -----------------------------------------------------------
local menus = {}   -- by menu address: { row, building }
local function menuTick(m)
    local addr = m:GetAddress()
    local s = menus[addr]
    if not s then
        s = { building = true }
        menus[addr] = s
        -- never add widgets inside a Slate Tick: build on the next game-thread turn
        ExecuteInGameThread(function()
            local ok, err = pcall(function()
                if not valid(m) then return end
                local r = makeRow(m.WidgetTree, donorPairs(owner(m), 1)[1], "Recipes")
                m.VerticalBox_126:AddChildToVerticalBox(r.box)
                s.row, s.building = r, false
            end)
            if not ok then log("menu build error: %s", tostring(err)) end
        end)
        return
    end
    if s.building or not s.row then return end
    setOp(s.row, hovered(s.row) and OP_HOVER or OP_NORMAL)
    if pressed(s.row) then
        local id = itemKey(m.ItemSlotStruct.ItemDataTable.RowName:ToString())
        local p = owner(m)
        ExecuteInGameThread(function()
            local ok, err = pcall(function()
                if valid(m) then pcall(function() m:CloseContextMenu(false) end) end
                openWindow(p, { v = "recipes", id = id }, false)
            end)
            if not ok then log("open error: %s", tostring(err)) end
        end)
    end
end

WT_windowTick = windowTick

-- hooks: registered on the game thread once the widget classes exist ----------------------------------------
local installed = false
local function guarded(tag, fn)
    return function(self)
        local ok, err = pcall(fn, self:get())
        if not ok then logOnce(tag .. tostring(err), "%s error: %s", tag, tostring(err)) end
    end
end
local function installHooks()
    if installed then return end
    if not valid(StaticFindObject(TOOLTIP)) then pcall(LoadAsset, TOOLTIP) end
    if not valid(StaticFindObject(CTXMENU)) then pcall(LoadAsset, CTXMENU) end
    if not valid(StaticFindObject(TOOLTIP)) or not valid(StaticFindObject(CTXMENU)) then return end
    installed = true
    RegisterHook(TOOLTIP .. ":Tick", guarded("tooltip", tipTick))
    RegisterHook(CTXMENU .. ":Tick", guarded("menu", menuTick))
    local ok, err = pcall(RegisterHook, WAYPOINT_TICK, function()
        local ok2, err2 = pcall(windowTick)
        if not ok2 then logOnce("win" .. tostring(err2), "window error: %s", tostring(err2)) end
    end)
    if not ok then log("window tick hook failed: %s", tostring(err)) end
    log("hooks installed")
end

if valid(StaticFindObject(TOOLTIP)) and valid(StaticFindObject(CTXMENU)) then installHooks() end
RegisterHook("/Script/Engine.PlayerController:ClientRestart", function()
    local ok, err = pcall(installHooks)
    if not ok then log("install error: %s", tostring(err)) end
    menus = {}
    closeWindow()
    win.root = nil -- rebuilt on next open
end)

log("v2 loaded: %d recipes, %d items with sources, %d wiki summaries", #D.recipes,
    (function() local n = 0 for _ in pairs(D.sources) do n = n + 1 end return n end)(),
    (function() local n = 0 for _ in pairs(WIKI) do n = n + 1 end return n end)())
