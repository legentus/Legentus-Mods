-- HitchProbe (temporary, 2026-11-20): logs every frame that takes over 50 ms, to find the lag when picking up items.
-- A 1 ms game-thread loop runs once per engine frame, so the time between two runs is one frame.
-- No hooks. Delete this folder once the lag is found.
local MOD = "[HitchProbe] "
local last, n = nil, 0
local worst, slow = 0, 0
local minuteAt = os.clock()
LoopInGameThreadWithDelay(1, function()
    local now = os.clock()
    if last then
        local ms = (now - last) * 1000
        if ms > 50 and ms < 10000 and n < 500 then n = n + 1; print(MOD .. string.format("hitch %.0f ms", ms) .. "\n") end
        if ms < 10000 then
            if ms > worst then worst = ms end
            if ms > 33 then slow = slow + 1 end
        end
    end
    last = now
    if now - minuteAt >= 60 then
        if slow > 0 then print(MOD .. string.format("last minute: %d frames over 33 ms, worst %.0f ms", slow, worst) .. "\n") end
        minuteAt, worst, slow = now, 0, 0
    end
end)
print(MOD .. "loaded\n")
