-- CheatMenu: F1 cheat menu built from Abiotic Factor's own UI widgets.
--   Unlimited Health   -> player's built-in Invincible flag
--   Unlimited Stamina  -> player's built-in InfiniteStamina flag
--   Drop Rate 1x-10x   -> repeats DropLoot calls (approach from ResourceMultiplier by PieKing1215, MIT)
-- Cheats apply on the host / in single player.

local MOD = "[CheatMenu] "
-- UE4SS's working directory is Binaries\Win64, so paths are relative to that
local SETTINGS_FILE = "ue4ss/Mods/CheatMenu/settings.txt"

local function log(fmt, ...) print(MOD .. string.format(fmt, ...) .. "\n") end

local function valid(o) return o ~= nil and o.IsValid ~= nil and o:IsValid() end

-- ---------------------------------------------------------------- settings
-- Layout values can be edited in settings.txt (restart the game to apply):
--   menuscale  = size multiplier for the whole menu (0.5 = half size)
--   menux/menuy = distance from the top-left corner of the screen, in pixels
--   maxheight  = tallest the cheat list may get (unscaled px) before it scrolls; 0 = no limit
local settings = { health = false, stamina = false, droprate = 1.0,
                   menuscale = 0.5, menux = 16, menuy = 16, maxheight = 600 }

local function num(v, lo, hi, default)
    local n = tonumber(v)
    if not n then return default end
    return math.max(lo, math.min(hi, n))
end

local function loadSettings()
    local f = io.open(SETTINGS_FILE, "r")
    if not f then return end
    for line in f:lines() do
        local k, v = line:match("^%s*(%w+)%s*=%s*(%S+)")
        if k == "health" or k == "stamina" then settings[k] = (v == "true")
        elseif k == "droprate" then settings.droprate = num(v, 1, 10, 1)
        elseif k == "menuscale" then settings.menuscale = num(v, 0.2, 2, 0.5)
        elseif k == "menux" then settings.menux = num(v, 0, 4000, 16)
        elseif k == "menuy" then settings.menuy = num(v, 0, 4000, 16)
        elseif k == "maxheight" then settings.maxheight = num(v, 0, 4000, 600) end
    end
    f:close()
end

local function saveSettings()
    local f = io.open(SETTINGS_FILE, "w")
    if not f then log("could not write %s", SETTINGS_FILE); return end
    f:write(string.format(
        "health=%s\nstamina=%s\ndroprate=%.2f\nmenuscale=%.2f\nmenux=%d\nmenuy=%d\nmaxheight=%d\n",
        tostring(settings.health), tostring(settings.stamina), settings.droprate,
        settings.menuscale, settings.menux, settings.menuy, settings.maxheight))
    f:close()
end

loadSettings()

-- ---------------------------------------------------------------- helpers
local function getPC()
    local pcs = FindAllOf("PlayerController")
    if not pcs then return nil end
    for _, pc in ipairs(pcs) do
        if valid(pc) and pc:IsLocalController() then return pc end
    end
    return nil
end

local function getPawn()
    local pc = getPC()
    if not valid(pc) then return nil end
    local pawn = pc.Pawn
    if valid(pawn) then return pawn end
    return nil
end

local classCache = {}
local function cls(path)
    local c = classCache[path]
    if valid(c) then return c end
    c = StaticFindObject(path)
    if not valid(c) then
        pcall(LoadAsset, path)
        c = StaticFindObject(path)
    end
    classCache[path] = c
    return c
end

local WBL_PATH = "/Script/UMG.Default__WidgetBlueprintLibrary"
local function wbl() return StaticFindObject(WBL_PATH) end

-- ---------------------------------------------------------------- cheats
local function applyPlayerCheats()
    local pawn = getPawn()
    if not pawn then return end
    -- only touch our own flags when we are the ones who turned them on, so the game's
    -- own cheat menu (or other mods) still work when ours is off
    if settings.health then pawn.Invincible = true end
    if settings.stamina then pawn.InfiniteStamina = true end
end

local function clearPlayerCheat(which)
    local pawn = getPawn()
    if not pawn then return end
    if which == "health" then pawn.Invincible = false end
    if which == "stamina" then pawn.InfiniteStamina = false end
end

-- keep flags applied (respawns, level loads, the game resetting them)
-- Game-thread timers only: LoopAsync/ExecuteWithDelay run Lua on UE4SS's async thread in the same Lua state as
-- our item-lookup hooks, which corrupted it and crashed the game (2026-11-12, host and a joining friend).
LoopInGameThreadWithDelay(500, function()
    if settings.health or settings.stamina then pcall(applyPlayerCheats) end
end)

-- ============================================================================ DROP RATE
-- How the game hands out items (reverse-engineered from the 1.5 blueprints):
--   * Every loot roll goes through Abiotic_Survival_GameMode_C:CalculateItemDrop(entry, ...,
--     DropSuccess&, ItemStruct&, Count&). Callers: GameMode.GenerateLootDrop (crates, desk items,
--     NPCs, corpses, farming, destroyed deployables...), Deployed_Container_ParentBP (container
--     contents), BenchUpgrade_MatterSynthesizer, and ItemFunctionLibrary.TryScrapItemInSlot (salvage).
--   * Each caller first looks up its drop list with the native
--     SalvageHandleFunctionLibrary.GetSalvageRow(RowHandle): real pre-hook (native).
--   * Salvage: Abiotic_PlayerCharacter.Server_TryScrapItem calls the native
--     GlobalItemHandleFunctionLibrary.GetGlobalItemRow(slot item), then
--     ItemFunctionLibrary.TryScrapItemInSlot, which calls GetSalvageRow(item.SalvageData) and rolls.
--     (UE4SS can't hook TryScrapItemInSlot itself: it's called on the library's default object.)
--     So "last item looked up whose SalvageData == the row being rolled" = the item being salvaged.
--   * The salvage preview in the UI reads DT_Salvage directly.
--
-- Rules (what the drop rate multiplies):
--   * Only crafting materials (recipe/upgrade ingredients), never ammo or one-of-a-kind items.
--   * Never anything rolled from a body (NPC kill loot, butchering).
--   * Salvaging a craftable item: vanilla. Salvaging a found-only item: multiplied.
--   * Salvage lists used ONLY by found-only items are scaled inside DT_Salvage itself, so the UI
--     preview shows the multiplied amounts. Lists shared with a craftable item stay vanilla in the
--     table; found-only items using them are multiplied at the roll instead.
local GAMEMODE = "/Game/Blueprints/Meta/Abiotic_Survival_GameMode.Abiotic_Survival_GameMode_C"
local DT_SALVAGE = "/Game/Blueprints/DataTables/DT_Salvage.DT_Salvage"
local PEN_LIST_ROLL = "resourcenode_penholder"
local DEBUG_DROPS = false  -- true = log each drop decision (debugging only)

local craftable = {}            -- item rows that have a recipe
local itemSalvageOf = {}        -- item row -> its salvage row
local itemSalvageRows = {}      -- salvage row -> true if any item uses it
local craftableSalvageRows = {} -- salvage row -> true if a craftable item uses it
local tableScaledRows = {}      -- salvage rows whose quantities we scaled in DT_Salvage
local singleItems = {}          -- item rows with StackSize 1 (never multiplied anywhere)
local materialItems = {}        -- crafting materials: the only items the drop rate multiplies
local materialsKnown = false    -- false if the recipe tables couldn't be read (then multiply nothing)
local currentSalvageRow = nil   -- salvage row being rolled right now
local lastItemRow = nil         -- last item row looked up via GetGlobalItemRow
local salvagedItem = nil        -- item being salvaged (when currentSalvageRow is its salvage row)
local firstSalvage = { item = nil, row = nil, t = -99, id = -1 }
local salvageLookupId = 0      -- +1 on every GetSalvageRow: a new salvage always starts with one   -- the first-time salvage in progress (see markSalvaged)

local bodyRows = {}              -- butchering lists (DT_NPCList GibInfo.GibSalvage)
local killRows = {}              -- kill loot lists (DT_NPCList PotentialLootWhenKilled)
local forEachRow
function isBodyRow(row)
    return bodyRows[row] or row:find("^gibbed_") ~= nil or row:find("^butcher_") ~= nil
end

-- Which situation a loot list belongs to. MUST match category() in editor/build_editor.py.
local function categoryOf(row)
    if not row then return "world" end
    if isBodyRow(row) then return "butchering" end
    if killRows[row] then return "kill" end
    if itemSalvageRows[row] then return "destroyed" end
    if row:find("^container_") then return "containers" end
    if row:find("^loot_fishtrash") then return "fishing" end
    if row:find("^harvest_") then return "farming" end
    return "world"
end

-- ---- per-item rules, part of the mod itself (Scripts\rules_data.txt).
-- Anthony picks items in his separate rules program, which exports a list; that list is used as
-- the reference to write this file. The program never talks to the mod.
-- Lines: category<TAB>item id<TAB>1|0. Items/categories not listed use the defaults below.
local RULES_FILE = "ue4ss/Mods/CheatMenu/Scripts/rules_data.txt"
local rules = nil
local function loadRules()
    local f = io.open(RULES_FILE, "r")
    if not f then log("drop rules: no rules_data.txt, using built-in defaults"); return end
    rules = {}
    local n = 0
    for line in f:lines() do
        local c, i, v = line:match("^([%w_]+)\t([^\t]+)\t([01])%s*$")
        if c then
            rules[c] = rules[c] or {}
            rules[c][i:lower()] = (v == "1")   -- FName text casing varies ("Pens" vs "pens"): match ignoring case
            n = n + 1
        end
    end
    f:close()
end

forEachRow = function(path, fn)
    pcall(LoadAsset, path)
    local dt = StaticFindObject(path)
    if not valid(dt) then return false end
    dt:ForEachRow(fn)
    return true
end

local function rowKey(rowName)
    if type(rowName) == "string" then return rowName end
    return rowName:ToString()
end

local function scaleCount(c)
    local scaled = c * settings.droprate
    local n = math.floor(scaled)
    if math.random() < (scaled - n) then n = n + 1 end
    return n
end

local function eligible(item)
    return materialsKnown and materialItems[item] and not singleItems[item]
end

-- Should `key` be multiplied in situation `cat`? The editor's file wins; otherwise the defaults
-- (same as the editor's starting checkboxes). For "salvaging" the key is the item being
-- salvaged; for every other category it's the item that drops.
local function shouldMultiply(cat, key)
    local r = rules and rules[cat]
    if r and r[key:lower()] ~= nil then return r[key:lower()] end
    if cat == "salvaging" then return not craftable[key] end
    if cat == "butchering" or cat == "destroyed" then return false end
    return eligible(key) and true or false
end

-- ---- first salvage of a craftable item (2026-11-19): the first time an item type is salvaged in a world, its
-- results are multiplied; every later salvage of that type gives the vanilla amount (so crafting then salvaging
-- can't farm materials). Host-side memory per world: ue4ss/Mods/CheatMenu/salvaged_<world>.txt (one item id per line).
local SALVAGED_DIR = "ue4ss/Mods/CheatMenu/"
local salvagedOnce, salvagedWorld = nil, nil
local function worldKey()
    local n = ""
    pcall(function()
        local gi = FindFirstOf("Abiotic_GameInstance_C")
        if valid(gi) then n = gi.ActiveWorldSaveName:ToString() end
    end)
    if n == "" then n = "default" end
    return (n:gsub("[^%w_%-]", "_"))
end
local function salvagedSet()
    local w = worldKey()
    if salvagedOnce and salvagedWorld == w then return salvagedOnce end
    salvagedOnce, salvagedWorld = {}, w
    local f = io.open(SALVAGED_DIR .. "salvaged_" .. w .. ".txt", "r")
    if f then
        for line in f:lines() do
            local id = line:match("^%s*(%S+)")
            if id then salvagedOnce[id] = true end
        end
        f:close()
    end
    return salvagedOnce
end
local function markSalvaged(item)
    local set = salvagedSet()
    if set[item] then return end
    set[item] = true
    local f = io.open(SALVAGED_DIR .. "salvaged_" .. salvagedWorld .. ".txt", "a")
    if f then f:write(item, "\n"); f:close() end
end
-- does salvaging `item` right now give multiplied results? (rules file wins; craftable = first time only)
local function salvageMultiplies(item)
    local r = rules and rules.salvaging
    if r and r[item:lower()] ~= nil then return r[item:lower()] end
    if craftable[item] then return not salvagedSet()[item] end
    return true
end

local ITEM_TABLES = { "Craftables", "Deployables", "Deployables_CraftingBenches", "Deployables_Small",
    "FoodAndGibs", "Gear", "Global", "Pets", "Pickups", "Plants", "Weapons" }
local RECIPE_TABLES = { "/Game/Blueprints/DataTables/DT_Recipes.DT_Recipes",
    "/Game/Blueprints/DataTables/DT_ChemistryRecipes.DT_ChemistryRecipes" }
local SUBSTITUTES = "/Game/Blueprints/Items/ItemTable_RecipeSubstitutes.ItemTable_RecipeSubstitutes"

-- ---- body loot (DT_NPCList kill loot + butchering, plus gibbed_*/butcher_* rows)
local function collectBodyRows()
    local n = 0
    local function add(name)
        if name and name ~= "None" and not bodyRows[name] then bodyRows[name] = true; n = n + 1 end
    end
    local nKill = 0
    pcall(forEachRow, "/Game/Blueprints/DataTables/DT_NPCList.DT_NPCList", function(_, row)
        pcall(function() add(row.GibInfo.GibSalvage.RowName:ToString()) end)
        pcall(function()
            row.PotentialLootWhenKilled:ForEach(function(_, h)
                local name = h:get().RowName:ToString()
                if name ~= "None" and not killRows[name] then killRows[name] = true; nKill = nKill + 1 end
            end)
        end)
    end)
end

-- ---- crafting materials (ingredients of recipes, chemistry, bench and item upgrades)
local function collectMaterials()
    local groups = {}
    pcall(forEachRow, SUBSTITUTES, function(rowName, row)
        local list = {}
        pcall(function() row.ItemsOfType:ForEach(function(_, h) list[#list + 1] = h:get().RowName:ToString() end) end)
        groups[rowKey(rowName)] = list
    end)
    local function addInputs(arr)
        pcall(function()
            arr:ForEach(function(_, inputRef)
                local input = inputRef:get()
                local name = input.Item.RowName:ToString()
                local tbl = 0
                pcall(function() tbl = input.Item.Table end)
                if tbl == 1 and groups[name] then
                    for _, m in ipairs(groups[name]) do materialItems[m] = true end
                elseif name ~= "None" then
                    materialItems[name] = true
                end
            end)
        end)
    end
    for _, path in ipairs(RECIPE_TABLES) do
        pcall(forEachRow, path, function(_, row) addInputs(row.RecipeItems) end)
    end
    pcall(forEachRow, "/Game/Blueprints/DataTables/DT_BenchUpgrades.DT_BenchUpgrades",
        function(_, row) addInputs(row.RequiredItems) end)
    pcall(forEachRow, "/Game/Blueprints/DataTables/DT_ItemUpgrades.DT_ItemUpgrades", function(_, row)
        pcall(function() row.Upgrades:ForEach(function(_, e) addInputs(e:get().RequiredItems) end) end)
    end)
    for name in pairs(materialItems) do   -- ammo never counts (every ammo row is ammo_*)
        if name:lower():find("^ammo_") then materialItems[name] = nil end
    end
    local n = 0
    for _ in pairs(materialItems) do n = n + 1 end
    return n
end

-- ---- items: recipes, salvage rows, stack sizes
local function collectItems()
    local nCraftable = 0
    for _, path in ipairs(RECIPE_TABLES) do
        pcall(forEachRow, path, function(_, row)
            local ok, item = pcall(function() return row.ItemToCreate.RowName:ToString() end)
            if ok and item and item ~= "None" and not craftable[item] then
                craftable[item] = true; nCraftable = nCraftable + 1
            end
        end)
    end
    local nSingle = 0
    for _, t in ipairs(ITEM_TABLES) do
        local path = "/Game/Blueprints/Items/ItemTable_" .. t .. ".ItemTable_" .. t
        local ok, err = pcall(forEachRow, path, function(rowName, row)
            local item = rowKey(rowName)
            local okT, st = pcall(function() return row.StackSize end)
            if okT and type(st) == "number" and st <= 1 and not singleItems[item] then
                singleItems[item] = true; nSingle = nSingle + 1
            end
            local okR, salvage = pcall(function() return row.SalvageData.RowName:ToString() end)
            if not okR or not salvage or salvage == "None" then return end
            itemSalvageOf[item] = salvage
            itemSalvageRows[salvage] = true
            if craftable[item] then craftableSalvageRows[salvage] = true end
        end)
        if not ok then log("could not read item table %s: %s", t, tostring(err)) end
    end
    return nCraftable
end

-- ---- scale DT_Salvage for salvage lists where EVERY item using the list is set to multiply
-- (so the salvage preview shows the real amounts). Mixed lists stay vanilla in the table and the
-- checked items are multiplied at the roll instead.
local salvageOriginals = {}   -- row -> { [index] = {min, max} } captured once
local function salvageListAllOn(row)
    local any = false
    for item, srow in pairs(itemSalvageOf) do
        if srow == row then
            any = true
            if not shouldMultiply("salvaging", item) then return false end
        end
    end
    return any
end

-- Vanilla amounts of every salvage list, captured once before we touch the table:
-- salvageEntries[row] = { {item=, min=, max=}, ... } in table order (used by the tooltip).
local salvageEntries = nil
local function captureSalvageEntries()
    if salvageEntries then return end
    salvageEntries = {}
    pcall(forEachRow, DT_SALVAGE, function(rowName, row)
        local list = {}
        row.SalvageDropItems:ForEach(function(_, e)
            local d = e:get()
            list[#list + 1] = { item = d.ItemDataTable.RowName:ToString(), min = d.QuantityMin, max = d.QuantityMax }
        end)
        salvageEntries[rowKey(rowName)] = list
    end)
end

-- The vanilla tooltip shows salvage results as icons only (it hard-codes a stack of 1 and hides
-- the number - see W_InventoryItemSlot_Tooltip.RefreshTooltipInformation). After it builds them,
-- write the real amount, including the drop-rate multiplier, into each icon's stack text.
local function amountLabel(min, max)
    if min == max then return "x" .. max end
    return min .. "-" .. max
end

local function decorateTooltip(tooltip)
    if not salvageEntries then return end
    local item = tooltip.ItemRowName:ToString()
    local row = itemSalvageOf[item]
    local list = row and salvageEntries[row]
    if not list then return end
    local mult = settings.droprate > 1.0 and salvageMultiplies(item)
    if DEBUG_DROPS and CheatMenu_LastTip ~= item then
        CheatMenu_LastTip = item
        log("tooltip: %s (list %s) multiplied=%s craftable=%s", item, row, tostring(mult), tostring(craftable[item] == true))
    end
    local box = tooltip.Hbox_SalvageItems
    local n = box:GetChildrenCount()
    for i = 0, n - 1 do
        local e = list[i + 1]
        local slot = box:GetChildAt(i)
        if e and valid(slot) then
            local min, max = e.min, e.max
            if mult and not singleItems[e.item] then
                min = math.floor(min * settings.droprate + 0.5)
                max = math.floor(max * settings.droprate + 0.5)
            end
            pcall(function()
                slot.StackText:SetText(FText(amountLabel(min, max)))
                slot.StackText:SetVisibility(3)   -- HitTestInvisible
            end)
        end
    end
end

-- The game does NOT read DT_Salvage values we write at runtime when it rolls (verified 2026-11-09:
-- the table said 3 per item but the roll gave 1), so salvage results are multiplied at the roll
-- (onCalculateItemDrop) and the tooltip shows the numbers via decorateTooltip. We only capture the
-- vanilla amounts here.
local function applySalvageTable()
    captureSalvageEntries()
end
-- Called when the cheat menu closes, so a changed drop rate updates the salvage table.
CheatMenu_ApplySalvageTable = function()
    applySalvageTable()
end

-- ---- the roll itself (post-hook: out params already hold the result)
local function onCalculateItemDrop(DropSuccess, ItemStruct, Count)
    if settings.droprate <= 1.0 then return end
    local okS, success = pcall(function() return DropSuccess:get() end)
    if okS and success == false then return end
    local c = Count:get()
    if type(c) ~= "number" or c <= 0 then return end
    local item = "?"
    pcall(function() item = ItemStruct:get().RowName:ToString() end)
    local row = currentSalvageRow
    local function keep(why)
        if item:lower() == "pens" then log("pens roll from %s kept at %d (%s)", tostring(row), c, why) end
        if DEBUG_DROPS then log("roll %s x%d kept (%s)", item, c, why) end
    end
    local penRoll = (item:lower() == "pens" or (row and row:lower() == PEN_LIST_ROLL))
    local cat, key
    if salvagedItem then
        cat, key = "salvaging", salvagedItem
        if singleItems[item] then return keep("one-of-a-kind result") end
        if row and tableScaledRows[row] then return keep("already scaled in salvage table " .. row) end
        -- one salvage = several rolls (one per result line) right after each other: the first roll of a
        -- never-salvaged craftable item marks it, and the rest of that same salvage still counts as first
        local now = os.clock()
        local sameSalvage = firstSalvage.id == salvageLookupId and firstSalvage.item == key and firstSalvage.row == row and (now - firstSalvage.t) < 0.25
        if sameSalvage then
            firstSalvage.t = now
        else
            local r = rules and rules.salvaging
            if r and r[key:lower()] ~= nil then
                if not r[key:lower()] then return keep("salvaging: " .. key .. " is set to normal") end
            elseif craftable[key] then
                if salvagedSet()[key] then return keep("salvaging: craftable " .. key .. " was already salvaged once in this world") end
                markSalvaged(key)
                firstSalvage.item, firstSalvage.row, firstSalvage.t, firstSalvage.id = key, row, now, salvageLookupId
                if DEBUG_DROPS then log("first salvage of craftable %s in this world: multiplied this time only", key) end
            end
        end
    else
        cat, key = categoryOf(row), item
        if row and tableScaledRows[row] then return keep("already scaled in salvage table " .. row) end
        if not shouldMultiply(cat, key) then return keep(cat .. ": " .. key .. " is set to normal") end
    end
    local n = scaleCount(c)
    if penRoll then log("pens roll from %s: %d -> %d (%s)", tostring(row), c, n, cat) end
    if n ~= c then
        Count:set(n)
        if DEBUG_DROPS then log("roll %s %d -> %d (%.1fx, %s: %s)", item, c, n, settings.droprate, cat, key) end
    end
end

-- Installed as early as possible (at startup): containers such as lockers roll their contents
-- while the level is loading. Falls back to the first in-world player spawn.
local dropHooksInstalled = false
local function handleRowName(h) return h:get().RowName:ToString() end
-- PROBE (pickup lag, 2026-11-20): how many item / salvage lookups pass through our Lua hooks; logged only when a
-- 100 ms window has a lot of them, and any drop roll slower than 3 ms. Remove once diagnosed.
local probe = { items = 0, salvage = 0 }
LoopInGameThreadWithDelay(100, function()
    if probe.items + probe.salvage >= 100 then log("PROBE lookups in ~100 ms: %d item, %d salvage", probe.items, probe.salvage) end
    probe.items, probe.salvage = 0, 0
end)
local function installDropHooks(when)
    if dropHooksInstalled then return end
    local ok, err = pcall(function()
        LoadAsset(GAMEMODE)
        RegisterHook(GAMEMODE .. ":CalculateItemDrop",
            function(self, ItemDropStruct, IgnoreTags, GameplayTags, ExtraLootChance, DropSuccess, ItemStruct, Count)
                local t0 = os.clock()
                local okM, errM = pcall(onCalculateItemDrop, DropSuccess, ItemStruct, Count)
                local ms = (os.clock() - t0) * 1000
                if ms > 3 then log("PROBE slow drop roll: %.1f ms", ms) end
                if not okM then log("drop roll failed: %s", tostring(errM)) end
            end)
        -- GenerateLootDrop is hooked by InstancedLoot now (one owner per BP function); the GetSalvageRow
        -- pre-hook below resets currentSalvageRow at the start of every roll anyway.
    end)
    if ok then
        dropHooksInstalled = true
    else
        log("drop rate hook failed (%s): %s", when, tostring(err))
        return
    end
    pcall(loadRules)
    pcall(collectItems)
    pcall(collectBodyRows)
    local okMat, nMat = pcall(collectMaterials)
    materialsKnown = okMat and type(nMat) == "number" and nMat > 0
    if not materialsKnown then log("crafting materials could not be read; drop rate will multiply nothing") end
    -- native lookups: real pre-hooks
    local okI, errI = pcall(function()
        RegisterHook("/Script/AbioticFactor.GlobalItemHandleFunctionLibrary:GetGlobalItemRow",
            function(self, RowHandle)
                probe.items = probe.items + 1
                local okN, name = pcall(handleRowName, RowHandle)
                if okN then lastItemRow = name end
            end)
    end)
    if not okI then log("item lookup hook failed: %s", tostring(errI)) end
    local okG, errG = pcall(function()
        RegisterHook("/Script/AbioticFactor.SalvageHandleFunctionLibrary:GetSalvageRow",
            function(self, RowHandle)
                probe.salvage = probe.salvage + 1
                local okN, name = pcall(handleRowName, RowHandle)
                currentSalvageRow = okN and name or nil
                salvagedItem = nil
                salvageLookupId = salvageLookupId + 1
                if currentSalvageRow and lastItemRow and itemSalvageOf[lastItemRow] == currentSalvageRow then
                    salvagedItem = lastItemRow
                end
            end)
    end)
    if not okG then log("salvage row hook failed: %s", tostring(errG)) end
    pcall(applySalvageTable)
    local okT, errT = pcall(function()
        local TOOLTIP = "/Game/Blueprints/Widgets/Inventory/W_InventoryItemSlot_Tooltip.W_InventoryItemSlot_Tooltip_C"
        LoadAsset(TOOLTIP)
        RegisterHook(TOOLTIP .. ":RefreshTooltipInformation", function(self)
            local okD, errD = pcall(decorateTooltip, self:get())
            if not okD and DEBUG_DROPS then log("tooltip amounts failed: %s", tostring(errD)) end
        end)
    end)
    if not okT then log("tooltip hook failed: %s", tostring(errT)) end
end

-- ---- pen holders (2026-11-19). Resource_MicroNode_PenHolder's DropRow is the plain item "pens" (GlobalItem), so
-- taking one hands out exactly 1 pen without any loot roll and the drop rate never saw it. DT_Salvage has a matching
-- list, resourcenode_penholder (1 pen), so we point each loaded pen holder at that list instead: the game then rolls
-- it through GenerateLootDrop -> CalculateItemDrop like the salt, phone or binder nodes, and the "world pens" rule
-- multiplies it. Field writes only (no spawning, no hook), game thread.
local PEN_NODE = "Resource_MicroNode_PenHolder_C"
local PEN_LIST = "resourcenode_penholder"
local penLast = ""            -- last status line logged (pen diagnostics are always on, but only log on change)
local penErrLogged = false
LoopInGameThreadWithDelay(2000, function()
    local ok, list = pcall(FindAllOf, PEN_NODE)
    if not ok then
        if not penErrLogged then penErrLogged = true; log("pen holders: FindAllOf failed: %s", tostring(list)) end
        return
    end
    local found, switched, already, other = 0, 0, 0, ""
    for _, n in ipairs(type(list) == "table" and list or {}) do
        local okN, errN = pcall(function()
            if not valid(n) then return end
            found = found + 1
            local dr = n.DropRow
            local t, r = dr.Table, dr.RowName:ToString()
            if t == 0 and r:lower() == "pens" then   -- the level/BP stores it as "Pens" (FNames ignore case, ToString does not)
                dr.Table = 1
                dr.RowName = FName(PEN_LIST)
                local t2, r2 = n.DropRow.Table, n.DropRow.RowName:ToString()
                if t2 == 1 and r2:lower() == PEN_LIST then switched = switched + 1
                else other = string.format("write did not stick (%s/%s)", tostring(t2), r2) end
            elseif t == 1 and r:lower() == PEN_LIST then
                already = already + 1
            else
                other = string.format("unexpected DropRow %s/%s", tostring(t), r)
            end
        end)
        if not okN and not penErrLogged then penErrLogged = true; log("pen holders: error reading a pen holder: %s", tostring(errN)) end
    end
    local line = string.format("pen holders: %d loaded, %d use the loot list %s%s", found, switched + already, PEN_LIST,
        other ~= "" and (" - " .. other) or "")
    if line ~= penLast then penLast = line; log("%s", line) end
end)

-- ---- poop (2026-11-15). Regular toilets give no item (Toilet_ParentBP only applies Buff_Toilet; the
-- minigame only lowers continence). Poop items come from the makeshift toilet's bucket (below) and from
-- bagging a Deployed_FloorPoop pile (player Server_PoopOnFloor, skinks): the pile's InteractWith_A eats 1 scrap_plastic, gives 1 ItemClass ("Feces") and
-- destroys the pile. Our post-hook sees that the pile is gone and adds droprate-1 more of the same item.
local POOP = "/Game/Blueprints/DeployedObjects/Misc/Deployed_FloorPoop.Deployed_FloorPoop_C"
local POOP_TAG = "CM_poop"
local function givePoop(pile, ch, row)
    if valid(pile) then return end            -- pile still there: not bagged (no plastic)
    if not valid(ch) then return end
    local extra = scaleCount(1) - 1
    if extra <= 0 then return end
    local g = FindFirstOf("Abiotic_Survival_GameMode_C")
    if not valid(g) then return end
    -- SpawnItem returns no actor: tag it via ConnectToBone (InstancedLoot only reads IL_ tags), find it,
    -- then let the dropped item's own InteractWith_A put it in the inventory (overflow stays on the floor)
    local p = ch:K2_GetActorLocation()
    g:SpawnItem({ Translation = { X = p.X, Y = p.Y, Z = p.Z }, Rotation = { X = 0, Y = 0, Z = 0, W = 1 },
                  Scale3D = { X = 1, Y = 1, Z = 1 } },
                { RowName = FName(row) }, extra, -1.0, true, true, nil, FName(POOP_TAG), 0, 0, {})
    for _, it in ipairs(FindAllOf("Abiotic_Item_Dropped_C") or {}) do
        if valid(it) and it.InitialAttachToBone:ToString() == POOP_TAG then
            it.InitialAttachToBone = FName("None")
            it:InteractWith_A(ch, nil)
            if DEBUG_DROPS then log("poop %s +%d (%.1fx)", row, extra, settings.droprate) end
            return
        end
    end
    log("poop: spawned %s x%d but could not find it to pick up", row, extra)
end

-- Makeshift toilet: Deployed_Toilet_Makeshift, on standing up after relieving >50% of max continence, calls
-- its child Deployed_Container_WasteBucket.AddWasteIntoBucket(1), which places that many WasteItemDataRow
-- ("feces") in the bucket inventory. We add droprate-1 more with a second call (deferred, guarded).
local BUCKET = "/Game/Blueprints/DeployedObjects/Furniture/Deployed_Container_WasteBucket.Deployed_Container_WasteBucket_C"
local inBucketAdd = false
local bucketHooked = false
local function installBucketHook(when)
    if bucketHooked then return end
    pcall(LoadAsset, BUCKET)
    local ok, err = pcall(function()
        RegisterHook(BUCKET .. ":AddWasteIntoBucket", function(self, StackAmount)
            if inBucketAdd or settings.droprate <= 1.0 then return end
            local okR, err2 = pcall(function()
                local bucket, n = self:get(), StackAmount:get()
                if not bucket:HasAuthority() or type(n) ~= "number" or n <= 0 then return end
                local extra = scaleCount(n) - n
                if extra <= 0 then return end
                ExecuteInGameThreadWithDelay(100, function()
                    if not valid(bucket) then return end
                    inBucketAdd = true
                    local okA, errA = pcall(function() bucket:AddWasteIntoBucket(extra) end)
                    inBucketAdd = false
                    if not okA then log("toilet bonus failed: %s", tostring(errA))
                    elseif DEBUG_DROPS then log("toilet bucket %d -> %d (%.1fx)", n, n + extra, settings.droprate) end
                end)
            end)
            if not okR then log("toilet hook failed: %s", tostring(err2)) end
        end)
    end)
    if ok then bucketHooked = true
    else log("toilet bucket hook failed (%s): %s", when, tostring(err)) end
end

local poopHooked = false
local function installPoopHook(when)
    installBucketHook(when)
    if poopHooked then return end
    pcall(LoadAsset, POOP)
    local ok, err = pcall(function()
        RegisterHook(POOP .. ":InteractWith_A", function(self, InteractingCharacter, ComponentUsed)
            if settings.droprate <= 1.0 then return end
            local okR, err2 = pcall(function()
                local pile, ch = self:get(), InteractingCharacter:get()
                if not pile:HasAuthority() then return end
                local row = pile.ItemClass.RowName:ToString()
                -- never spawn inside a Blueprint hook (UE4SS loader deadlock): defer
                ExecuteInGameThreadWithDelay(100, function()
                    local okG, errG = pcall(givePoop, pile, ch, row)
                    if not okG then log("poop bonus failed: %s", tostring(errG)) end
                end)
            end)
            if not okR then log("poop hook failed: %s", tostring(err2)) end
        end)
    end)
    if ok then poopHooked = true
    else log("poop hook failed (%s): %s", when, tostring(err)) end
end

ExecuteInGameThread(function() installDropHooks("startup"); installPoopHook("startup") end)

-- ---------------------------------------------------------------- UI
local ESlateVisibility = { Visible = 0, Collapsed = 1, Hidden = 2, HitTestInvisible = 3, SelfHitTestInvisible = 4 }

local W = {
    UserWidget  = "/Script/UMG.UserWidget",
    WidgetTree  = "/Script/UMG.WidgetTree",
    Canvas      = "/Script/UMG.CanvasPanel",
    Border      = "/Script/UMG.Border",
    VBox        = "/Script/UMG.VerticalBox",
    TextBlock   = "/Script/UMG.TextBlock",
    Title       = "/Game/Blueprints/Widgets/MenuSystem/W_MenuTitleBig.W_MenuTitleBig_C",
    -- NOTE: W_GameCommand / W_GameCommandEntry_* widgets crash the game without a GameCommands row, and
    -- W_Settings_Boolean's checkbox has no style outside the settings page; don't use them.
    -- W_MainMenuButton renders blank and huge inside a row, so toggles use a plain CheckBox.
    CheckBox    = "/Script/UMG.CheckBox",
    SizeBox     = "/Script/UMG.SizeBox",
    ScrollBox   = "/Script/UMG.ScrollBox",
    Slider      = "/Game/Blueprints/Widgets/MenuSystem/Settings_Buttons/W_Settings_SliderBar.W_Settings_SliderBar_C",
}

local menu = nil        -- root UserWidget
local controls = {}     -- { health = CheckBox, stamina = CheckBox, droprate = SpinBox }
local rows = {}         -- { {row=W_GameCommand, title=, desc=} } texts re-applied after Construct
local menuOpen = false
-- widgets can't be built until the engine has finished starting and a player exists;
-- set by the ClientRestart hook (fires at the main menu and on every level load)
local gameReady = false
local controlsReady = false  -- true once controls show our settings; until then don't read them

local function construct(path, outer, name)
    return StaticConstructObject(cls(path), outer, FName(name))
end

-- Nothing in the game holds a UPROPERTY reference to widgets we create from Lua, so Unreal's
-- garbage collector frees them while they're still on screen (crash in SObjectWidget::OnPaint).
-- Construct the root with the RootSet internal flag so it (and everything under it) stays alive.
local ROOTSET = (EInternalObjectFlags and EInternalObjectFlags.RootSet) or 0x40000000
local RF_NoFlags = 0

local function constructRooted(path, outer, name)
    return StaticConstructObject(cls(path), outer, FName(name), RF_NoFlags, ROOTSET)
end

local function createGameWidget(path, pc)
    return wbl():Create(pc, cls(path), pc)
end

-- Rows are built from plain UMG pieces styled like the game's command rows (dark panel,
-- yellow title, the game's TeX Gyre Adventor font). The game's own W_GameCommand row is
-- backed by native code that expects a DT_GameCommands row and destabilises the renderer.
local FONT_PATH = "/Game/Blueprints/Widgets/Fonts/texgyreadventor_Font.texgyreadventor_Font"
local YELLOW = { SpecifiedColor = { R = 1.0, G = 0.92, B = 0.5, A = 1.0 }, ColorUseRule = 0 }

local function gameFont(size)
    local f = cls(FONT_PATH)
    return {
        FontObject = f,
        TypefaceFontName = FName("Default"),
        Size = size,
        LetterSpacing = 0,
        SkewAmount = 0.0,
        bForceMonospaced = false,
        bMaterialIsStencil = false,
        MonospacedWidth = 1.0,
    }
end

local function makeText(tree, name, text, size)
    local tb = construct(W.TextBlock, tree, name)
    -- Only set plain fields: passing whole Slate structs (FSlateFontInfo, FSlateColor) from Lua
    -- tables corrupted memory under UE4SS 3.0.1 and crashed the game.
    tb:SetText(FText(text))
    return tb
end

local rowCount = 0
local function addRow(tree, vbox, title, desc, contentWidget)
    rowCount = rowCount + 1
    local panel = construct(W.Border, tree, "CheatMenu_Row" .. rowCount)
    panel:SetBrushColor({ R = 0.16, G = 0.16, B = 0.16, A = 1.0 })
    panel:SetPadding({ Left = 10, Top = 6, Right = 10, Bottom = 8 })
    local inner = construct(W.VBox, tree, "CheatMenu_RowBox" .. rowCount)
    panel:SetContent(inner)
    inner:AddChildToVerticalBox(makeText(tree, "CheatMenu_RowTitle" .. rowCount, title, 22))
    inner:AddChildToVerticalBox(makeText(tree, "CheatMenu_RowDesc" .. rowCount, desc, 13))
    local cslot = inner:AddChildToVerticalBox(contentWidget)
    pcall(function() cslot:SetPadding({ Left = 0, Top = 6, Right = 0, Bottom = 0 }) end)
    local slot = vbox:AddChildToVerticalBox(panel)
    pcall(function() slot:SetPadding({ Left = 0, Top = 0, Right = 0, Bottom = 6 }) end)
end

local function applyRowTexts() end

local function syncControlsFromSettings()
    pcall(function() controls.health:SetIsChecked(settings.health) end)
    pcall(function() controls.stamina:SetIsChecked(settings.stamina) end)
    pcall(function()
        local s = controls.droprate
        s:SetMinValue(1.0); s:SetMaxValue(10.0)
        s:SetMinSliderValue(1.0); s:SetMaxSliderValue(10.0)
        s:SetDelta(0.5)
        s:SetValue(settings.droprate)
    end)
end

-- plain UMG checkbox (engine style), scaled up and tinted to match the game's teal slider
local function makeCheckBox(tree, name)
    return construct(W.CheckBox, tree, name)
end

local menuCount = 0

local function buildMenu(pc)
    rows, controls = {}, {}
    local gi = FindFirstOf("GameInstance")
    menuCount = menuCount + 1
    local root = constructRooted(W.UserWidget, gi, "CheatMenu_Root" .. menuCount)
    root.WidgetTree = construct(W.WidgetTree, root, "CheatMenu_Tree")
    local tree = root.WidgetTree

    local canvas = construct(W.Canvas, tree, "CheatMenu_Canvas")
    tree.RootWidget = canvas

    local border = construct(W.Border, tree, "CheatMenu_Border")
    border:SetBrushColor({ R = 0.02, G = 0.025, B = 0.03, A = 0.92 })
    border:SetPadding({ Left = 24, Top = 16, Right = 24, Bottom = 20 })
    -- pinned to the top-left corner
    local cslot = canvas:AddChildToCanvas(border)
    cslot:SetAutoSize(true)
    cslot:SetAnchors({ Minimum = { X = 0, Y = 0 }, Maximum = { X = 0, Y = 0 } })
    cslot:SetAlignment({ X = 0, Y = 0 })
    cslot:SetPosition({ X = settings.menux, Y = settings.menuy })
    -- shrink the whole menu around its top-left corner (mouse clicks follow the scaling)
    pcall(function() border:SetRenderTransformPivot({ X = 0, Y = 0 }) end)
    pcall(function() border:SetRenderScale({ X = settings.menuscale, Y = settings.menuscale }) end)

    -- layout: title stays put; the cheat list below it scrolls once it's taller than maxheight
    local outer = construct(W.VBox, tree, "CheatMenu_Outer")
    border:SetContent(outer)

    local title = createGameWidget(W.Title, pc)
    if valid(title) then
        pcall(function() title.TitleText = FText("CHEAT MENU") end)
        outer:AddChildToVerticalBox(title)
    end

    local sizer = construct(W.SizeBox, tree, "CheatMenu_Sizer")
    if settings.maxheight > 0 then pcall(function() sizer:SetMaxDesiredHeight(settings.maxheight) end) end
    outer:AddChildToVerticalBox(sizer)
    local scroll = construct(W.ScrollBox, tree, "CheatMenu_Scroll")
    pcall(function() scroll:SetAlwaysShowScrollbar(false) end)
    sizer:SetContent(scroll)
    local vbox = construct(W.VBox, tree, "CheatMenu_List")
    scroll:AddChild(vbox)

    controls.health = makeCheckBox(tree, "CheatMenu_Health")
    addRow(tree, vbox, "Unlimited Health", "You take no damage.", controls.health)

    controls.stamina = makeCheckBox(tree, "CheatMenu_Stamina")
    addRow(tree, vbox, "Unlimited Stamina", "Sprinting, jumping and swinging never tire you.", controls.stamina)

    local dr = createGameWidget(W.Slider, pc)
    controls.droprate = dr.SettingSpinBox
    addRow(tree, vbox, "Drop Rate", "Multiplies loot from containers, NPCs, corpses and poop (1x to 10x).", dr)

    return root
end

-- Input: remember how the game had the mouse set up before we opened, and put it back
-- exactly on close. At the main menu (or in any game menu) the cursor is already visible and
-- UI input must stay on; forcing GameOnly there is what loses the mouse.
-- If a game menu already has the cursor (main menu, pause, inventory) we leave input alone.
-- Only during normal gameplay do we switch to UI input and switch back on close.
-- (Never pass nil widgets to SetInputMode_*: UE4SS doesn't turn nil into nullptr reliably.)
local weChangedInput = false

local function setInputForMenu(pc, open)
    local lib = wbl()
    if open then
        weChangedInput = false
        if pc.bShowMouseCursor then return end
        weChangedInput = true
        pcall(function() lib:SetInputMode_GameAndUIEx(pc, menu, 0, false) end)
        pc.bShowMouseCursor = true
        pcall(function() pc:SetIgnoreLookInput(true) end)   -- keep the camera still
    elseif weChangedInput then
        weChangedInput = false
        pcall(function() pc:ResetIgnoreLookInput() end)
        pcall(function() lib:SetInputMode_GameOnly(pc, true) end)
        pc.bShowMouseCursor = false
    end
end

local function openMenu()
    local pc = getPC()
    if not valid(pc) then log("no local player controller yet"); return end
    if not gameReady then log("game still starting, F1 ignored"); return end
    if not valid(menu) then
        local ok, res = pcall(buildMenu, pc)
        if not ok or not valid(res) then log("failed to build menu: %s", tostring(res)); return end
        local added, err = pcall(function() res:AddToViewport(500) end)
        if not added then
            log("could not show menu yet: %s", tostring(err))
            pcall(function() res:RemoveFromParent() end)
            return
        end
        menu = res
    else
        local shown = pcall(function() menu:SetVisibility(ESlateVisibility.Visible) end)
        if not shown then menu = nil; return end
    end
    menuOpen = true
    controlsReady = false
    -- widgets run Construct when they're shown; set our texts/values right after that,
    -- twice, in case a widget's own Construct/Tick resets its value a frame later
    for _, delay in ipairs({ 50, 300 }) do
        ExecuteInGameThreadWithDelay(delay, function()
            applyRowTexts()
            syncControlsFromSettings()
            if delay == 300 then controlsReady = true end
        end)
    end
    setInputForMenu(pc, true)
end

local function closeMenu()
    if valid(menu) then pcall(function() menu:SetVisibility(ESlateVisibility.Collapsed) end) end
    menuOpen = false
    controlsReady = false
    local pc = getPC()
    if valid(pc) then setInputForMenu(pc, false) end
    saveSettings()
    -- drop rate may have changed: rescale the salvage table so the salvage preview stays right
    if CheatMenu_ApplySalvageTable then pcall(CheatMenu_ApplySalvageTable) end
end

-- read the controls while the menu is open (avoids binding UMG delegates from Lua)
LoopInGameThreadWithDelay(150, function()
    if not menuOpen or not controlsReady then return end
    pcall(function()
        if not valid(menu) then menuOpen = false; return end
        if not controlsReady then return end
        for _, which in ipairs({ "health", "stamina" }) do
            local ok, on = pcall(function() return controls[which]:IsChecked() end)
            if ok and type(on) == "boolean" and on ~= settings[which] then
                settings[which] = on
                if on then applyPlayerCheats() else clearPlayerCheat(which) end
            end
        end
        local ok, d = pcall(function() return controls.droprate:GetValue() end)
        if ok and type(d) == "number" then
            d = math.max(1.0, math.min(10.0, d))
            if math.abs(d - settings.droprate) > 0.001 then
                settings.droprate = d
            end
        end
    end)
    return false
end)

local okMK, MK = pcall(require, "ModKeys")   -- shared keybinds (F4 menu); falls back to the default key without it
local lastF1 = 0
local function toggleMenu()
    local now = os.clock()
    if now - lastF1 < 0.3 then return end   -- ignore key repeat / double taps
    lastF1 = now
    if menuOpen then closeMenu() else openMenu() end
end
if okMK then MK.bind("CheatMenu.open", "Cheat Menu", "Open / close the cheat menu", "F1", toggleMenu)
else RegisterKeyBind(Key.F1, function() ExecuteInGameThread(toggleMenu) end) end

-- A new level (or the main menu finishing loading) gives us a fresh player controller.
-- Our old widget is gone with the old world, so forget it and rebuild on the next F1.
local function onNewPlayer()
    if valid(menu) then pcall(function() menu:RemoveFromParent() end) end
    menu = nil
    menuOpen = false
    controlsReady = false
    weChangedInput = false
    gameReady = false
    ExecuteInGameThreadWithDelay(2000, function()
        gameReady = true
        pcall(function()
            local inWorld = false
            pcall(function()
                local pc = getPC()
                inWorld = valid(pc) and not pc:GetWorld():GetFullName():find("MainMenu")
            end)
            if inWorld then installDropHooks("in world"); installPoopHook("in world") end
        end)
    end)
end

RegisterHook("/Script/Engine.PlayerController:ClientRestart", onNewPlayer)
-- fallback in case ClientRestart already fired before this mod loaded
ExecuteInGameThreadWithDelay(30000, function() gameReady = true end)

log("loaded (F1 opens the menu). health=%s stamina=%s droprate=%.1fx",
    tostring(settings.health), tostring(settings.stamina), settings.droprate)
