-- AuxGearWheel v2 (Auxiliary Gear Wheel Mod)
-- Hold CAPS LOCK: the game's own radial item wheel opens with every Full Body Suit you carry (backpack + hotbar)
-- plus the one you are wearing. Move the mouse to a suit and let go of Caps Lock:
--   * a suit you are not wearing is equipped (the one you wore goes back into its slot, vanilla swap),
--   * the suit you are wearing is unequipped into your inventory.
--   v2: suits go back to the hotbar/backpack slot they were equipped from (remembered in origins.txt) when that
--   slot is free, also when swapping one suit for another; otherwise the game's quick-move places them. If the
--   inventory is full the suit stays on and an "Inventory full" popup shows.
--   Move to a slot = Player.Request_TrySwapItems(equipInv, suitSlot, inv, slot) (the drag-and-drop swap).
-- The worn suit is tinted green on the wheel, has an EQUIPPED tag under it, and the centre text says it will be
-- unequipped. A quick tap of Caps Lock (shorter than mintap ms) does nothing.
--
-- How it works (from the game's blueprints, see AuxGearWheel\NOTES.md):
--  * Wheel = W_RadialWheel_Flashlights_C, opened with the vanilla Player.EnterRadialWheel(class) and closed with
--    Player.TryCloseRadialWheel(false, class) (no commit, so the flashlight wheel's own action never runs).
--    Its "Get Wheel Data" works for ANY item row (item icon + ItemName), so only the entry list is swapped:
--    a post-hook on its "Get Wheel Categories" writes our suit rows into the EntryList out-param and sets the
--    segment count. Our hooks only act on the wheel WE opened; the vanilla flashlight wheel is untouched.
--  * Equip   = Player.Request_TryQuickMoveItem(sourceInventory, player, slot, EquippingGear=true, nil, false, false)
--              (same call as the inventory's right-click "Equip"; server side swaps with the worn suit).
--  * Unequip = Player.Request_TryQuickMoveItem(CharacterEquipSlotInventory, player, suitSlot, false, nil, false, false)
--              (same call as shift-clicking the worn suit).
-- Hooks owned by this mod (no other mod may hook these, see project notes on UE4SS crashes):
--    W_RadialWheel_Flashlights_C:Get Wheel Categories, W_RadialWheel_Flashlights_C:SelectionChanged
-- Timers: game-thread only (LoopInGameThreadWithDelay). No RegisterKeyBind (its callback runs off the game thread);
-- the key is polled with PlayerController:IsInputKeyDown on the game thread instead.

local MOD = "[AuxGearWheel] "
local function log(fmt, ...) print(MOD .. string.format(fmt, ...) .. "\n") end
local function valid(o) return o ~= nil and o.IsValid ~= nil and o:IsValid() end

-- ---------------------------------------------------------------- settings (Mods\AuxGearWheel\settings.txt)
local SETTINGS_FILE = "ue4ss/Mods/AuxGearWheel/settings.txt"
local settings = { key = "CapsLock", mintap = 150, poll = 30, badge = true, badgescale = 0.5, badgey = 34, debug = true }
do
    local f = io.open(SETTINGS_FILE, "r")
    if f then
        for line in f:lines() do
            local k, v = line:match("^%s*(%w+)%s*=%s*(%S+)")
            if k and settings[k] ~= nil then
                if type(settings[k]) == "boolean" then settings[k] = (v == "true" or v == "1")
                elseif type(settings[k]) == "number" then settings[k] = tonumber(v) or settings[k]
                else settings[k] = v end
            end
        end
        f:close()
    end
end
local function dbg(fmt, ...) if settings.debug then log(fmt, ...) end end

-- ---------------------------------------------------------------- timers (game thread only)
local function gtLoop(ms, fn)
    local h
    local ok, res = pcall(LoopInGameThreadWithDelay, ms, function()
        local ok2, stop = pcall(fn)
        if not ok2 then log("loop: %s", tostring(stop)); stop = false end
        if stop and h then pcall(CancelDelayedAction, h) end
    end)
    if ok then h = res else log("LoopInGameThreadWithDelay unavailable: %s", tostring(res)) end
    return ok
end

-- ---------------------------------------------------------------- game paths / data
local WHEEL_PKG  = "/Game/Blueprints/Widgets/TextChat/W_RadialWheel_Flashlights"
local WHEEL_CLS  = WHEEL_PKG .. ".W_RadialWheel_Flashlights_C"
local HOOK_CATS  = WHEEL_CLS .. ":Get Wheel Categories"
local HOOK_SEL   = WHEEL_CLS .. ":SelectionChanged"
local PLAYER_CLS = "/Game/Blueprints/Characters/Abiotic_PlayerCharacter.Abiotic_PlayerCharacter_C"
local TEXTBLOCK  = "/Script/UMG.TextBlock"
-- Every item with EquipSlot = EquipmentSlot_Suit (ItemTable_Gear / ItemTable_Global, 2026-11-11). Any other row
-- starting with "suit_" (future updates) is treated as a suit too.
local SUITS = {
    suit_hazmat = true, suit_fire = true, suit_powerC = true, suit_rebreather = true, suit_ratsuit = true,
    suit_beekeeper = true, suit_sappersuit = true, suit_mgt_larva = true, suit_highinquisitor = true,
}
local SUIT_ORDER = {}
for i, r in ipairs({ "suit_hazmat", "suit_fire", "suit_powerC", "suit_rebreather", "suit_ratsuit", "suit_beekeeper",
    "suit_sappersuit", "suit_mgt_larva", "suit_highinquisitor" }) do SUIT_ORDER[r] = i end
local function isSuit(row) return row ~= nil and (SUITS[row] or row:sub(1, 5) == "suit_") end
local SUIT_SLOT = 5   -- ItemFunctionLibrary.SlotTypeToIndex(EquipmentSlot_Suit = 8) = 8 - 3

local GREEN       = { R = 0.35, G = 1.0, B = 0.45, A = 1.0 }
local GREEN_DIM   = { R = 0.30, G = 0.85, B = 0.40, A = 0.85 }

local LOADTAG = string.format("%x%04x", os.time() % 0xFFFFFF, math.random(0, 0xFFFF))
local seq = 0
local function addr(o) return valid(o) and o:GetAddress() or 0 end
local function rowOf(slot)
    local ok, r = pcall(function() return slot.ItemDataTable.RowName:ToString() end)
    if ok and r and r ~= "" and r ~= "None" then return r end
    return nil
end

local cachedPC
local function getPC()
    if cachedPC and valid(cachedPC) then return cachedPC end
    cachedPC = nil
    local pcs = FindAllOf("PlayerController")
    if not pcs then return nil end
    for _, pc in ipairs(pcs) do
        if valid(pc) then
            local ok, isLocal = pcall(function() return pc:IsLocalController() end)
            if ok and isLocal then cachedPC = pc; return pc end
        end
    end
    return nil
end
local function keyDown(pc, name)
    local ok, v = pcall(function() return pc:IsInputKeyDown({ KeyName = FName(name) }) end)
    return ok and v == true
end

-- ---------------------------------------------------------------- state
local S = {
    open = false, opening = false, w = nil, wAddr = 0, p = nil, list = {}, ticks = 0, wasDown = false,
    entryColor = nil, cls = nil,
}

local function wheelClass()
    if valid(S.cls) then return S.cls end
    local c = StaticFindObject(WHEEL_CLS)
    if not valid(c) then
        pcall(function() LoadAsset(WHEEL_PKG) end)
        c = StaticFindObject(WHEEL_CLS)
    end
    S.cls = valid(c) and c or nil
    return S.cls
end

local function isOurs(w) return S.opening or (S.open and addr(w) == S.wAddr) end

-- Every suit the player carries (hotbar + backpack) and the worn one, one entry per item row.
local function collectSuits(p)
    local list, seen = {}, {}
    local eq = p.CharacterEquipSlotInventory
    if valid(eq) then
        local inv = eq.CurrentInventory
        for i = 1, #inv do
            local r = rowOf(inv[i])
            if isSuit(r) and not seen[r] then
                seen[r] = true
                list[#list + 1] = { row = r, equipped = true, inv = eq, idx = i - 1 }
            end
        end
    end
    for _, comp in ipairs({ p.CharacterHotbarInventory, p.CharacterInventory }) do
        if valid(comp) then
            local inv = comp.CurrentInventory
            for i = 1, #inv do
                local r = rowOf(inv[i])
                if isSuit(r) and not seen[r] then
                    seen[r] = true
                    list[#list + 1] = { row = r, equipped = false, inv = comp, idx = i - 1 }
                end
            end
        end
    end
    -- every suit has a fixed place on the wheel, worn or not: game data order, unknown suits after (A-Z)
    table.sort(list, function(a, b)
        local ra, rb = SUIT_ORDER[a.row] or 1000, SUIT_ORDER[b.row] or 1000
        if ra ~= rb then return ra < rb end
        return a.row < b.row
    end)
    return list
end

-- Where is this suit row right now? (inventories can change while the wheel is open)
local function locate(p, row, equipped)
    local comps = equipped and { p.CharacterEquipSlotInventory } or { p.CharacterHotbarInventory, p.CharacterInventory }
    for _, comp in ipairs(comps) do
        if valid(comp) then
            local inv = comp.CurrentInventory
            for i = 1, #inv do
                if rowOf(inv[i]) == row then return comp, i - 1 end
            end
        end
    end
    return nil
end

local function quickMove(p, comp, idx, equip)
    dbg("Request_TryQuickMoveItem(%s, slot %d, equip=%s)", comp:GetFName():ToString(), idx, tostring(equip))
    local ok, err = pcall(function() p:Request_TryQuickMoveItem(comp, p, idx, equip, nil, false, false) end)
    if not ok then
        dbg("quick move with nil container failed (%s), retrying with an invalid object", tostring(err))
        ok, err = pcall(function() p:Request_TryQuickMoveItem(comp, p, idx, equip, CreateInvalidObject(), false, false) end)
    end
    if not ok then log("quick move failed: %s", tostring(err)) end
end

-- ---------------------------------------------------------------- original inventory slots of suits
-- When the wheel equips a suit, the hotbar/backpack slot it came from is remembered (per item row, saved in
-- Mods\AuxGearWheel\origins.txt). Taking the suit off (or swapping it for another) puts it back there if that
-- slot is empty; otherwise the game's normal quick-move decides.
local ORIGINS_FILE = "ue4ss/Mods/AuxGearWheel/origins.txt"
local origins = {}   -- row -> { where = "hotbar" | "backpack", idx = 0-based slot }
do
    local f = io.open(ORIGINS_FILE, "r")
    if f then
        for line in f:lines() do
            local r, wh, i = line:match("^%s*(%S+)%s+(%a+)%s+(%d+)")
            if r and (wh == "hotbar" or wh == "backpack") then origins[r] = { where = wh, idx = tonumber(i) } end
        end
        f:close()
    end
end
local function saveOrigins()
    local rows = {}
    for r, o in pairs(origins) do rows[#rows + 1] = string.format("%s %s %d", r, o.where, o.idx) end
    table.sort(rows)
    local f = io.open(ORIGINS_FILE, "w")
    if not f then log("could not write %s", ORIGINS_FILE); return end
    f:write(table.concat(rows, "\n"), #rows > 0 and "\n" or "")
    f:close()
end
local function whereOf(p, comp)
    if addr(comp) == addr(p.CharacterHotbarInventory) then return "hotbar" end
    if addr(comp) == addr(p.CharacterInventory) then return "backpack" end
    return nil
end
local function compOf(p, where)
    if where == "hotbar" then return p.CharacterHotbarInventory end
    if where == "backpack" then return p.CharacterInventory end
    return nil
end
local function slotEmpty(comp, idx)
    if not valid(comp) then return false end
    local inv = comp.CurrentInventory
    if idx < 0 or idx >= #inv then return false end
    return rowOf(inv[idx + 1]) == nil
end
-- the remembered slot for this row, if it is free right now
local function freeOrigin(p, row)
    local o = origins[row]
    if not o then return nil end
    local comp = compOf(p, o.where)
    if slotEmpty(comp, o.idx) then return comp, o.idx end
    return nil
end
local function hasFreeSlot(p)
    for _, comp in ipairs({ p.CharacterInventory, p.CharacterHotbarInventory }) do
        if valid(comp) then
            local inv = comp.CurrentInventory
            for i = 1, #inv do if rowOf(inv[i]) == nil then return true end end
        end
    end
    return false
end
local function popup(p, text)
    local ok = pcall(function() p:Client_DisplayItemErrorNotify(FText(text), true) end)
    if not ok then pcall(function() p:Client_DisplayWarningMessage(FText(text), 1, true) end) end
end
-- equip slot <-> inventory slot, the drag-and-drop swap (server just exchanges the two slots)
local function swapSlots(p, comp1, idx1, comp2, idx2)
    dbg("Request_TrySwapItems(%s %d <-> %s %d)", comp1:GetFName():ToString(), idx1, comp2:GetFName():ToString(), idx2)
    local ok, err = pcall(function() p:Request_TrySwapItems(comp1, idx1, comp2, idx2) end)
    if not ok then log("swap failed: %s", tostring(err)) end
    return ok
end

-- Take the worn suit off. Returns false if it stays on.
local function unequip(p, row, eqComp, eqIdx)
    local oc, oi = freeOrigin(p, row)
    if oc then
        dbg("unequip %s back to its %s slot %d", row, origins[row].where, oi)
        if swapSlots(p, eqComp, eqIdx, oc, oi) then return true end
    end
    if not hasFreeSlot(p) then
        dbg("unequip %s: inventory full", row)
        popup(p, "Inventory full")
        return false
    end
    dbg("unequip %s (standard quick move)", row)
    quickMove(p, eqComp, eqIdx, false)
    return true
end

local function equip(p, row, comp, idx)
    local wh = whereOf(p, comp)
    -- the suit worn now (if any) goes back to its own remembered slot first, if that slot is free
    local eq = p.CharacterEquipSlotInventory
    local wornRow, wornIdx
    if valid(eq) then
        local inv = eq.CurrentInventory
        for i = 1, #inv do
            local r = rowOf(inv[i])
            if isSuit(r) then wornRow, wornIdx = r, i - 1; break end
        end
    end
    if wornRow then
        local oc, oi = freeOrigin(p, wornRow)
        if oc and not (addr(oc) == addr(comp) and oi == idx) then
            dbg("worn %s goes back to its %s slot %d", wornRow, origins[wornRow].where, oi)
            swapSlots(p, eq, wornIdx, oc, oi)
        else
            dbg("worn %s has no free remembered slot, the game swaps it into %s slot %d", wornRow, tostring(wh), idx)
        end
    end
    if wh then origins[row] = { where = wh, idx = idx }; saveOrigins() end
    dbg("equip %s from %s slot %d", row, tostring(wh), idx)
    quickMove(p, comp, idx, true)
end

-- ---------------------------------------------------------------- wheel look
local function setEntryText(w, text, green)
    local en = w.EntryName
    if not valid(en) then return end
    if not S.entryColor then
        pcall(function()
            local c = en.ColorAndOpacity.SpecifiedColor
            S.entryColor = { R = c.R, G = c.G, B = c.B, A = c.A }
        end)
    end
    pcall(function() en:SetText(FText(text)) end)
    local col = green and GREEN or S.entryColor
    if col then pcall(function() en:SetColorAndOpacity({ SpecifiedColor = col, ColorUseRule = 0 }) end) end
end

local function decorateEquipped(icon)
    -- tint: the icon's own Tick fades CurrentColor towards these two colours
    local ok = pcall(function()
        icon.Settings.HighlightColor_7_FCF133C849CA59F3A456E984F1122433 = GREEN
        icon.Settings.UnhighlightColor_9_20CEE6F940EC3C0A462D609528F7D138 = GREEN_DIM
    end)
    if not ok then
        pcall(function()
            icon.Settings = {
                AnimationStyle_2_C5857E2F4AC7D5363326C8B5363D9ADD = 0,
                HighlightColor_7_FCF133C849CA59F3A456E984F1122433 = GREEN,
                UnhighlightColor_9_20CEE6F940EC3C0A462D609528F7D138 = GREEN_DIM,
                ColorTransitionSpeed_12_2636B2604C9B6A366DD018A588954C28 = 0.3,
            }
        end)
    end
    if not settings.badge then return end
    -- "EQUIPPED" tag under the icon
    local ok2, err = pcall(function()
        seq = seq + 1
        local tb = StaticConstructObject(StaticFindObject(TEXTBLOCK), icon.WidgetTree,
            FName("AuxGearWheel_" .. LOADTAG .. "_" .. seq), 0, 0)
        tb:SetText(FText("EQUIPPED"))
        tb:SetColorAndOpacity({ SpecifiedColor = GREEN, ColorUseRule = 0 })
        pcall(function() tb:SetShadowOffset({ X = 1, Y = 1 }) end)
        pcall(function() tb:SetShadowColorAndOpacity({ R = 0, G = 0, B = 0, A = 0.9 }) end)
        pcall(function() tb:SetJustification(1) end)
        local sl = icon.Overlay_0:AddChildToOverlay(tb)
        sl:SetHorizontalAlignment(2)   -- centre
        sl:SetVerticalAlignment(3)     -- bottom
        tb:SetRenderTransformPivot({ X = 0.5, Y = 0.5 })
        tb:SetRenderScale({ X = settings.badgescale, Y = settings.badgescale })
        tb:SetRenderTranslation({ X = 0, Y = settings.badgey })
        tb:SetVisibility(4)            -- HitTestInvisible
    end)
    if not ok2 then dbg("badge failed: %s", tostring(err)) end
end

local function decorate(w)
    local sw = w.SelectionWheel
    if not valid(sw) then return end
    local kids = sw.Children
    local n = 0
    pcall(function() n = kids:GetArrayNum() end)
    dbg("wheel has %d icons for %d suits", n, #S.list)
    for i = 1, math.min(n, #S.list) do
        if S.list[i].equipped then
            local icon = kids[i]
            if valid(icon) then decorateEquipped(icon) end
        end
    end
end

local function refreshEntryText(w)
    if #S.list == 0 then setEntryText(w, "No suits in your inventory", false); return end
    local idx = -1
    pcall(function() idx = w.SelectionWheel.Index end)
    local e = S.list[(idx or -1) + 1]
    if not e then return end
    -- the vanilla code has just written the item name into EntryName
    if not e.name then
        pcall(function() e.name = w.EntryName:GetText():ToString() end)
    end
    local name = e.name or e.row
    if e.equipped then setEntryText(w, name .. "\nEquipped - release to unequip", true)
    else setEntryText(w, name, false) end
end

-- ---------------------------------------------------------------- open / close
local function canOpen(pc, p)
    if not valid(p) then return false end
    if not p:IsA(StaticFindObject(PLAYER_CLS)) then return false end
    local blocked = false
    pcall(function() if pc.bShowMouseCursor then blocked = true end end)          -- inventory, menus, map...
    pcall(function() if pc.IsTextChatOpen then blocked = true end end)
    pcall(function() if valid(p.RadialWheel) then blocked = true end end)          -- another wheel is open
    pcall(function()
        if StaticFindObject("/Script/Engine.Default__GameplayStatics"):IsGamePaused(pc) then blocked = true end
    end)
    return not blocked
end

local function openWheel(p)
    local cls = wheelClass()
    if not cls then log("wheel class %s not found", WHEEL_CLS); return end
    S.list = collectSuits(p)
    dbg("open: %d suit(s)%s", #S.list, #S.list > 0 and (" - first " .. S.list[1].row) or "")
    S.p = p
    S.opening = true
    local ok, err = pcall(function() p:EnterRadialWheel(cls) end)
    S.opening = false
    if not ok then log("EnterRadialWheel failed: %s", tostring(err)); return end
    local w = p.RadialWheel
    if not valid(w) or not w:IsA(cls) then dbg("wheel did not open"); return end
    S.w, S.wAddr, S.open, S.ticks = w, w:GetAddress(), true, 0
    decorate(w)
    refreshEntryText(w)
end

local function resetState()
    S.open, S.w, S.wAddr, S.p, S.list = false, nil, 0, nil, {}
end

local function closeWheel(commit)
    local p, w = S.p, S.w
    local idx = -1
    pcall(function() idx = w.SelectionWheel.Index end)
    local heldMs = S.ticks * settings.poll
    local list = S.list
    pcall(function() p:TryCloseRadialWheel(false, S.cls, {}) end)
    resetState()
    if not commit or not valid(p) then return end
    if heldMs < settings.mintap then dbg("tap (%d ms) - nothing selected", heldMs); return end
    local e = list[(idx or -1) + 1]
    if not e then dbg("no selection (index %s)", tostring(idx)); return end
    local comp, slot = locate(p, e.row, e.equipped)
    if not comp then log("%s is no longer in your %s", e.row, e.equipped and "suit slot" or "inventory"); return end
    if e.equipped then unequip(p, e.row, comp, slot)
    else equip(p, e.row, comp, slot) end
end

-- ---------------------------------------------------------------- hooks
local function hookAll()
    local ok1, e1 = pcall(RegisterHook, HOOK_CATS, function(ctx, entryList, hasList)
        local w = ctx:get()
        if not isOurs(w) then return end
        local names = {}
        for i, e in ipairs(S.list) do names[i] = e.row end
        local ok, err = pcall(function()
            local arr = entryList:get()
            arr:Empty()
            for i, r in ipairs(names) do arr[i] = FName(r) end
            hasList:set(#names > 0)
            w.SelectionWheel:UpdateSegments(#names)
        end)
        if not ok then log("could not fill the wheel: %s", tostring(err)) end
    end)
    log("hook Get Wheel Categories: %s %s", tostring(ok1), ok1 and "" or tostring(e1))

    local ok2, e2 = pcall(RegisterHook, HOOK_SEL, function(ctx)
        local w = ctx:get()
        if not isOurs(w) then return end
        pcall(refreshEntryText, w)
    end)
    log("hook SelectionChanged: %s %s", tostring(ok2), ok2 and "" or tostring(e2))
end

local hooked = false
local function tryHook()
    if hooked then return true end
    if not valid(StaticFindObject(PLAYER_CLS)) or not wheelClass() then return false end
    hooked = true
    hookAll()
    return true
end

-- ---------------------------------------------------------------- main loop (game thread)
gtLoop(settings.poll, function()
    if not hooked then
        S.hookWait = (S.hookWait or 0) + settings.poll
        if S.hookWait < 2000 then return false end
        S.hookWait = 0
        pcall(tryHook)
        return false
    end
    local pc = getPC()
    if not valid(pc) then if S.open then resetState() end; S.wasDown = false; return false end
    local down = keyDown(pc, settings.key)
    if S.open then
        S.ticks = S.ticks + 1
        -- closed by the game (damage, menu, death, another wheel...)?
        local still = valid(S.w) and valid(S.p) and addr(S.p.RadialWheel) == S.wAddr
        if not still then
            dbg("wheel was closed by the game")
            resetState()
        elseif not down then
            closeWheel(true)
        end
    elseif down and not S.wasDown then
        local p = pc.Pawn
        if canOpen(pc, p) then
            local ok, err = pcall(openWheel, p)
            if not ok then log("open failed: %s", tostring(err)); S.opening = false end
        end
    end
    S.wasDown = down
    return false
end)

log("loaded (hold %s)", settings.key)
