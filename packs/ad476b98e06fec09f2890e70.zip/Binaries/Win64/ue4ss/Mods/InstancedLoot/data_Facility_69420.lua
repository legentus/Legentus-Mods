return {
 ["containers"]={
  ["/Game/Maps/Facility_Dam_Central.Facility_Dam_Central:PersistentLevel.Container_Locker_C_1"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={
      [0]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="752B075A4101B682CD9348B3296C90D4",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="rubberbands",
       ["stack"]=3,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [2]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="3AED4B9E44E282EA49A9B48AA139B32B",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="ducttape",
       ["stack"]=3,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [6]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="AB527D0D44C7B04993ED22ADDE47D920",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="scrap_paper",
       ["stack"]=3,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Central.Facility_Dam_Central:PersistentLevel.Deployed_Container_Medkit_C_0"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={
      [9]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="A0480B3F416DF36A4E1EA197D14B9CF9",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="iodinetablets",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Central.Facility_Dam_Central:PersistentLevel.Deployed_Container_Medkit_C_2"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={
      [1]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [10]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [11]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [12]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [13]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [14]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [15]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [2]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [3]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="B5BD11764E6C2A13DB07EE89A61BCD47",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="splint",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [4]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [5]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [6]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [7]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [8]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [9]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Central.Facility_Dam_Central:PersistentLevel.Deployed_Container_Toolbox_C_0"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=6,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Central.Facility_Dam_Central:PersistentLevel.Deployed_Container_Toolbox_C_1"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=6,
     ["slots"]={
      [0]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [1]={
       ["ammo"]=0,
       ["dur"]=40,
       ["dyn"]=false,
       ["id"]="E5BF77F5478D4313D7BBA19FA4E7B3A2",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=40,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="Screwdriver",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [2]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="C937DE00418DD8ED36D73EB7F78C5C56",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="ducttape",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [3]={
       ["ammo"]=0,
       ["dur"]=15,
       ["dyn"]=false,
       ["id"]="F3203E0045738F373D569E833473096F",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=15,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="hammer",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [4]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [5]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="703B5B2C477B1E2C51229790F3978D99",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="gigaglue",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Hydroplant.Facility_Dam_Hydroplant:PersistentLevel.Container_KitchenCabinet_C_0"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=6,
     ["slots"]={
      [1]={
       ["ammo"]=0,
       ["dur"]=20,
       ["dyn"]=false,
       ["id"]="F5B274E1467587841E538A83E9AA9658",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=20,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="knife",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [2]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="F24B605D4CD9C72CB66B35B4755C5D3C",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="food_cannedpeas",
       ["stack"]=3,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Hydroplant.Facility_Dam_Hydroplant:PersistentLevel.Container_KitchenCabinet_C_1"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=6,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Hydroplant.Facility_Dam_Hydroplant:PersistentLevel.Container_KitchenCabinet_C_2"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=6,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Hydroplant.Facility_Dam_Hydroplant:PersistentLevel.Container_KitchenCounter_C_0"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Hydroplant.Facility_Dam_Hydroplant:PersistentLevel.Container_KitchenCounter_C_1"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={
      [12]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="5198CBF843C00CE53F0519B2EA2A99BD",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="food_cannedpeas",
       ["stack"]=3,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Hydroplant.Facility_Dam_Hydroplant:PersistentLevel.Container_KitchenCounter_C_2"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Hydroplant.Facility_Dam_Hydroplant:PersistentLevel.Container_KitchenCounter_C_3"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Hydroplant.Facility_Dam_Hydroplant:PersistentLevel.Container_KitchenCounter_C_4"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={
      [1]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="3EB3F26F4594CA951A239298FCF87995",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="food_cannedpeas",
       ["stack"]=3,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Hydroplant.Facility_Dam_Hydroplant:PersistentLevel.Container_KitchenCounter_C_5"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Hydroplant.Facility_Dam_Hydroplant:PersistentLevel.Container_KitchenCounter_C_6"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={
      [4]={
       ["ammo"]=0,
       ["dur"]=20,
       ["dyn"]=false,
       ["id"]="94F0847745C0C866CE37A5954CEB2A6C",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=20,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="knife",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Hydroplant.Facility_Dam_Hydroplant:PersistentLevel.Container_KitchenCounter_C_7"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={
      [5]={
       ["ammo"]=0,
       ["dur"]=20,
       ["dyn"]=false,
       ["id"]="D6B7F04F427EE16D919C97BA786D49D4",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=20,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="knife",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/Facility_Dam_Waterfall.Facility_Dam_Waterfall:PersistentLevel.Deployed_Container_Medkit_C_0"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={
      [0]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [1]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [10]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [11]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [12]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [13]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [14]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [15]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [2]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [4]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [5]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [6]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [7]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [8]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [9]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/Facility_Labs_Control.Facility_Labs_Control:PersistentLevel.Deployed_Container_TrashCan_Small_C_0"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=4,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Facility_Security.Facility_Security:PersistentLevel.Container_Locker_Security_C_16"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={
      [0]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [1]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [10]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [11]={
       ["ammo"]=0,
       ["dur"]=15,
       ["dyn"]=false,
       ["id"]="8476E55E40B73379653DA8B09B28E940",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=15,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="armor_hat_securitycap",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [12]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [13]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [14]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [15]={
       ["ammo"]=0,
       ["dur"]=20,
       ["dyn"]=false,
       ["id"]="99225BC0478A23FE1ECC39A0DED85C5D",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=20,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="armor_legs_security",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [2]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [3]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [4]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [5]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [6]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [7]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [8]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [9]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/Facility_Security.Facility_Security:PersistentLevel.Deployed_Container_FilingCabinet_Medium_C_16"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Facility_Security.Facility_Security:PersistentLevel.Deployed_Container_FilingCabinet_Small_C_15"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=8,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Facility_Security.Facility_Security:PersistentLevel.Deployed_Container_TrashCan_C_2"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=8,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Facility_Security.Facility_Security:PersistentLevel.Deployed_Container_TrashCan_C_5"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=8,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/V_Alps.V_Alps:PersistentLevel.Deployed_Container_Toolbox_C_1"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=6,
     ["slots"]={
      [2]={
       ["ammo"]=0,
       ["dur"]=40,
       ["dyn"]=false,
       ["id"]="6C7EF10A48C78439B36075B49EE62DB2",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=40,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="Screwdriver",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [3]={
       ["ammo"]=0,
       ["dur"]=15,
       ["dyn"]=false,
       ["id"]="081849FA4E60F0B898A8D1BC84B1F3FE",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=15,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="hammer",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/V_Anteverse_B.V_Anteverse_B:PersistentLevel.Deployed_Container_FilingCabinet_Huge_C_1"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=32,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/V_FOG.V_FOG:PersistentLevel.Container_KitchenCabinet_C_3"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=6,
     ["slots"]={
      [1]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="B3BF65874A5D0C19D44BE589876C6685",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="food_cannedpeas",
       ["stack"]=3,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/V_FOG.V_FOG:PersistentLevel.Container_KitchenCabinet_C_5"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=6,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/V_FOG.V_FOG:PersistentLevel.Container_KitchenCabinet_C_6"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=6,
     ["slots"]={
      [0]={
       ["ammo"]=0,
       ["dur"]=20,
       ["dyn"]=false,
       ["id"]="B622222047A869543B3125A3CFB1D4B1",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=20,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="knife",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/V_FOG.V_FOG:PersistentLevel.Container_KitchenCabinet_C_7"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=6,
     ["slots"]={
      [4]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="E8F48C8E4A611C6FCFA5529EDC671EEF",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="food_cannedpeas",
       ["stack"]=3,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/V_FOG.V_FOG:PersistentLevel.Container_KitchenCounter_C_2"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={
      [11]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="E320E1BB4BC3B43E70BB0BBBE55733BC",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="food_cannedpeas",
       ["stack"]=3,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/V_FOG.V_FOG:PersistentLevel.Container_KitchenCounter_C_3"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={
      [0]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [1]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [10]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [11]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [12]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [13]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [14]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [15]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [2]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [3]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [4]={
       ["ammo"]=0,
       ["dur"]=20,
       ["dyn"]=false,
       ["id"]="FD206F384726BC0C9FDE5AAECFC23C59",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=20,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="knife",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [5]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [6]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [7]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [8]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [9]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/V_FOG.V_FOG:PersistentLevel.Container_KitchenCounter_C_4"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/V_FOG.V_FOG:PersistentLevel.Deployed_Container_TrashCan_C_31"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=8,
     ["slots"]={
      [0]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [1]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [2]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [3]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="6CD2D40A4DB8F8EF3A3A169F3F97ABA0",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="scrap_paper",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [4]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [5]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [6]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="B79FC30F48915015F585F3BFFCFD8BFD",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="scrap_plastic",
       ["stack"]=2,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [7]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/V_FOG.V_FOG:PersistentLevel.Deployed_Container_TrashCan_Small_C_5"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=4,
     ["slots"]={
      [0]={
       ["ammo"]=0,
       ["dur"]=100,
       ["dyn"]=false,
       ["id"]="4B689AC74CC7C4EE143A2098477AC116",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="scrap_paper",
       ["stack"]=3,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/V_FOG.V_FOG:PersistentLevel.Deployed_Refrigerator_C_1"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=48,
     ["slots"]={
      [0]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [1]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [10]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [11]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [12]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [13]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [14]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [15]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [16]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [17]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [18]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [19]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [2]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [20]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [21]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [22]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [23]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [24]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [25]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [26]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [27]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [28]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [29]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [3]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [30]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [31]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [32]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [33]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [34]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [35]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [36]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [37]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [38]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [39]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [4]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [40]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [41]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [42]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [43]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [44]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [45]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [46]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [47]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [5]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [6]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [7]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [8]={
       ["ammo"]=0,
       ["dur"]=0,
       ["dyn"]=false,
       ["id"]="-1",
       ["liq"]=-1,
       ["liqt"]=0,
       ["maxdur"]=0,
       ["pms"]="",
       ["props"]={

       },
       ["ptags"]={

       },
       ["row"]="Empty",
       ["stack"]=0,
       ["tags"]={

       },
       ["tv"]="None"
      },
      [9]={
       ["ammo"]=0,
       ["dur"]=24,
       ["dyn"]=false,
       ["id"]="C0C9759D41A927A0F60D56A99CEEC723",
       ["liq"]=0,
       ["liqt"]=0,
       ["maxdur"]=100,
       ["pms"]="",
       ["props"]={
        [1]={
         [1]=21,
         [2]=1
        }
       },
       ["ptags"]={

       },
       ["row"]="food_potato",
       ["stack"]=1,
       ["tags"]={

       },
       ["tv"]="None"
      }
     }
    }
   }
  },
  ["/Game/Maps/V_Train.V_Train:PersistentLevel.Deployed_Container_Chest_Vintage_C_0"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Vignette_FurnitureWarehouse.Vignette_FurnitureWarehouse:PersistentLevel.Container_KitchenCabinet_C_35"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=6,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Vignette_FurnitureWarehouse.Vignette_FurnitureWarehouse:PersistentLevel.Container_KitchenCabinet_C_36"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=6,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Vignette_FurnitureWarehouse.Vignette_FurnitureWarehouse:PersistentLevel.Container_KitchenCabinet_C_37"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=6,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Vignette_FurnitureWarehouse.Vignette_FurnitureWarehouse:PersistentLevel.Container_KitchenCabinet_C_38"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=6,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Vignette_FurnitureWarehouse.Vignette_FurnitureWarehouse:PersistentLevel.Container_KitchenCounter_C_73"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Vignette_FurnitureWarehouse.Vignette_FurnitureWarehouse:PersistentLevel.Container_KitchenCounter_C_74"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Vignette_FurnitureWarehouse.Vignette_FurnitureWarehouse:PersistentLevel.Container_KitchenCounter_C_76"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Vignette_FurnitureWarehouse.Vignette_FurnitureWarehouse:PersistentLevel.Container_KitchenCounter_C_77"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Vignette_FurnitureWarehouse.Vignette_FurnitureWarehouse:PersistentLevel.Container_KitchenCounter_C_78"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Vignette_FurnitureWarehouse.Vignette_FurnitureWarehouse:PersistentLevel.Container_KitchenCounter_C_79"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Vignette_FurnitureWarehouse.Vignette_FurnitureWarehouse:PersistentLevel.Container_KitchenCounter_C_80"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Vignette_FurnitureWarehouse.Vignette_FurnitureWarehouse:PersistentLevel.Container_KitchenCounter_C_81"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  },
  ["/Game/Maps/Vignette_FurnitureWarehouse.Vignette_FurnitureWarehouse:PersistentLevel.Container_KitchenCounter_C_82"]={
   ["holder"]="76561198246427700",
   ["inv"]={
    ["76561198246427700"]={
     ["n"]=16,
     ["slots"]={

     }
    }
   }
  }
 },
 ["corpses"]={

 },
 ["drops"]={

 },
 ["nodes"]={
  ["/Game/Maps/Facility_Labs_Control.Facility_Labs_Control:PersistentLevel.Resource_MicroNode_Enethiol_C_0"]={
   ["76561198246427700"]=true
  }
 },
 ["placed"]={

 },
 ["players"]={
  ["76561198246427700"]="Legentus"
 }
}