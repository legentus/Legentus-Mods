# InstancedLoot - how it works (RE notes, 2026-11-12)

Install on every player. Host rolls; every game hides other players' copies.

* Enemy/crate/gib drops: post-hook GameMode GenerateLootDrop (only when TryPlaceInInventory=false). The game's
  own items (Abiotic_Item_Dropped_C spawned during the call, found with NotifyOnNewObject) go to the player
  nearest the drop; every other player gets their own roll (game's CalculateItemDrop called from Lua, Lua
  copy of the formula as fallback) spawned with GameMode.SpawnItem(ConnectToBone = tag).
* Owner tag: InitialAttachToBone = "IL_<UniquePlayerID>" (replicated FName; rep index 16 on Item_Dropped,
  17 on Item_ParentBP; only read by the game when InitialAttachToComponent is valid). Retag = set +
  NetPushModelHelpers.MarkPropertyDirtyFromRepIndex.
* Hiding: root SetHiddenInGame(true, propagate), all trace-type collision channels -> Ignore on every
  primitive, AbioticTargeting:SetEnabled(false). Physics untouched.
* Corpses: CharacterCorpse InteractWith_A post-hook. First searcher = game's own search. Later searchers:
  HasBeenLooted=false, DropLoot(true, player), HasBeenLooted=true (rep index 11). Clients: CanInteractWith_A
  post-hook re-enables the prompt on bodies searched by someone else.
* Floor loot: native pre-hook Actor:K2_DestroyActor. A level-placed (RF_WasLoaded) Abiotic_Item_ParentBP_C
  destroyed with HasBeenPickedUp -> picker (TryPickupItemAndFindBestSlotForIt post-hook) marked, every other
  known player gets a NoPhysics copy at the same transform. Copies are Item_Dropped -> saved by the game;
  re-tagged on load by AssetID from our data file.
* Containers: Deployed_Container_ParentBP with InitialContainerLoot row and not DeployedByPlayer.
  InteractWith_A post-hook swaps ContainerInventory.CurrentInventory to the opener's saved contents
  (UpdateInventorySlot per slot, then MarkPropertyDirtyFromRepIndex(inv, 2) + OnRep_CurrentInventory).
  New opener = fresh roll; item data made by GameMode.SpawnItem on a temp item. Clients block opening a
  loot container another player is using (CanInteractWith_A post-hook, IsContainerBeingUsed).
* Data per world: Mods\InstancedLoot\data_<world>.lua. Log: Mods\InstancedLoot\loot_log.txt.
