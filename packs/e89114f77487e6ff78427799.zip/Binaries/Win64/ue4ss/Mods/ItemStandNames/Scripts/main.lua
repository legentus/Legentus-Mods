-- ItemStandNames: the look-at prompt over an item stand shows the item it holds, and holding interact
-- takes the item (hotbar, then backpack; "Inventory is full" otherwise) or places the held item on an empty stand.
-- ("Personal Teleporter (Home)") instead of "Item Stand".
-- How: post-hook W_PlayerHUD_InteractionPrompt_C:UpdateInteractionPrompts (the only place that sets
-- InteractionObjectName) and, when HitActor is a Deployed_ItemStand_ParentBP_C child, overwrite the text.
-- Name rules copy ItemFunctionLibrary.GetItemFullName: teleporter = "{ItemName} ({BenchName})" with
-- BenchName after the comma in PlayerMadeString; pets = PlayerMadeString; else ItemData.ItemName.
-- Hooks owned (no other Lua mod may hook these): UpdateInteractionPrompts, AbioticDeployed_ParentBP_C
-- CanLongInteractWith_A + LongInteractWith_A, Deployed_ItemStand_ParentBP_C GetInteractText,
-- Deployed_Container_ParentBP_C InteractWith_A_LocalFX.

local TAG = "[ItemStandNames] "
local function log(fmt, ...) print(TAG .. string.format(fmt, ...) .. "\n") end

local HUD_FN = "/Game/Blueprints/Widgets/W_PlayerHUD_InteractionPrompt.W_PlayerHUD_InteractionPrompt_C:UpdateInteractionPrompts"
local STAND = "Deployed_ItemStand_ParentBP_C"

local function str(v)
    if v == nil then return "" end
    local ok, s = pcall(function() return v:ToString() end)
    return ok and s or tostring(v)
end

-- class -> is it an item stand (walk the parent chain once per class)
local standClass = {}
local function isStand(actor)
    local cls = actor:GetClass()
    local key = cls:GetFullName()
    local r = standClass[key]
    if r == nil then
        r = false
        local c = cls
        while c and c:IsValid() do
            if c:GetFName():ToString() == STAND then r = true; break end
            c = c:GetSuperStruct()
        end
        standClass[key] = r
    end
    return r
end

-- row name -> { name = "Item Name", pet = bool }
local rows = {}
local gl = nil
local function rowInfo(row)
    local r = rows[row]
    if r then return r end
    if not (gl and gl:IsValid()) then
        gl = StaticFindObject("/Script/AbioticFactor.Default__GlobalItemHandleFunctionLibrary") -- native CDO, always loaded
    end
    local d, p = {}, {}
    gl:GetGlobalItemRow({ RowName = FName(row) }, d, p)
    local rp = p.ReturnPath
    if type(rp) == "userdata" and rp.get then rp = rp:get() end
    -- UE4SS unpacks the out struct straight into the table passed for it (d.ItemName, ...)
    local data = d.ItemName and d or d.Data
    if rp ~= 0 or not data then
        r = { name = nil, pet = false }
    else
        local name = str(data.ItemName):gsub("{CookedState}%s*", "")
        local pet = false
        pcall(function()
            local tags = data.GameplayTags.GameplayTags
            local n = type(tags) == "table" and #tags or tags:GetArrayNum()
            for i = 1, n do
                local t = tags[i]
                if str(type(t) == "table" and t.TagName or t.TagName) == "Item.Pet" then pet = true; break end
            end
        end)
        r = { name = name ~= "" and name or row, pet = pet }
    end
    rows[row] = r
    return r
end

local function heldName(stand)
    local inv = stand.ContainerInventory
    if not (inv and inv:IsValid()) then return nil end
    local arr = inv.CurrentInventory
    for i = 1, arr:GetArrayNum() do
        local sl = arr[i]
        local row = str(sl.ItemDataTable.RowName)
        if row ~= "" and row ~= "None" then
            local info = rowInfo(row)
            if not info.name then return nil end
            local cd = sl.ChangeableData
            local pms = str(cd.PlayerMadeString)
            local name = info.name
            if row == "PersonalTeleporter" then
                local bench = pms:match(",%s*(.-)%s*$")
                if bench and bench ~= "" then name = string.format("%s (%s)", name, bench) end
            elseif info.pet and pms ~= "" then
                name = pms
            end
            local n = cd.CurrentStack
            if type(n) == "number" and n > 1 then name = string.format("%s (%d)", name, n) end
            return name
        end
    end
    return nil
end

local errOnce = false
local function onPrompt(self, _, _, _, _, _, _, _, _, _, _, hitActor)
    local ok, err = pcall(function()
        local a = hitActor and hitActor:get()
        if not (a and a:IsValid()) or not isStand(a) then return end
        local name = heldName(a)
        if not name then return end
        local w = self:get()
        local tb = w.InteractionObjectName
        if tb and tb:IsValid() then tb:SetText(FText(name)) end
    end)
    if not ok and not errOnce then errOnce = true; log("hook error: %s", tostring(err)) end
end

-- ---------------------------------------------------------------- hold interact: take / place
-- Stands inherit AbioticDeployed_ParentBP's CanLongInteractWith_A (always false) and an empty
-- LongInteractWith_A, so we turn hold-interact on for stands and do the move ourselves.
-- Moves use the game's own Request_TrySwapItems (same path as dragging between slots); they run in a
-- deferred game-thread action, never inside the hook (stand mesh loads -> hook deadlock rule).
local DEP_CLS = "/Game/Blueprints/DeployedObjects/AbioticDeployed_ParentBP.AbioticDeployed_ParentBP_C"
local CAN_FN  = DEP_CLS .. ":CanLongInteractWith_A"
local DO_FN   = DEP_CLS .. ":LongInteractWith_A"
local TXT_FN  = "/Game/Blueprints/DeployedObjects/Furniture/Deployed_ItemStand_ParentBP.Deployed_ItemStand_ParentBP_C:GetInteractText"
local SEL_INV = "Inventory_2_B69CD60741EFD551F09ED5AFF44B1E46"
local SEL_IDX = "Index_5_6BDC7B3944A5DE0B319F9FA20720872F"

local lastHold = -100   -- os.clock() of our last finished hold on a stand
local function emptyRow(r) return r == "" or r == "None" end

-- first filled slot of a stand -> index0, row
local function standItem(stand)
    local inv = stand.ContainerInventory
    if not (inv and inv:IsValid()) then return nil end
    local arr = inv.CurrentInventory
    local firstEmpty = nil
    for i = 1, arr:GetArrayNum() do
        local row = str(arr[i].ItemDataTable.RowName)
        if not emptyRow(row) then return inv, i - 1, row end
        firstEmpty = firstEmpty or (i - 1)
    end
    return inv, nil, nil, firstEmpty
end

local function localPlayer()
    local pc = FindFirstOf("Abiotic_PlayerController_C")
    local pl = nil
    pcall(function() pl = pc.Pawn end)
    if pl and pl:IsValid() then return pl end
    return nil
end

-- the hotbar slot the player is holding -> inv, index0, row
local function heldSlot(pl)
    if not (pl and pl:IsValid()) then return nil end
    local hand = pl.ItemInHand_BP
    if not (hand and hand:IsValid()) then return nil end
    local inv, idx = nil, nil
    pcall(function()
        local sel = pl.CurrentHotbarSlotSelected
        inv, idx = sel[SEL_INV], sel[SEL_IDX]
    end)
    if not (inv and inv:IsValid()) then inv = pl.CharacterHotbarInventory end
    if type(idx) ~= "number" or idx < 0 then idx = pl.LastSelectedHotbarSlot end
    if not (inv and inv:IsValid()) or type(idx) ~= "number" then return nil end
    local arr = inv.CurrentInventory
    if idx < 0 or idx >= arr:GetArrayNum() then return nil end
    local row = str(arr[idx + 1].ItemDataTable.RowName)
    if emptyRow(row) then return nil end
    return inv, idx, row
end

-- hotbar first, then backpack -> inv, index0
local function freeSlot(pl)
    for _, inv in ipairs({ pl.CharacterHotbarInventory, pl.CharacterInventory }) do
        if inv and inv:IsValid() then
            local arr = inv.CurrentInventory
            for i = 1, arr:GetArrayNum() do
                if emptyRow(str(arr[i].ItemDataTable.RowName)) then return inv, i - 1 end
            end
        end
    end
    return nil
end

local function nameOf(row) local i = rowInfo(row); return i.name or row end

-- what a hold would do for this stand and player: "take" / "place" / nil
local function holdAction(stand, pl)
    local inv, idx, row = standItem(stand)
    if not inv then return nil end
    if idx then return "take", row end
    local _, _, hrow = heldSlot(pl)
    if hrow then return "place", hrow end
    return nil
end

local hookErr = {}
local function guard(tag, fn)
    local ok, err = pcall(fn)
    if not ok and not hookErr[tag] then hookErr[tag] = true; log("%s error: %s", tag, tostring(err)) end
end

local function onCanLong(ctx, pSuccess)
    guard("CanLongInteract", function()
        local a = ctx:get()
        if not (a and a:IsValid()) or not isStand(a) then return end
        if holdAction(a, localPlayer()) then pSuccess:set(true) end
    end)
end

local function onText(ctx, pInteract, pLong)
    guard("GetInteractText", function()
        local a = ctx:get()
        if not (a and a:IsValid()) then return end
        local act, row = holdAction(a, localPlayer())
        if act == "take" then pLong:set(FText("Take " .. (heldName(a) or nameOf(row))))
        elseif act == "place" then pLong:set(FText("Place " .. nameOf(row))) end
    end)
end

local function doMove(stand, pl)
    if not (stand and stand:IsValid() and pl and pl:IsValid()) then return end
    local sinv, sidx, row, sempty = standItem(stand)
    if not sinv then return end
    if sidx then
        local tinv, tidx = freeSlot(pl)
        if not tinv then
            pcall(function() pl:Client_DisplayItemErrorNotify(FText("Inventory is full"), true) end)
            log("take %s: inventory full", row)
            return
        end
        pl:Request_TrySwapItems(sinv, sidx, tinv, tidx)
        log("take %s -> %s[%d]", row, tinv:GetFName():ToString(), tidx)
    elseif sempty then
        local hinv, hidx, hrow = heldSlot(pl)
        if not hinv then return end
        pl:Request_TrySwapItems(hinv, hidx, sinv, sempty)
        log("place %s from %s[%d]", hrow, hinv:GetFName():ToString(), hidx)
    end
end

local function onLong(ctx, pChar)
    guard("LongInteract", function()
        local a = ctx:get()
        if not (a and a:IsValid()) or not isStand(a) then return end
        local pl = pChar and pChar:get()
        if not (pl and pl:IsValid()) then return end
        lastHold = os.clock()
        pcall(function() pl.JustExecutedInteraction = true end)
        -- defer: the swap updates the stand's display mesh (asset loads are unsafe inside a BP hook)
        ExecuteInGameThreadWithDelay(1, function() guard("move", function() doMove(a, pl) end) end)
    end)
end


-- The client calls InteractWith_A_LocalFX(Held) for taps AND holds, and Deployed_Container_ParentBP's
-- LocalFX opens the container UI itself (ToggleInventory). On a hold over a stand, close it again in
-- the same frame, and mark the hold as executed so letting go of the key is not treated as a tap.
local FX_FN = "/Game/Blueprints/DeployedObjects/Furniture/Deployed_Container_ParentBP.Deployed_Container_ParentBP_C:InteractWith_A_LocalFX"
local function closeInv(pl)
    if pl.IsInventoryOpen then pl:ToggleInventory(true, 0, {}, nil, false) end
end
local function onLocalFX(ctx, pHeld)
    guard("LocalFX", function()
        local a = ctx:get()
        if not (a and a:IsValid()) or not isStand(a) then return end
        local pl = localPlayer()
        if not pl then return end
        local held = pHeld and pHeld:get()
        local dt = os.clock() - lastHold
        if held then
            lastHold = os.clock()
            -- Releasing the key runs a TAP unless JustExecutedInteraction is set; holds with real long
            -- interactions set it, ours must too.
            pl.JustExecutedInteraction = true
            closeInv(pl)
        elseif dt < 1.5 then
            -- the release still came through as a tap: this LocalFX is what opens the menu, close it now
            closeInv(pl)
        end
    end)
end

-- ---------------------------------------------------------------- hook registration
-- Register once each class is loaded (gate on a live object, never a blind StaticFindObject).
-- If a class is reloaded later (new UFunction object), hook the new one.
local HOOKS = {
    { gate = "W_PlayerHUD_InteractionPrompt_C", fn = HUD_FN, cb = onPrompt },
    { gate = "Deployed_ItemStand_ParentBP_C", fn = CAN_FN, cb = onCanLong },
    { gate = "Deployed_ItemStand_ParentBP_C", fn = DO_FN,  cb = onLong },
    { gate = "Deployed_ItemStand_ParentBP_C", fn = TXT_FN, cb = onText },
    { gate = "Deployed_ItemStand_ParentBP_C", fn = FX_FN,  cb = onLocalFX },
}
LoopInGameThreadWithDelay(2000, function()
    for _, h in ipairs(HOOKS) do
        local o = FindFirstOf(h.gate)
        if o and o:IsValid() then
            local fn = StaticFindObject(h.fn) -- loaded: a live object of the class exists
            if fn and fn:IsValid() then
                local addr = fn:GetAddress()
                if addr ~= h.addr then
                    h.addr = addr
                    local ok, err = pcall(RegisterHook, h.fn, h.cb)
                    log(ok and ("hooked " .. h.fn:match(":(.*)$")) or ("RegisterHook failed: " .. tostring(err)))
                end
            end
        end
    end
end)

log("loaded")
