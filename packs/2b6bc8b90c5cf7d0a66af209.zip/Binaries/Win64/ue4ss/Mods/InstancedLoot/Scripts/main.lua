-- InstancedLoot v1
-- Per-player ("instanced") loot for multiplayer. Every player gets their own roll and their own copy of:
--   1. enemy / crate / gib drops   (GameMode.GenerateLootDrop that spawns items in the world)
--   2. searchable corpses           (CharacterCorpse_ParentBP: each player can search each body once)
--   3. loot lying around            (items placed in the level: when one player takes it, everyone else
--                                    gets their own copy in the same spot)
--   4. loot containers              (cabinets, wall medkits, lockers...: each player has their own contents)
--
-- INSTALL ON EVERY PLAYER (host and clients). The host does the rolling and bookkeeping; each game hides
-- the copies that belong to other players. A client without the mod sees everyone's copies.
--
-- How it works (all from the game's blueprints, see NOTES.md):
--  * Owner tag: an item copy is tagged by writing "IL_<UniquePlayerID>" into its InitialAttachToBone
--    property. That property is replicated, only read by the game when InitialAttachToComponent is set
--    (never for our copies), and is NOT carried into the inventory when the item is picked up.
--    Rep index 16 on Abiotic_Item_Dropped_C, 17 on Abiotic_Item_ParentBP_C (from the blueprints'
--    own MarkPropertyDirtyFromRepIndex calls), so a later re-tag is pushed with MarkPropertyDirtyFromRepIndex.
--  * Hiding: each game hides items tagged for someone else (SetHiddenInGame per component, restored on show; interaction
--    trace channels set to Ignore, aim targeting off). Physics is untouched, so on the host the owner's copy
--    still behaves normally for the owner.
--  * Copies are spawned with GameMode.SpawnItem(..., ConnectToBone = tag), which sets the tag before the
--    actor is spawned. Copies are ordinary dropped items, so the game saves them; their AssetIDs are kept
--    in our data file and re-tagged when the world loads.
--
-- TEST MODE (solo), COMMENTED OUT since v1.14. To turn it back on, change every "--[[TESTMODE" in this file to
-- "--TESTMODE[[" (one find/replace), then set fakeplayers = 2 in settings.txt. While it is on,
-- settings.txt fakeplayers = 2 makes the host roll for FAKE1, FAKE2 as if they were
-- online. F7 (rebindable in F4) switches who YOU are (you -> FAKE1 -> FAKE2 -> you), so you can open the
-- same medkit as each "player", see each player's own drops and pick up a desk item as one player and
-- find it still there as another. Everything is logged to Mods\InstancedLoot\loot_log.txt.
--
-- Hooks owned by this mod (no other Lua mod may RegisterHook these, see project notes on UE4SS crashes):
--   GameMode:GenerateLootDrop (taken over from CheatMenu), CharacterCorpse_ParentBP_C:InteractWith_A,
--   CanInteractWith_A, InteractWith_A_LocalFX, Deployed_Container_ParentBP_C:InteractWith_A,
--   Server_UserLeftContainer, CanInteractWith_A, TryRegenerateContainerLoot,
--   Abiotic_PlayerCharacter_C:TryPickupItemAndFindBestSlotForIt; native Actor:K2_DestroyActor.

local MOD = "[InstancedLoot] "
local DIR = "ue4ss/Mods/InstancedLoot/"
local IL = {}            -- all module state lives in tables (Lua 200-local limit)
IL.t0 = os.time()

-- ---------------------------------------------------------------- logging
local LOGFILE = DIR .. "loot_log.txt"
local function stamp() return os.date("%H:%M:%S") end
local function log(fmt, ...)
    local ok, msg = pcall(string.format, fmt, ...)
    if not ok then msg = fmt end
    print(MOD .. msg .. "\n")
    local f = io.open(LOGFILE, "a")
    if f then f:write(stamp() .. " " .. msg .. "\n"); f:close() end
end
do
    local f = io.open(LOGFILE, "w")
    if f then f:write("==== InstancedLoot log, game started " .. os.date("%Y-%m-%d %H:%M:%S") .. " ====\n"); f:close() end
end
local function valid(o) return o ~= nil and type(o) == "userdata" and o.IsValid ~= nil and o:IsValid() end
local function str(v)
    if v == nil then return "" end
    if type(v) == "string" then return v end
    local ok, s = pcall(function() return v:ToString() end)
    if ok and s then return s end
    return tostring(v)
end

-- ---------------------------------------------------------------- settings (Mods\InstancedLoot\settings.txt)
local S = { enabled = true, drops = true, corpses = true, floorloot = true, containers = true, lootables = true,
            --[[TESTMODE
            fakeplayers = 0,
            --TESTMODE]]
            existing = "keep", verbose = false, droplifespan = 240,
            -- super special items: never copied per player (first come, first served, like the vanilla game).
            -- comma list of item row names; * matches anything
            special = "key_*,Gatekey,tramkey,tablet_wax_*,composer_tablet,core_fragment" }
do
    local f = io.open(DIR .. "settings.txt", "r")
    if f then
        for line in f:lines() do
            local k, v = line:match("^%s*(%w+)%s*=%s*([^;#%s]+)")
            if k == "special" then v = line:match("=%s*([^#]*)"):gsub("%s", "") end
            if k and S[k] ~= nil then
                if type(S[k]) == "boolean" then S[k] = (v == "true" or v == "1")
                elseif type(S[k]) == "number" then S[k] = tonumber(v) or S[k]
                else S[k] = v end
            end
        end
        f:close()
    end
end
if S.verbose then log("settings: drops=%s corpses=%s floorloot=%s lootables=%s containers=%s existing=%s",
    tostring(S.drops), tostring(S.corpses), tostring(S.floorloot), tostring(S.lootables), tostring(S.containers), S.existing) end
--[[TESTMODE
log("TEST MODE is compiled in: fakeplayers=%d", S.fakeplayers)
--TESTMODE]]
IL.special = {}
for pat in S.special:gmatch("[^,]+") do
    IL.special[#IL.special + 1] = "^" .. pat:lower():gsub("[%^%$%(%)%%%.%[%]%+%-%?]", "%%%0"):gsub("%*", ".*") .. "$"
end
local function isSpecial(row)
    row = tostring(row or ""):lower()
    for _, p in ipairs(IL.special) do if row:find(p) then return true end end
    return false
end
if S.verbose then log("special items (never copied): %s", S.special) end

-- PROBE (pickup lag, 2026-11-20): log any hook/timer/save that takes over 3 ms. Remove once diagnosed.
IL.SLOW_MS = 3
function IL.where(fn)
    local ok, i = pcall(debug.getinfo, fn, "S")
    return ok and i and ("line " .. tostring(i.linedefined)) or "?"
end
function IL.timed(label, fn, ...)
    local t0 = os.clock()
    local ok, err = pcall(fn, ...)
    local ms = (os.clock() - t0) * 1000
    if ms > IL.SLOW_MS then log("SLOW %s: %.1f ms", type(label) == "function" and label() or label, ms) end
    return ok, err
end
-- ---------------------------------------------------------------- game-thread timers
local function gtDelay(ms, fn)
    pcall(ExecuteInGameThreadWithDelay, ms, function()
        local ok, err = IL.timed(function() return "timer " .. IL.where(fn) end, fn); if not ok then log("timer error: %s", tostring(err)) end
    end)
end
local function gtLoop(ms, fn)
    pcall(LoopInGameThreadWithDelay, ms, function()
        local ok, err = IL.timed(function() return "loop " .. ms .. " ms " .. IL.where(fn) end, fn); if not ok then log("loop error: %s", tostring(err)) end
    end)
end

-- ---------------------------------------------------------------- paths / statics
local P = {
    GM = "/Game/Blueprints/Meta/Abiotic_Survival_GameMode.Abiotic_Survival_GameMode_C",
    DROPPED = "/Game/Blueprints/Items/Abiotic_Item_Dropped.Abiotic_Item_Dropped_C",
    ITEM = "/Game/Blueprints/Items/Abiotic_Item_ParentBP.Abiotic_Item_ParentBP_C",
    CORPSE = "/Game/Blueprints/Environment/Special/CharacterCorpse_ParentBP.CharacterCorpse_ParentBP_C",
    CONT = "/Game/Blueprints/DeployedObjects/Furniture/Deployed_Container_ParentBP.Deployed_Container_ParentBP_C",
    NODE = "/Game/Blueprints/Environment/Nodes/ResourceNode_ParentBP.ResourceNode_ParentBP_C",
    MICRO = "/Game/Blueprints/Environment/Nodes/Resource_MicroNode_ParentBP.Resource_MicroNode_ParentBP_C",
    PLAYER = "/Game/Blueprints/Characters/Abiotic_PlayerCharacter.Abiotic_PlayerCharacter_C",
    DT_SALVAGE = "/Game/Blueprints/DataTables/DT_Salvage.DT_Salvage",
    PUSH = "/Script/Engine.Default__NetPushModelHelpers",
    SALVLIB = "/Script/AbioticFactor.Default__SalvageHandleFunctionLibrary",
}
local REP_TAG = { dropped = 16, item = 17 }        -- rep index of InitialAttachToBone
local REP_INV = 2                                    -- Abiotic_InventoryComponent_C.CurrentInventory
local REP_LOOTED = 11                                -- CharacterCorpse_ParentBP_C.HasBeenLooted
local TAG = "IL_"

local function cdo(path)
    local o = StaticFindObject(path)
    if valid(o) then return o end
    return nil
end
local function gm()
    local g = FindFirstOf("Abiotic_Survival_GameMode_C")
    if valid(g) then return g end
    return nil
end
local function isServer() return gm() ~= nil end

-- ---------------------------------------------------------------- identity
-- uid = Abiotic_PlayerState_C.UniquePlayerID (replicated, stable across sessions)
IL.acting = nil          -- test mode: the fake uid the host is pretending to be (nil = yourself)
IL.fakes = {}            -- stays empty while test mode is commented out
--[[TESTMODE
for i = 1, math.max(0, math.floor(S.fakeplayers)) do IL.fakes[#IL.fakes + 1] = "FAKE" .. i end
--TESTMODE]]

local function psUid(ps)
    if not valid(ps) then return nil end
    local ok, id = pcall(function() return str(ps.UniquePlayerID) end)
    if ok and id and id ~= "" then return id end
    return nil
end
local function localPC()
    for _, pc in ipairs(FindAllOf("Abiotic_PlayerController_C") or {}) do
        if valid(pc) then
            local ok, isLocal = pcall(function() return pc:IsLocalController() end)
            if ok and isLocal then return pc end
        end
    end
    return nil
end
local function realLocalUid()
    local pc = localPC()
    if not pc then return nil end
    local ok, ps = pcall(function() return pc.PlayerState end)
    return ok and psUid(ps) or nil
end
local function myUid() return IL.acting or realLocalUid() end
local function nameOfUid(uid)
    if uid == nil then return "?" end
    if uid:sub(1, 4) == "FAKE" then return uid end
    for _, ps in ipairs(FindAllOf("Abiotic_PlayerState_C") or {}) do
        if psUid(ps) == uid then
            local ok, n = pcall(function() return str(ps:GetPlayerName()) end)
            if ok and n ~= "" then return n end
        end
    end
    return uid:sub(-6)
end
-- uid of a character (server side). The host's own character counts as IL.acting in test mode.
local function uidOfChar(ch)
    if not valid(ch) then return nil end
    local ok, ps = pcall(function() return ch.PlayerState end)
    local uid = ok and psUid(ps) or nil
    if uid and IL.acting and uid == realLocalUid() then return IL.acting end
    return uid
end
local function onlinePlayers()       -- list of {uid, char}
    local out = {}
    for _, ch in ipairs(FindAllOf("Abiotic_PlayerCharacter_C") or {}) do
        if valid(ch) then
            local uid = uidOfChar(ch)
            if uid then out[#out + 1] = { uid = uid, char = ch } end
        end
    end
    return out
end
-- everyone who should get a roll right now: online players + fake test players
local function rollList()
    local list, seen = {}, {}
    for _, p in ipairs(onlinePlayers()) do
        if not seen[p.uid] then seen[p.uid] = true; list[#list + 1] = p.uid end
    end
    local real = realLocalUid()
    if IL.acting and real and not seen[real] then seen[real] = true; list[#list + 1] = real end
    for _, f in ipairs(IL.fakes) do
        if not seen[f] then seen[f] = true; list[#list + 1] = f end
    end
    return list
end
local function isSim(uid) return uid ~= nil and uid:sub(1, 4) == "FAKE" end
local function who(uid) return (isSim(uid) and "[SIM] " or "") .. nameOfUid(uid) end

-- ---------------------------------------------------------------- persistent data (per world, host only)
IL.D = nil; IL.world = nil; IL.dirty = false
local function serialize(v, ind)
    ind = ind or ""
    local t = type(v)
    if t == "number" then return string.format("%.17g", v)
    elseif t == "boolean" then return tostring(v)
    elseif t == "string" then return string.format("%q", v)
    elseif t == "table" then
        local parts, ni = {}, ind .. " "
        local keys = {}
        for k in pairs(v) do keys[#keys + 1] = k end
        table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
        for _, k in ipairs(keys) do
            local kk = type(k) == "number" and ("[" .. k .. "]") or ("[" .. string.format("%q", k) .. "]")
            parts[#parts + 1] = ni .. kk .. "=" .. serialize(v[k], ni)
        end
        return "{\n" .. table.concat(parts, ",\n") .. "\n" .. ind .. "}"
    end
    return "nil"
end
local function worldName()
    local gi = FindFirstOf("Abiotic_GameInstance_C")
    local n = ""
    if valid(gi) then pcall(function() n = str(gi.ActiveWorldSaveName) end) end
    if n == "" then n = "default" end
    return (n:gsub("[^%w_%-]", "_"))
end
local function dataFile(w) return DIR .. "data_" .. w .. ".lua" end
local function data()
    local w = worldName()
    if IL.D and IL.world == w then return IL.D end
    if IL.D and IL.dirty and IL.world then
        local f = io.open(dataFile(IL.world), "w")
        if f then f:write("return " .. serialize(IL.D)); f:close() end
    end
    IL.world = w
    IL.D = nil
    local f = io.open(dataFile(w), "r")
    if f then
        local src = f:read("*a"); f:close()
        local fn = load(src)
        if fn then local ok, d = pcall(fn); if ok and type(d) == "table" then IL.D = d end end
    end
    IL.D = IL.D or {}
    for _, k in ipairs({ "drops", "placed", "corpses", "containers", "players", "nodes" }) do IL.D[k] = IL.D[k] or {} end
    -- forget enemy-drop tags older than 3 days (those items despawned long ago)
    local cut, pruned = os.time() - 3 * 86400, 0
    for id, e in pairs(IL.D.drops) do
        if not e.floor and (e.t or 0) < cut then IL.D.drops[id] = nil; pruned = pruned + 1 end
    end
    if pruned > 0 then IL.dirty = true; if S.verbose then log("pruned %d old drop tags", pruned) end end
    -- test mode off: old FAKE1/FAKE2 test players must not count as players (they kept every lootable alive)
    if #IL.fakes == 0 then
        local nf = 0
        for u in pairs(IL.D.players) do if u:sub(1, 4) == "FAKE" then IL.D.players[u] = nil; nf = nf + 1 end end
        for _, t in pairs(IL.D.nodes) do for u in pairs(t) do if u:sub(1, 4) == "FAKE" then t[u] = nil end end end
        if nf > 0 then IL.dirty = true; if S.verbose then log("removed %d old test players (FAKE...) from this world's data", nf) end end
    end
    local n = function(t) local c = 0 for _ in pairs(t) do c = c + 1 end return c end
    if S.verbose then log("world '%s' data loaded: %d tagged items, %d taken floor items, %d searched corpses, %d containers, %d known players",
        w, n(IL.D.drops), n(IL.D.placed), n(IL.D.corpses), n(IL.D.containers), n(IL.D.players)) end
    return IL.D
end
local function saveData()
    if not IL.D or not IL.dirty or not IL.world then return end
    local t0 = os.clock()
    local f = io.open(dataFile(IL.world), "w")
    if f then f:write("return " .. serialize(IL.D)); f:close(); IL.dirty = false end
    local ms = (os.clock() - t0) * 1000
    if ms > IL.SLOW_MS then log("SLOW save world data: %.1f ms", ms) end
end
local function markDirty() IL.dirty = true end

-- ---------------------------------------------------------------- salvage tables (for our own rolls)
IL.salvage = nil
local function loadSalvage()
    if IL.salvage then return IL.salvage end
    IL.salvage = {}
    pcall(LoadAsset, P.DT_SALVAGE)
    local dt = StaticFindObject(P.DT_SALVAGE)
    if not valid(dt) then log("DT_Salvage not found; extra rolls fall back to copying the first roll"); return IL.salvage end
    local nrows = 0
    dt:ForEachRow(function(rowName, row)
        local list = {}
        pcall(function()
            row.SalvageDropItems:ForEach(function(_, e)
                local d = e:get()
                local vars = {}
                pcall(function() d.PossibleTextureVariants:ForEach(function(_, v) vars[#vars + 1] = str(v:get().RowName) end) end)
                list[#list + 1] = { item = str(d.ItemDataTable.RowName), min = d.QuantityMin, max = d.QuantityMax,
                                    chance = d.ChanceToDrop, vars = vars }
            end)
        end)
        IL.salvage[str(rowName)] = list
        nrows = nrows + 1
    end)
    if S.verbose then log("salvage table read: %d loot lists", nrows) end
    return IL.salvage
end

-- ---------------------------------------------------------------- cheat menu drop rate for our own rolls
-- The cheat menu multiplies loot in its CalculateItemDrop hook, which our Lua rolls never pass through.
-- This is a copy of its decision (CheatMenu main.lua categoryOf / shouldMultiply / scaleCount), reading the
-- cheat menu's own settings.txt (droprate, re-read every 2 s) and Scripts\rules_data.txt. Keep in sync.
local DR = { ready = false, rules = nil, craftable = {}, salvRows = {}, single = {}, mats = {}, matsKnown = false,
             body = {}, kill = {}, r = 1.0, rT = -99 }
local CM_DIR = "ue4ss/Mods/CheatMenu/"
function DR.rows(path, fn)
    pcall(LoadAsset, path)
    local dt = StaticFindObject(path)
    if not valid(dt) then return false end
    dt:ForEachRow(fn)
    return true
end
function DR.rate()
    if os.clock() - DR.rT < 2 then return DR.r end
    DR.rT = os.clock()
    local r = 1.0
    local okE = io.open(CM_DIR .. "enabled.txt", "r")
    if okE then
        okE:close()
        local f = io.open(CM_DIR .. "settings.txt", "r")
        if f then
            for line in f:lines() do
                local v = line:match("^%s*droprate%s*=%s*([%d%.]+)")
                if v then r = math.max(1, math.min(10, tonumber(v) or 1)) end
            end
            f:close()
        end
    end
    if r ~= DR.r then if S.verbose then log("cheat menu drop rate for extra players' rolls: %.2fx", r) end end
    DR.r = r
    return r
end
function DR.init()
    if DR.ready then return end
    DR.ready = true
    local f = io.open(CM_DIR .. "Scripts/rules_data.txt", "r")
    local nRules = 0
    if f then
        DR.rules = {}
        for line in f:lines() do
            local c, i, v = line:match("^([%w_]+)\t([^\t]+)\t([01])%s*$")
            if c then DR.rules[c] = DR.rules[c] or {}; DR.rules[c][i] = (v == "1"); nRules = nRules + 1 end
        end
        f:close()
    end
    pcall(DR.rows, "/Game/Blueprints/DataTables/DT_NPCList.DT_NPCList", function(_, row)
        pcall(function() local n = str(row.GibInfo.GibSalvage.RowName); if n ~= "None" then DR.body[n] = true end end)
        pcall(function() row.PotentialLootWhenKilled:ForEach(function(_, h) local n = str(h:get().RowName); if n ~= "None" then DR.kill[n] = true end end) end)
    end)
    local RECIPES = { "/Game/Blueprints/DataTables/DT_Recipes.DT_Recipes", "/Game/Blueprints/DataTables/DT_ChemistryRecipes.DT_ChemistryRecipes" }
    local groups = {}
    pcall(DR.rows, "/Game/Blueprints/Items/ItemTable_RecipeSubstitutes.ItemTable_RecipeSubstitutes", function(rowName, row)
        local list = {}
        pcall(function() row.ItemsOfType:ForEach(function(_, h) list[#list + 1] = str(h:get().RowName) end) end)
        groups[str(rowName)] = list
    end)
    local function addInputs(arr)
        pcall(function()
            arr:ForEach(function(_, ref)
                local input = ref:get()
                local name = str(input.Item.RowName)
                local tbl = 0
                pcall(function() tbl = input.Item.Table end)
                if tbl == 1 and groups[name] then for _, m in ipairs(groups[name]) do DR.mats[m] = true end
                elseif name ~= "None" then DR.mats[name] = true end
            end)
        end)
    end
    for _, path in ipairs(RECIPES) do
        pcall(DR.rows, path, function(_, row)
            addInputs(row.RecipeItems)
            pcall(function() local it = str(row.ItemToCreate.RowName); if it ~= "None" then DR.craftable[it] = true end end)
        end)
    end
    pcall(DR.rows, "/Game/Blueprints/DataTables/DT_BenchUpgrades.DT_BenchUpgrades", function(_, row) addInputs(row.RequiredItems) end)
    pcall(DR.rows, "/Game/Blueprints/DataTables/DT_ItemUpgrades.DT_ItemUpgrades", function(_, row)
        pcall(function() row.Upgrades:ForEach(function(_, e) addInputs(e:get().RequiredItems) end) end)
    end)
    for name in pairs(DR.mats) do if name:lower():find("^ammo_") then DR.mats[name] = nil end end
    local nMats = 0
    for _ in pairs(DR.mats) do nMats = nMats + 1 end
    DR.matsKnown = nMats > 0
    for _, t in ipairs({ "Craftables", "Deployables", "Deployables_CraftingBenches", "Deployables_Small",
                         "FoodAndGibs", "Gear", "Global", "Pets", "Pickups", "Plants", "Weapons" }) do
        pcall(DR.rows, "/Game/Blueprints/Items/ItemTable_" .. t .. ".ItemTable_" .. t, function(rowName, row)
            local item = str(rowName)
            pcall(function() if row.StackSize <= 1 then DR.single[item] = true end end)
            pcall(function() local sv = str(row.SalvageData.RowName); if sv ~= "None" then DR.salvRows[sv] = true end end)
        end)
    end
    if S.verbose then log("drop-rate rules (copied from the cheat menu): %d rules, %d crafting materials", nRules, nMats) end
end
function DR.category(row)
    if not row then return "world" end
    if DR.body[row] or row:find("^gibbed_") or row:find("^butcher_") then return "butchering" end
    if DR.kill[row] then return "kill" end
    if DR.salvRows[row] then return "destroyed" end
    if row:find("^container_") then return "containers" end
    if row:find("^loot_fishtrash") then return "fishing" end
    if row:find("^harvest_") then return "farming" end
    return "world"
end
function DR.should(cat, item)
    local r = DR.rules and DR.rules[cat]
    if r and r[item] ~= nil then return r[item] end
    if cat == "butchering" or cat == "destroyed" then return false end
    return DR.matsKnown and DR.mats[item] and not DR.single[item] and true or false
end
-- the count after the cheat menu's multiplier (same random rounding)
function DR.scale(row, item, c)
    local rate = DR.rate()
    if rate <= 1.0 or c <= 0 then return c end
    DR.init()
    if not DR.should(DR.category(row), item) then return c end
    local scaled = c * rate
    local n = math.floor(scaled)
    if math.random() < (scaled - n) then n = n + 1 end
    return n
end

-- Roll one salvage list with the same formula as GameMode.CalculateItemDrop (min guaranteed, then
-- each extra unit at ChanceToDrop + extra). Done in Lua: calling CalculateItemDrop / GetSalvageRow from
-- Lua (struct out-params) crashed UE4SS in push_structproperty (2026-11-12).
IL.calcMode = "lua"
local function rollList_(salvageRow, extra)
    local list = loadSalvage()[salvageRow]
    local out = {}
    if not list then return out, "unknown list" end
    for _, e in ipairs(list) do
        local n = 0
        for i = 1, (e.max or 0) do
            if i <= (e.min or 0) then n = n + 1
            elseif math.random() <= (e.chance or 0) + (extra or 0) then n = n + 1 end
        end
        n = DR.scale(salvageRow, e.item, n)
        if n > 0 then out[#out + 1] = { item = e.item, count = n } end
    end
    return out
end
local function fmtItems(items)
    if #items == 0 then return "(nothing)" end
    local t = {}
    for _, it in ipairs(items) do t[#t + 1] = it.count .. "x " .. it.item end
    return table.concat(t, ", ")
end

-- ---------------------------------------------------------------- tagging + hiding
IL.tracked = {}          -- address -> { obj, kind, checks, tagged }
IL.internal = 0          -- >0 while we spawn items ourselves (temp items, copies)
IL.pendingNew = {}       -- vanilla Item_Dropped spawned recently (for GenerateLootDrop attribution)

local function kindOf(a)
    local ok, k = pcall(function()
        if a:IsA(StaticFindObject(P.DROPPED)) then return "dropped" end
        return "item"
    end)
    return ok and k or "item"
end
local function tagOf(a)
    local ok, t = pcall(function() return str(a.InitialAttachToBone) end)
    if ok and t and t:sub(1, #TAG) == TAG then return t:sub(#TAG + 1) end
    return nil
end
local function setTag(a, uid, kind)
    kind = kind or kindOf(a)
    pcall(function() a:FlushNetDormancy() end)
    a.InitialAttachToBone = FName(uid and (TAG .. uid) or "None")
    pcall(function() cdo(P.PUSH):MarkPropertyDirtyFromRepIndex(a, REP_TAG[kind], FName("InitialAttachToBone")) end)
end

IL.traceChannels = nil
local function traceChannels()
    if IL.traceChannels then return IL.traceChannels end
    local list = { 3, 4 }   -- Visibility, Camera
    pcall(function()
        local cp = StaticFindObject("/Script/Engine.Default__CollisionProfile")
        cp.DefaultChannelResponses:ForEach(function(_, e)
            local d = e:get()
            if d.bTraceType then list[#list + 1] = d.Channel end
        end)
    end)
    IL.traceChannels = list
    if S.verbose then log("interaction trace channels to ignore on hidden copies: %s", table.concat(list, ",")) end
    return list
end
-- every scene component of an item, found three ways and merged (v1.7 used only K2_GetComponentsByClass; in game
-- that hid nothing, so other players' copies stayed visible). Late-added parts (glass item box) are caught by
-- re-running this on every check.
IL.partsInfo = nil
local NAMED_PARTS = { "WorldMesh", "World_StaticMesh", "World_SkeletalMesh" }
local function parts(a)
    local out, seen = {}, {}
    local nC, nT, nN = 0, 0, 0
    local function add(c)
        if c == nil or not valid(c) then return false end
        local k = c:GetAddress()
        if seen[k] then return false end
        seen[k] = true; out[#out + 1] = c
        return true
    end
    pcall(function()
        local cls = StaticFindObject("/Script/Engine.PrimitiveComponent")
        a:K2_GetComponentsByClass(cls):ForEach(function(_, e) if add(e:get()) then nC = nC + 1 end end)
    end)
    local function walk(c, depth)
        if depth > 8 or c == nil or not valid(c) then return end
        if add(c) then nT = nT + 1 end
        local okN, n = pcall(function() return c:GetNumChildrenComponents() end)
        if not okN or type(n) ~= "number" then return end
        for i = 0, n - 1 do
            local okC, ch = pcall(function() return c:GetChildComponent(i) end)
            if okC then walk(ch, depth + 1) end
        end
    end
    pcall(function() walk(a:K2_GetRootComponent(), 0) end)
    for _, name in ipairs(NAMED_PARTS) do
        pcall(function() if add(a[name]) then nN = nN + 1 end end)
    end
    if not IL.partsInfo then
        IL.partsInfo = true
        if S.verbose then log("item parts found: %d by class, %d more by attachment, %d more by name", nC, nT, nN) end
    end
    return out
end
local function isA_(c, path)
    local ok, r = pcall(function() return c:IsA(StaticFindObject(path)) end)
    return ok and r == true
end
-- hide: every part hidden, its own flag remembered. show: each part back to its own flag.
-- returns how many visible parts it hid (0 on a hide = nothing to see was found)
local function hideParts(rec, hide)
    local a = rec.obj
    rec.saved = rec.saved or {}
    rec.vis = rec.vis or {}
    local hid, fresh = 0, 0
    for _, c in ipairs(parts(a)) do
        local key = c:GetAddress()
        local okH, h = pcall(function() return c.bHiddenInGame end)
        if hide then
            if rec.vis[key] == nil then
                if okH and type(h) == "boolean" then rec.vis[key] = h
                else rec.vis[key] = isA_(c, "/Script/Engine.ShapeComponent") end   -- shapes hidden by default
            end
            if not (okH and h == true) then pcall(function() c:SetHiddenInGame(true, false) end) end
            if okH and h == false then fresh = fresh + 1 end
            if rec.vis[key] == false then hid = hid + 1 end
        elseif rec.vis[key] ~= nil then
            pcall(function() c:SetHiddenInGame(rec.vis[key], false) end)
        end
        if isA_(c, "/Script/Engine.PrimitiveComponent") then
            rec.saved[key] = rec.saved[key] or {}
            for _, ch in ipairs(traceChannels()) do
                if hide then
                    if rec.saved[key][ch] == nil then
                        local okR, r = pcall(function() return c:GetCollisionResponseToChannel(ch) end)
                        if okR then rec.saved[key][ch] = r end
                    end
                    pcall(function() c:SetCollisionResponseToChannel(ch, 0) end)
                elseif rec.saved[key][ch] ~= nil then
                    pcall(function() c:SetCollisionResponseToChannel(ch, rec.saved[key][ch]) end)
                end
            end
        end
    end
    pcall(function() a.AbioticTargeting:SetEnabled(not hide) end)
    return hid, fresh
end
local function applyHide(rec, hide)
    if rec.hidden == hide then return end
    -- never hidden yet and should be visible: leave it exactly as the game made it
    if rec.hidden == nil and not hide then rec.hidden = false; return end
    -- Not SetActorHiddenInGame: AActor::bHidden replicates, so the host would hide the owner's copy on their client too.
    -- Not propagate=true on show: that also un-hides the collision sphere (the red wireframe dome, v1.4).
    local ok, r = pcall(hideParts, rec, hide)
    if not ok then log("hide/show failed: %s", tostring(r)) end
    if ok and hide and r == 0 and not rec.warned then
        rec.warned = true
        log("WARNING: hid a copy of %s but found no visible part to hide", (function() local o, n = pcall(function() return rec.obj.ItemDataRow.RowName:ToString() end); return o and n or "?" end)())
    end
    rec.hidden = hide
end
local function itemName(a)
    local ok, r = pcall(function() return str(a.ItemDataRow.RowName) end)
    return ok and r or "?"
end
-- decide visibility of one tracked item on THIS machine
local function check(rec)
    local a = rec.obj
    if not valid(a) then return false end
    local owner = tagOf(a)
    rec.owner = owner
    if owner then
        local me = myUid()
        local hide = me ~= nil and owner ~= me
        if rec.hidden ~= hide then
            applyHide(rec, hide)
            if S.verbose then log("%s %s copy of %s (tagged for %s, you are %s)", hide and "HIDE" or "SHOW", rec.kind, itemName(a), who(owner), who(me)) end
        elseif hide then
            -- still hidden? parts added later (or re-shown by the game) get hidden too
            local ok, _, fresh = pcall(hideParts, rec, true)
            if ok and fresh > 0 then if S.verbose then log("RE-HIDE %s: %d part(s) had become visible again", itemName(a), fresh) end end
        end
    elseif rec.hidden then
        applyHide(rec, false)
    end
    return true
end
local function track(a, kind)
    local key = a:GetAddress()
    if IL.tracked[key] and IL.tracked[key].obj == a then return IL.tracked[key] end
    local rec = { obj = a, kind = kind, checks = 0 }
    IL.tracked[key] = rec
    return rec
end
local function recheckAll()
    local n, h = 0, 0
    for key, rec in pairs(IL.tracked) do
        if not check(rec) then IL.tracked[key] = nil
        else n = n + 1; if rec.hidden then h = h + 1 end end
    end
    return n, h
end

-- ---------------------------------------------------------------- spawning copies (server)
local function spawnItem(row, count, loc, rot, uid, physics)
    local g = gm()
    if not g then return nil end
    IL.internal = IL.internal + 1
    IL.lastSpawned = nil
    if S.verbose then log("step: spawning %dx %s for %s", count or 0, tostring(row), uid and who(uid) or "nobody") end
    local a
    local ok, err = pcall(function()
        local out = {}
        a = g:SpawnItem({ Translation = loc, Rotation = rot or { X = 0, Y = 0, Z = 0, W = 1 }, Scale3D = { X = 1, Y = 1, Z = 1 } },
                        { RowName = FName(row) }, count, -1.0, not physics, false, nil,
                        FName(uid and (TAG .. uid) or "None"), 0, 0, out)
    end)
    IL.internal = IL.internal - 1
    if not ok then log("SpawnItem %s failed: %s", row, tostring(err)); return nil end
    if not valid(a) then a = IL.lastSpawned end
    if not valid(a) then log("SpawnItem %s gave no actor", row); return nil end
    if uid then
        -- belt and braces: make sure the tag is set and pushed
        if tagOf(a) ~= uid then setTag(a, uid, "dropped") end
        local id = ""
        pcall(function() id = str(a.ChangeableData.AssetID) end)
        if id ~= "" then data().drops[id] = { u = uid, t = os.time() }; markDirty() end
        check(track(a, "dropped"))
    end
    return a
end
local function vec(v) return { X = v.X, Y = v.Y, Z = v.Z } end
local function dist(a, b) local dx, dy, dz = a.X - b.X, a.Y - b.Y, a.Z - b.Z; return math.sqrt(dx * dx + dy * dy + dz * dz) end

-- furniture / big deployable items (ItemTable_Deployables + _CraftingBenches). When a break drops one of these, the
-- thing came off whole (barrel, fridge, harvested plant...): that drop stays vanilla, one copy for whoever is there.
IL.deploy = {}
for n in ("Aquarium_Large,ArcadeMachine,Armchair_Fancy,Armchair_Modern_01,Armchair_Tall_Fancy,Armchair_Vintage,Banner_Gatekeeper,Banner_Order,Bed_Res_01,Bench_Locker,Bench_Park,Bookshelf_Office_Medium,Bookshelf_Office_Tall,Bookshelf_Vintage,Cabinet_Fancy,Cabinet_Lab_01,Cabinet_Vintage,Chair_Beanbag_01,Chair_Corner_01,Chair_Fancy_03,Chair_Fancy_04,Chair_Office_03,Chair_Power,Chair_Rustic,Chest_Vintage,ChurchPew_Salem,Container_LootSpillBag,Couch_Fancy_L,Couch_Modern_01,Couch_VOTV_Plaid,Crate_HGatekeeper,Crate_HInquisitor,Crate_HMusicBox,Crate_HOrnate,Crate_HSecurity,Deployable_Antelight,Deployable_Antelight_GRN,Deployable_Antelight_RGB,Deployable_Antelight_blue,Deployable_Antelight_orange,Deployable_Antelight_pink,Deployable_Antelight_red,Deployable_Antelight_space,Deployable_ArmoryLocker,Deployable_Barrel,Deployable_Barricade_Full,Deployable_Barricade_Half,Deployable_Barricade_Window,Deployable_Bench_Ammo,Deployable_Bench_Chemistry,Deployable_Bench_Cooking,Deployable_Bench_Crafting,Deployable_Bench_Distillation,Deployable_Bench_Repair,Deployable_Bench_Upgrade,Deployable_CementBagWall_Block,Deployable_CementBagWall_Corner,Deployable_CementBagWall_Curve,Deployable_CementBagWall_HalfCurve,Deployable_CementBagWall_Straight,Deployable_Chair_Executive_01,Deployable_Chair_Office_01,Deployable_Chair_Vintage,Deployable_CoffeeTable_01,Deployable_CoffeeTable_Fancy_01,Deployable_ConferenceTable_Office,Deployable_Cot_Military,Deployable_Couch_Office_Armchair_01,Deployable_Couch_Office_Long_01,Deployable_Couch_Office_Medium_01,Deployable_Couch_fancy_01,Deployable_Desk_01,Deployable_Desk_02,Deployable_Desk_Executive_01,Deployable_DiningTable_Fancy_01,Deployable_DiningTable_Fancy_02,Deployable_DiningTable_Vintage_01,Deployable_DiningTable_Vintage_02,Deployable_DiscTurret,Deployable_FaucetSink,Deployable_FilingCabinet_Huge,Deployable_FilingCabinet_Large,Deployable_FilingCabinet_Medium,Deployable_FilingCabinet_Small,Deployable_Fridge,Deployable_GardenPlot,Deployable_GardenPlot_Large,Deployable_GardenPlot_Medium,Deployable_GardenPlot_Round,Deployable_GaseousNest,Deployable_LDesk_01,Deployable_Magazine_Stand,Deployable_MakeshiftStove,Deployable_Medkit,Deployable_Plant_Floor_Office_01,Deployable_PottedPlant_01,Deployable_PottedPlant_02,Deployable_PottedPlant_03,Deployable_PottedPlant_04,Deployable_PottedPlant_06,Deployable_RockingChair_Vintage,Deployable_RoundTable_Office_01,Deployable_Snowtent,Deployable_Stool_Office_01,Deployable_TableCard,Deployable_Table_Cafeteria,Deployable_TrashCan_01,Deployable_TrashCan_Small,Deployable_VinePlant,Deployable_WaterCooler,Deployable_WaterFilter,Desk_Fancy_01,Desk_Lab_01,Freezer,Fridge_Hazard,IS0018,Lamp_Standing_Office_01,Leyak_Containment,NightThrone,Painting_Desk,Painting_Landscape,Painting_Landscape_Fancy,Painting_Landscape_Large,Painting_Landscape_Large_Fancy,Painting_Square,Painting_Square_Fancy,Painting_Vertical,Painting_Vertical_Fancy,RockingChair_Rustic,Stool_Arcade,TV,Table_Arcade,Table_Rustic,Table_Side_01,TrashCan_Park,TrashCan_VOTV,WarmingDrawer,bed_garden,bench_garden,bench_order,bench_torii,chair_zabuton,chest_reservoir,constructionsign,cubicle_full,cubicle_full_half,cubicle_full_nowindow,cubicle_full_window,cubicle_gate,cubicle_gate_half,cubicle_half,cubicle_half_half,cubicle_half_nowindow,cubicle_half_window,gatekeeper_forcefield,moosehead,rug_peccary,scarecrow_farming,table_kotatsu,table_order,tapestry_order,votv_AshTray,votv_BedsideTable_Brown,votv_CardboardBox_Large,votv_CardboardBox_Small,votv_Chair_Dirty,votv_Chair_Garden,votv_Chair_Lounge,votv_Chair_Office,votv_Chair_Plastic,votv_Cone,votv_Couch_Dirty,votv_Dresser,votv_Hoop,votv_Mattress,votv_MiniFridge,votv_NeonSign_ASO,votv_NeonSign_Stolas,votv_Table_Garden,votv_Trampoline,votv_WasteBin,votv_jammer,votv_jammer_relay,votv_mannequin,votv_microwave,votv_substation,votv_table_coffee,votv_worldglobe,wishingshelf,wishingshelf_stocking,xmas_snowglobe"):gmatch("[^,]+") do IL.deploy[n:lower()] = true end
local function isDeployable(row) return IL.deploy[tostring(row or ""):lower()] == true end

-- ---------------------------------------------------------------- 1. enemy / crate drops
-- GenerateLootDrop(SalvageDropRow, Origin, BoxExtent, HasLifespan, TryPlaceInInventory, inventoryOwner, IsMicroNode,
--   IsNotReceivingDamage, TextureVariant, ExtraStackCount, IgnoreTags, RandomRotation, RotationOverride,
--   AlwaysDropOverflow, BuffTags&, ExtraLootChance, DynamicProperties&, LootIsGenerated&)
-- NEVER spawn items inside a Blueprint hook callback: UE4SS holds m_thread_actions_mutex there, SpawnItem may
-- block-load the item class, and the loading thread's StaticConstructObject hook waits for that same mutex
-- -> deadlock (the 2026-11-12 freezes). Deferred game-thread actions run without the mutex.
IL.inDrop = false
local function onGenerateLootDrop(ctx, pRow, pOrigin, pExtent, pLife, pTryInv, pOwner, pMicro, pNoDmg, pTV, pExtra,
                                   pIgnore, pRandRot, pRotOver, pOverflow, pBuff, pChance, pDyn, pGenerated)
    if not S.enabled or not S.drops or IL.inDrop then return end
    if pTryInv:get() then return end           -- goes straight into someone's inventory: already personal
    local row = str(pRow:get().RowName)
    local o = pOrigin:get(); local origin = { X = o.X, Y = o.Y, Z = o.Z }
    local e = pExtent:get(); local ext = { X = e.X, Y = e.Y, Z = e.Z }
    local life = pLife:get()
    local extra = 0.0; pcall(function() extra = pChance:get() end)
    local now = os.clock()
    -- the vanilla roll's items: dropped items spawned during this call, near Origin
    local reach = math.max(ext.X, ext.Y, ext.Z) + 300
    local mine = {}
    local keep = {}
    for _, p in ipairs(IL.pendingNew) do
        if valid(p.obj) and now - p.t < 0.5 then
            local okL, l = pcall(function() return p.obj:K2_GetActorLocation() end)
            if okL and dist(l, origin) <= reach and not tagOf(p.obj) then mine[#mine + 1] = p.obj
            else keep[#keep + 1] = p end
        end
    end
    IL.pendingNew = keep
    local inList = {}
    -- (cached table only: loading DT_Salvage here, inside a hook, could deadlock)
    for _, en in ipairs((IL.salvage or {})[row] or {}) do inList[tostring(en.item):lower()] = true end
    if not IL.salvage then for _, a in ipairs(mine) do inList[itemName(a):lower()] = true end end
    for _, a in ipairs(mine) do
        if isDeployable(itemName(a)) and inList[itemName(a):lower()] then
            if S.verbose then log("DROP list '%s': dropped as a whole deployable (%s): vanilla, not instanced", row, itemName(a)) end
            return
        end
    end
    local players = rollList()
    if #players <= 1 then return end      -- alone: nothing to instance
    -- the vanilla items go to the player nearest the drop
    local best, bestD
    for _, p in ipairs(onlinePlayers()) do
        local okL, l = pcall(function() return p.char:K2_GetActorLocation() end)
        if okL then local d = dist(l, origin); if not bestD or d < bestD then best, bestD = p.uid, d end end
    end
    best = best or players[1]
    local names = {}
    for _, a in ipairs(mine) do
        setTag(a, best, "dropped")
        local id = ""; pcall(function() id = str(a.ChangeableData.AssetID) end)
        if id ~= "" then data().drops[id] = { u = best, t = os.time() }; markDirty() end
        local okC, c = pcall(function() return a.ChangeableData.CurrentStack end)
        names[#names + 1] = (okC and c or 1) .. "x " .. itemName(a)
        check(track(a, "dropped"))
    end
    if S.verbose then log("DROP list '%s' at (%.0f,%.0f,%.0f): game's roll -> %s: %s", row, origin.X, origin.Y, origin.Z, who(best),
        #names > 0 and table.concat(names, ", ") or "(nothing)") end
    local lifeOn = life
    gtDelay(10, function()
    IL.inDrop = true
    for _, uid in ipairs(players) do
        if uid ~= best then
            local items = {}
            for _, it in ipairs(rollList_(row, extra)) do if not isSpecial(it.item) and not isDeployable(it.item) then items[#items + 1] = it end end
            local spawned = 0
            for _, it in ipairs(items) do
                local loc = { X = origin.X + (math.random() * 2 - 1) * (ext.X + 30),
                              Y = origin.Y + (math.random() * 2 - 1) * (ext.Y + 30),
                              Z = origin.Z + math.random() * ext.Z + 20 }
                local a = spawnItem(it.item, it.count, loc, nil, uid, true)
                if a then
                    spawned = spawned + 1
                    if lifeOn and S.droplifespan > 0 then pcall(function() a:SetLifeSpan(S.droplifespan) end) end
                end
            end
            if S.verbose then log("DROP list '%s': own roll for %s -> %s (%d spawned, visible only to them)", row, who(uid), fmtItems(items), spawned) end
        end
    end
    IL.inDrop = false
    end)
end

-- ---------------------------------------------------------------- 2. corpses
local function corpseIsLoot(c)
    local o = {}
    local ok = pcall(function() c:GetTypeOfInteractableCorpse(o, o, o, o, o) end)
    return ok and o.LootItem == true
end
local function setLooted(c, v)
    pcall(function() c:FlushNetDormancy() end)
    c.HasBeenLooted = v
    pcall(function() cdo(P.PUSH):MarkPropertyDirtyFromRepIndex(c, REP_LOOTED, FName("HasBeenLooted")) end)
end
local function onCorpseInteract(ctx, pChar)
    if not S.enabled or not S.corpses or not isServer() then return end
    local c = ctx:get()
    local ch = pChar:get()
    if not valid(c) or not valid(ch) then return end
    if not corpseIsLoot(c) then return end
    local uid = uidOfChar(ch)
    if not uid then return end
    local key = c:GetFullName():match("%s(.+)$") or c:GetFullName()
    local d = data()
    local by = d.corpses[key] or {}
    d.corpses[key] = by
    if by[uid] then
        if S.verbose then log("CORPSE %s: %s already searched this body; nothing", key:match("[^%.:]+$") or key, who(uid)) end
        return
    end
    local others = 0
    for _ in pairs(by) do others = others + 1 end
    if others == 0 then
        -- the game's own search just ran for this player (or the body was searched before the mod)
        by[uid] = true; markDirty()
        if S.verbose then log("CORPSE %s: %s searched it (game's roll, first searcher)", key:match("[^%.:]+$") or key, who(uid)) end
        return
    end
    -- searched by someone else before: give this player their own search (deferred, see the spawn note)
    by[uid] = true; markDirty()
    gtDelay(10, function()
    if not valid(c) or not valid(ch) then return end
    setLooted(c, false)
    local ok, err = pcall(function() c:DropLoot(true, ch) end)
    local got = c.HasBeenLooted
    setLooted(c, true)
    if S.verbose then log("CORPSE %s: own roll for %s -> %s (placed in their inventory)", key:match("[^%.:]+$") or key, who(uid),
        ok and (got and "loot given" or "the roll came up empty") or ("FAILED: " .. tostring(err))) end
    end)
end
-- clients: a body someone else searched still offers "search" to you
IL.mySearched = {}
local function onCorpseCanInteract(ctx, pComp, pSuccess)
    if not S.enabled or not S.corpses then return end
    local c = ctx:get()
    if not valid(c) or pSuccess:get() then return end
    if not c.HasBeenLooted or c.IsGibbed or not c.IsInteractable then return end
    if IL.mySearched[c:GetAddress() .. "|" .. tostring(myUid())] then return end
    if not corpseIsLoot(c) then return end
    pSuccess:set(true)
end
local function onCorpseLocalFX(ctx)
    local c = ctx:get()
    -- keyed per identity: in test mode (F7) each fake player searches the same body
    if valid(c) then IL.mySearched[c:GetAddress() .. "|" .. tostring(myUid())] = true end
end

-- ---------------------------------------------------------------- 3. floor loot (items placed in the level)
IL.lastPicker = nil      -- { uid, t } from TryPickupItemAndFindBestSlotForIt
IL.runtime = {}          -- address -> true for items spawned at runtime (FinishSpawningActor)
local function isPlaced(a)
    local ok, r = pcall(function() return a:HasAnyFlags(0x00080000) end)   -- RF_WasLoaded
    if ok and type(r) == "boolean" then return r end
    if not IL.flagWarned then IL.flagWarned = true; log("HasAnyFlags unavailable; telling level items apart by spawn tracking") end
    return not IL.runtime[a:GetAddress()]
end
local function nearestPlayerUid(loc)
    local best, bd
    for _, p in ipairs(onlinePlayers()) do
        local okL, l = pcall(function() return p.char:K2_GetActorLocation() end)
        if okL then local dd = dist(l, loc); if not bd or dd < bd then best, bd = p.uid, dd end end
    end
    return best
end
local function floorEntry(a)
    local e = {}
    local ok = pcall(function()
        e.row = str(a.ItemDataRow.RowName)
        e.stack = a.ChangeableData.CurrentStack
        local l = a:K2_GetActorLocation(); e.x, e.y, e.z = l.X, l.Y, l.Z
        local q = a:K2_GetActorRotation(); e.pitch, e.yaw, e.roll = q.Pitch, q.Yaw, q.Roll
    end)
    if not ok or not e.row or e.row == "None" then return nil end
    if (e.stack or 0) < 1 then e.stack = 1 end
    e.taken, e.copies = {}, {}
    return e
end
-- FRotator::Quaternion, in Lua (no struct return values through UE4SS)
local function quatFromRot(pitch, yaw, roll)
    local h = math.pi / 360
    local sp, cp = math.sin((pitch or 0) * h), math.cos((pitch or 0) * h)
    local sy, cy = math.sin((yaw or 0) * h), math.cos((yaw or 0) * h)
    local sr, cr = math.sin((roll or 0) * h), math.cos((roll or 0) * h)
    return { X = cr * sp * sy - sr * cp * cy, Y = -cr * sp * cy - sr * cp * sy,
             Z = cr * cp * sy - sr * sp * cy, W = cr * cp * cy + sr * sp * sy }
end
local function giveFloorCopies(key, e, uids)
    local made = {}
    for _, uid in ipairs(uids) do
        if not e.taken[uid] and not e.copies[uid] then
            local a = spawnItem(e.row, e.stack, { X = e.x, Y = e.y, Z = e.z }, quatFromRot(e.pitch, e.yaw, e.roll), uid, false)
            if a then
                local id = ""; pcall(function() id = str(a.ChangeableData.AssetID) end)
                e.copies[uid] = id ~= "" and id or true
                if id ~= "" then data().drops[id].floor = key end
                made[#made + 1] = who(uid)
            end
        end
    end
    if #made > 0 then markDirty() end
    return made
end
local function everyone()
    local list, seen = {}, {}
    for _, u in ipairs(rollList()) do if not seen[u] then seen[u] = true; list[#list + 1] = u end end
    for u in pairs(data().players) do if not seen[u] then seen[u] = true; list[#list + 1] = u end end
    return list
end
-- native pre-hook: any actor destroyed from blueprint code
local function onDestroy(ctx)
    if not S.enabled or IL.internal > 0 then return end
    local a = ctx:get()
    if not valid(a) then return end
    local key = a:GetAddress()
    local rec = IL.tracked[key]
    local isItem = rec ~= nil
    if not isItem then
        IL.clsItem = valid(IL.clsItem) and IL.clsItem or StaticFindObject(P.ITEM)
        IL.clsDropped = valid(IL.clsDropped) and IL.clsDropped or StaticFindObject(P.DROPPED)
        local ok, r = pcall(function() return a:IsA(IL.clsItem) or a:IsA(IL.clsDropped) end)
        isItem = ok and r
    end
    if not isItem then return end
    IL.tracked[key] = nil
    IL.runtime[key] = nil
    if not isServer() then return end
    local picked = false
    pcall(function() picked = a.HasBeenPickedUp == true end)
    local id = ""; pcall(function() id = str(a.ChangeableData.AssetID) end)
    local d = data()
    local tagged = id ~= "" and d.drops[id] or nil
    local picker = IL.lastPicker and (os.clock() - IL.lastPicker.t) < 0.5 and IL.lastPicker.uid or nil
    if tagged then
        d.drops[id] = nil; markDirty()
        if picked then
            if S.verbose then log("PICKUP %s: %s took their own copy (tagged for %s)", itemName(a), who(picker or tagged.u), who(tagged.u)) end
            if tagged.floor and d.placed[tagged.floor] then d.placed[tagged.floor].taken[tagged.u] = true end
        end
        return
    end
    if not picked or not S.floorloot then return end
    if not isPlaced(a) then return end
    if isSpecial(itemName(a)) then if S.verbose then log("FLOOR %s is a special item: not copied", itemName(a)) end; return end
    local pkey = a:GetFullName():match("%s(.+)$") or a:GetFullName()
    local e = d.placed[pkey] or floorEntry(a)
    if not e then return end
    d.placed[pkey] = e
    picker = picker or nearestPlayerUid(a:K2_GetActorLocation()) or myUid()
    e.taken[picker] = true
    markDirty()
    local others = {}
    -- copies only for the players who are here now: an offline player gets theirs when they next join
    -- (playerSweep), instead of a spawn for every player this world has ever seen on each pick-up (lag, 2026-11-20)
    for _, u in ipairs(rollList()) do if u ~= picker then others[#others + 1] = u end end
    -- spawn after this frame (the original is being destroyed right now)
    gtDelay(50, function()
        local made = giveFloorCopies(pkey, e, others)
        if S.verbose then log("FLOOR %s (%dx %s): %s took the level's copy; own copies left for: %s", pkey:match("[^%.:]+$") or pkey,
            e.stack, e.row, who(picker), #made > 0 and table.concat(made, ", ") or "nobody else") end
    end)
end

-- ---------------------------------------------------------------- 3b. world lootables (micro nodes)
-- Paper stacks, beakers, backpacks... are Resource_MicroNode actors, not items. Taking one runs
-- ResourceNode_ParentBP:GenerateItemDrop(TryPlaceInInventory=true, PlayerCharacter, ...) on the host, which puts the
-- loot straight into the taker's inventory, then the node is depleted (IsDepleted, rep index 10) for everyone.
-- Instanced: nothing is spawned. The host un-depletes the node again while someone has not taken it yet, and every
-- game hides the node only from the players who already took it. The next player's take is the game's own pickup.
-- Furniture you break down is a ResourceNode too but not a micro node: untouched here.
local REP_DEPLETED = 10
IL.nodeObj = {}          -- key -> node object (this game)
IL.nodeRec = {}          -- key -> hide record (applyHide)
IL.mine = nil            -- this game's own "I took it" marks: [key .. "|" .. uid] = true (clients; host uses data)
local function nodeKeyOf(n) return n:GetFullName():match("%s(.+)$") or n:GetFullName() end
local function isMicro(n)
    IL.clsMicro = valid(IL.clsMicro) and IL.clsMicro or StaticFindObject(P.MICRO)
    local ok, r = pcall(function() return n:IsA(IL.clsMicro) end)
    return ok and r == true
end
local function mineFile() return DIR .. "mine_" .. worldName() .. ".lua" end
local function mine()
    if IL.mine then return IL.mine end
    IL.mine = {}
    local f = io.open(mineFile(), "r")
    if f then
        local fn = load(f:read("*a")); f:close()
        if fn then local ok, t = pcall(fn); if ok and type(t) == "table" then IL.mine = t end end
    end
    return IL.mine
end
local function saveMine()
    local f = io.open(mineFile(), "w")
    if f then f:write("return " .. serialize(IL.mine or {})); f:close() end
end
-- has this identity taken the lootable?
local function nodeTaken(key, uid)
    if not uid then return false end
    if isServer() then
        local t = data().nodes[key]
        return t ~= nil and t[uid] == true
    end
    return mine()[key .. "|" .. uid] == true
end
-- Finding a node whose level is loaded. NEVER StaticFindObject(key) here: when the node's level is not loaded
-- (other area, Night Realm...) the lookup misses, and on a miss UE4SS 4fb9b615 falls back to a full GUObjectArray
-- scan that reads every object's Outer while the async loader is creating objects -> access violation in
-- UObject::GetOutermost (crashes 2026-11-11 and 2026-11-14). This ran every 5 s for every remembered node.
-- FindAllOf only walks UE4SS's hash tables, so it sees loaded objects only and never does that scan.
local function nodeClassOf(key)
    local name = key:match("[^%.:]+$") or key
    return name:match("^(.-_C)_%d+$")
end
local function loadedNodesOf(clsName, cache)
    local byKey = cache[clsName]
    if byKey then return byKey end
    byKey = {}
    local ok, list = pcall(FindAllOf, clsName)
    if ok and type(list) == "table" then
        for _, o in ipairs(list) do
            if valid(o) then
                local okK, k = pcall(nodeKeyOf, o)
                if okK and k then byKey[k] = o end
            end
        end
    end
    cache[clsName] = byKey
    return byKey
end
local function findLoadedNode(key, cache)
    local cn = nodeClassOf(key)
    local o = cn and loadedNodesOf(cn, cache)[key]
    if o then return o end
    return loadedNodesOf("Resource_MicroNode_ParentBP_C", cache)[key]
end
local function nodeRefreshOne(key, n, cache)
    n = (n and valid(n)) and n or (valid(IL.nodeObj[key]) and IL.nodeObj[key]) or nil
    if not n then n = findLoadedNode(key, cache or {}) end
    if not n then return end
    IL.nodeObj[key] = n
    -- depleted for real (everyone took it, or it was never instanced): the game hides it; forget our marks so a
    -- respawned node is fresh for everyone
    local okD, dep = pcall(function() return n.IsDepleted end)
    -- (the host un-depletes it a frame after each take, and clients may see that brief "depleted": only a node that
    -- stays depleted for 10 s really is gone)
    IL.depSince = IL.depSince or {}
    if okD and dep == true then IL.depSince[key] = IL.depSince[key] or os.clock() else IL.depSince[key] = nil end
    if okD and dep == true and os.clock() - IL.depSince[key] > 10 then
        if isServer() then if data().nodes[key] then data().nodes[key] = nil; markDirty() end
        else local m, changed = mine(), false
            for k in pairs(m) do if k:sub(1, #key + 1) == key .. "|" then m[k] = nil; changed = true end end
            if changed then saveMine() end
        end
    end
    -- host: a node still standing that EVERY known player "took" can't be right (the last take always depletes
    -- it): left over from a failed take (full inventory) recorded by v1.15 or older. Give it back to everyone.
    if isServer() and okD and dep == false and data().nodes[key] then
        local t, all = data().nodes[key], true
        for _, u in ipairs(everyone()) do if not t[u] then all = false; break end end
        if all then
            data().nodes[key] = nil; markDirty()
            if S.verbose then log("LOOTABLE %s: everyone was marked as having taken it but it is still there; un-marked (old failed take)",
                key:match("[^%.:]+$") or key) end
        end
    end
    local rec = IL.nodeRec[key]
    if not rec or rec.obj ~= n then rec = { obj = n, kind = "node" }; IL.nodeRec[key] = rec end
    local hide = (not (okD and dep == true)) and nodeTaken(key, myUid())
    if rec.hidden ~= hide then
        applyHide(rec, hide)
        if S.verbose then log("%s lootable %s (you are %s)", hide and "HIDE" or "SHOW", key:match("[^%.:]+$") or key, who(myUid())) end
    end
end
local function nodeRefreshAll()
    local keys = {}
    if isServer() then for k in pairs(data().nodes) do keys[k] = true end
    else for k in pairs(mine()) do keys[k:match("^(.*)|[^|]*$") or k] = true end end
    for k in pairs(IL.nodeRec) do keys[k] = true end
    local cache = {}                       -- class name -> { key -> loaded node }, built once per refresh
    for k in pairs(keys) do pcall(nodeRefreshOne, k, nil, cache) end
end
IL.nodeRefreshAll = nodeRefreshAll
-- ---------------------------------------------------------------- lootables: what a node can give, players' item counts
-- the item rows a lootable can give: its item (GlobalItem) or its salvage list's items (cached table only; never
-- loaded from inside a hook). nil = unknown.
local function nodeWatchSet(tbl, row)
    if not row or row == "" or row == "None" then return nil end
    if tbl == 0 then return { [row:lower()] = true } end
    local list = IL.salvage and IL.salvage[row]
    if not list and IL.salvage then
        local lr = row:lower()
        for k, v in pairs(IL.salvage) do if k:lower() == lr then list = v; break end end
    end
    if not list or #list == 0 then return nil end
    local w = {}
    for _, en in ipairs(list) do w[tostring(en.item):lower()] = true end
    return w
end
local PLAYER_INVS = { "CharacterInventory", "CharacterHotbarInventory", "CharacterEquipSlotInventory" }
-- { row(lowercase) = count } over a character's own inventories (read only: safe inside hooks)
local function invCounts(ch)
    local c = {}
    for _, name in ipairs(PLAYER_INVS) do
        local okI, inv = pcall(function() return ch[name] end)
        if okI and valid(inv) then
            pcall(function()
                local arr = inv.CurrentInventory
                for i = 1, arr:GetArrayNum() do
                    local sl = arr[i]
                    local r = str(sl.ItemDataTable.RowName):lower()
                    if r ~= "" and r ~= "none" then c[r] = (c[r] or 0) + math.max(1, sl.ChangeableData.CurrentStack or 1) end
                end
            end)
        end
    end
    return c
end
local takeBack        -- defined after the container slot helpers it uses
IL.invCache = {}
local function onNodeItemDrop(ctx, pTryInv, pChar, pNoDmg)
    if not S.enabled or not S.lootables or not isServer() then return end
    local n = ctx:get()
    if not valid(n) or not pTryInv:get() then return end      -- broken by damage: not a pick-up
    if not isMicro(n) then return end                        -- furniture etc.: the drop code handles it
    local ch = pChar:get()
    local picker = valid(ch) and uidOfChar(ch) or nil
    if not picker then return end
    local okR, tbl, row = pcall(function() return n.DropRow.Table, str(n.DropRow.RowName) end)
    if not okR then return end
    local key = nodeKeyOf(n)
    local short = key:match("[^%.:]+$") or key
    if tbl == 0 and (isSpecial(row) or isDeployable(row)) then
        if S.verbose then log("LOOTABLE %s gives %s, a special item: first come, first served", short, tostring(row)) end; return
    end
    IL.nodeObj[key] = n
    -- what this call just put in the picker's inventory (the game adds it synchronously, before this hook runs)
    local now = invCounts(ch)
    local prev = IL.invCache[picker]
    IL.invCache[picker] = now
    local gained = {}
    local watch = nodeWatchSet(tbl, row)
    if prev then
        for r, c in pairs(now) do
            if (not watch or watch[r]) and c > (prev[r] or 0) then gained[r] = c - (prev[r] or 0) end
        end
    end
    -- The game sets IsDepleted right after this call, but only if the item really went somewhere
    -- ("Loot Is Generated?"). With a full inventory nothing is picked up and the node stays: then this was not a
    -- take, and we must not hide it from this player (bug seen 2026-11-14, Enethiol with a full inventory).
    gtDelay(10, function()
        if not valid(n) then return end
        local okD, dep = pcall(function() return n.IsDepleted end)
        if not (okD and dep == true) then
            if S.verbose then log("LOOTABLE %s: %s tried to take it but nothing was picked up (inventory full?), so it stays for them",
                short, who(picker)) end
            return
        end
        local d = data()
        d.nodes[key] = d.nodes[key] or {}
        local repeatTake = d.nodes[key][picker] == true
        d.nodes[key][picker] = true
        markDirty()
        if repeatTake then
            -- they already had theirs (their game didn't hide it: no mod, old mod, or clicking very fast).
            -- The host can't refuse the pick-up, so take back what it just gave them.
            local back = {}
            if valid(ch) then
                for r, c in pairs(gained) do
                    local got = takeBack(ch, r, c)
                    if got > 0 then back[#back + 1] = got .. "x " .. r end
                end
                IL.invCache[picker] = invCounts(ch)
            end
            if S.verbose then log("LOOTABLE %s: %s took it AGAIN; took back %s", short, who(picker),
                #back > 0 and table.concat(back, ", ") or (prev and "nothing (nothing new found)" or "nothing (no inventory snapshot yet)")) end
        end
        local left = {}
        for _, u in ipairs(everyone()) do if not d.nodes[key][u] then left[#left + 1] = u end end
        if #left == 0 then
            if S.verbose then log("LOOTABLE %s: %s took it; everyone has had theirs, so it stays gone", short, who(picker)) end
            pcall(nodeRefreshOne, key, n)     -- drop our own hide now, so a respawn shows it to everyone
            return
        end
        -- bring it back for the others
        local ok, err = pcall(function()
            n:FlushNetDormancy()
            n.IsDepleted = false
            cdo(P.PUSH):MarkPropertyDirtyFromRepIndex(n, REP_DEPLETED, FName("IsDepleted"))
            n:OnRep_IsDepleted()
            n:SaveNodeToWorldSave()
        end)
        nodeRefreshOne(key, n)
        local names = {}
        for _, u in ipairs(left) do names[#names + 1] = who(u) end
        if S.verbose then log("LOOTABLE %s: %s %s; still there for: %s%s", short, who(picker), repeatTake and "(again)" or "took it", table.concat(names, ", "),
            ok and "" or (" (restore FAILED: " .. tostring(err) .. ")")) end
    end)
end
-- every game: you took it -> it's gone for you (the interacting game plays the local pickup FX)
-- a string that changes whenever anything in your own inventories changes (rows, stacks, liquid);
-- with only (a set of item rows): just how many of those you carry (so another pickup at the same moment doesn't count)
local function myInvSig(only)
    local pc = localPC()
    local ok, ch = pcall(function() return pc.Pawn end)
    if not ok or not valid(ch) then return nil end
    local parts = {}
    for _, name in ipairs({ "CharacterInventory", "CharacterHotbarInventory", "CharacterEquipSlotInventory" }) do
        local okI, inv = pcall(function() return ch[name] end)
        if okI and valid(inv) then
            pcall(function()
                local arr = inv.CurrentInventory
                for i = 1, arr:GetArrayNum() do
                    local sl = arr[i]
                    local cd = sl.ChangeableData
                    local r = str(sl.ItemDataTable.RowName)
                    if not only then parts[#parts + 1] = r .. ":" .. tostring(cd.CurrentStack) .. ":" .. tostring(cd.LiquidLevel)
                    elseif only[r:lower()] then parts[#parts + 1] = tostring(cd.CurrentStack) .. ":" .. tostring(cd.LiquidLevel)
                    else parts[#parts + 1] = "-" end
                end
            end)
        end
    end
    if #parts == 0 then return nil end
    return table.concat(parts, ",")
end
local function onNodeLocalFX(ctx)
    if not S.enabled or not S.lootables or isServer() then return end   -- host knows from GenerateItemDrop
    local n = ctx:get()
    if not valid(n) or not isMicro(n) then return end
    local me = myUid()
    if not me then return end
    local key = nodeKeyOf(n)
    IL.nodeObj[key] = n
    -- the host decides; with a full inventory nothing is picked up and the node stays. We can't see the host's
    -- decision, but we can see our own inventory. Mark it as taken right away (so quitting mid-pickup can't give
    -- you a second one), and take the mark back if nothing arrives in your inventory within ~2 s.
    local mk = key .. "|" .. me
    local already = mine()[mk] == true
    mine()[mk] = true
    saveMine()
    gtDelay(10, function() pcall(nodeRefreshOne, key, n) end)    -- hide at once (fast clicking re-grabbed it)
    gtDelay(400, function() pcall(nodeRefreshOne, key, n) end)
    -- watch only what this lootable can give: its item (GlobalItem), or the items of its salvage list (cached
    -- only, never loaded inside this hook); unknown list -> watch everything
    local okR, tbl, row = pcall(function() return n.DropRow.Table, str(n.DropRow.RowName) end)
    local watch = okR and nodeWatchSet(tbl, row) or nil
    local before = myInvSig(watch)
    if already or not before then return end      -- can't read the inventory: keep the mark (old behaviour)
    local tries = 0
    local function check()
        tries = tries + 1
        local now = myInvSig(watch)
        if now and now ~= before then return end  -- it arrived: really taken
        if tries < 4 then gtDelay(500, check); return end
        mine()[mk] = nil
        saveMine()
        pcall(nodeRefreshOne, key, n)
        if S.verbose then log("LOOTABLE %s: nothing arrived in your inventory (full?), so it stays for you", key:match("[^%.:]+$") or key) end
    end
    gtDelay(300, check)
end
-- every game: a lootable you already took offers nothing
IL.nodeKeyByAddr = {}
local function onNodeCanInteract(ctx, pComp, pSuccess)
    if not S.enabled or not S.lootables then return end
    local n = ctx:get()
    if not valid(n) or not pSuccess:get() then return end
    local addr = n:GetAddress()
    local key = IL.nodeKeyByAddr[addr]
    if key == nil then key = isMicro(n) and nodeKeyOf(n) or false; IL.nodeKeyByAddr[addr] = key end
    if key and nodeTaken(key, myUid()) then pSuccess:set(false) end
end
local function onTryPickup(ctx)
    if not isServer() then return end
    local ch = ctx:get()
    IL.lastPicker = { uid = uidOfChar(ch), t = os.clock() }
end

-- ---------------------------------------------------------------- 4. containers
local function contKey(c) return c:GetFullName():match("%s(.+)$") or c:GetFullName() end
local function contShort(key) return key:match("[^%.:]+$") or key end
local function isLootContainer(c)
    local ok, r = pcall(function()
        if c.DeployedByPlayer then return false end
        local row = str(c.InitialContainerLoot.RowName)
        return row ~= "" and row ~= "None"
    end)
    return ok and r
end
local function invOf(c)
    local ok, inv = pcall(function() return c.ContainerInventory end)
    if ok and valid(inv) then return inv end
    return nil
end
local function readEntry(row, cd)
    local e = { row = row, id = str(cd.AssetID), dur = cd.CurrentItemDurability, maxdur = cd.MaxItemDurability,
                stack = cd.CurrentStack, ammo = cd.CurrentAmmoInMagazine, liq = cd.LiquidLevel,
                liqt = cd.CurrentLiquid, tv = str(cd.TextureVariantRow.RowName), dyn = cd.DynamicState,
                pms = str(cd.PlayerMadeString), tags = {}, ptags = {}, props = {} }
    pcall(function() cd.GameplayTags.GameplayTags:ForEach(function(_, t) e.tags[#e.tags + 1] = str(t:get().TagName) end) end)
    pcall(function() cd.GameplayTags.ParentTags:ForEach(function(_, t) e.ptags[#e.ptags + 1] = str(t:get().TagName) end) end)
    pcall(function() cd.DynamicProperties:ForEach(function(_, p) local v = p:get(); e.props[#e.props + 1] = { v.Key, v.Value } end) end)
    return e
end
local function snapshot(inv)
    local snap = { n = 0, slots = {} }
    local arr = inv.CurrentInventory
    local n = arr:GetArrayNum()
    snap.n = n
    for i = 1, n do
        local s = arr[i]
        local row = str(s.ItemDataTable.RowName)
        if row ~= "" and row ~= "None" then snap.slots[i - 1] = readEntry(row, s.ChangeableData) end
    end
    return snap
end
local function snapItems(snap)
    local t = {}
    for i = 0, (snap.n or 0) - 1 do local e = snap.slots[i]; if e then t[#t + 1] = (e.stack or 1) .. "x " .. e.row end end
    return #t > 0 and table.concat(t, ", ") or "(empty)"
end
-- write one inventory slot field by field, in place (whole-struct writes from Lua are unreliable)
local function writeSlot(inv, i, e)
    local sl = inv.CurrentInventory[i + 1]
    local cd = sl.ChangeableData
    if not e then
        sl.ItemDataTable.RowName = FName("None")
        cd.AssetID = ""; cd.CurrentStack = 0; cd.CurrentItemDurability = 0; cd.MaxItemDurability = 0
        cd.CurrentAmmoInMagazine = 0; cd.LiquidLevel = 0; cd.CurrentLiquid = 0
        cd.TextureVariantRow.RowName = FName("None"); cd.DynamicState = false; cd.PlayerMadeString = ""
        pcall(function() cd.GameplayTags.GameplayTags:Empty() end)
        pcall(function() cd.GameplayTags.ParentTags:Empty() end)
        pcall(function() cd.DynamicProperties:Empty() end)
        return
    end
    sl.ItemDataTable.RowName = FName(e.row)
    cd.AssetID = e.id or ""; cd.CurrentStack = e.stack or 1
    cd.CurrentItemDurability = e.dur or 0; cd.MaxItemDurability = e.maxdur or 0
    cd.CurrentAmmoInMagazine = e.ammo or 0; cd.LiquidLevel = e.liq or 0; cd.CurrentLiquid = e.liqt or 0
    cd.TextureVariantRow.RowName = FName((e.tv and e.tv ~= "") and e.tv or "None")
    cd.DynamicState = e.dyn == true; cd.PlayerMadeString = e.pms or ""
    if #(e.tags or {}) + #(e.ptags or {}) + #(e.props or {}) > 0 then
        if S.verbose then log("CONTAINER note: %s had tags/properties that are not restored", e.row) end
    end
end
local function pushInv(c, inv)
    pcall(function() c:FlushNetDormancy() end)
    pcall(function() cdo(P.PUSH):MarkPropertyDirtyFromRepIndex(inv, REP_INV, FName("CurrentInventory")) end)
    pcall(function() inv:OnRep_CurrentInventory() end)
end
-- host: remove up to `amount` of an item (lowercase row) from a character's own inventories (field writes, as above)
takeBack = function(ch, row, amount)
    local left = amount
    for _, name in ipairs(PLAYER_INVS) do
        if left <= 0 then break end
        local okI, inv = pcall(function() return ch[name] end)
        if okI and valid(inv) then
            local changed = false
            pcall(function()
                local arr = inv.CurrentInventory
                for i = arr:GetArrayNum(), 1, -1 do
                    if left <= 0 then break end
                    local sl = arr[i]
                    if str(sl.ItemDataTable.RowName):lower() == row then
                        local have = math.max(1, sl.ChangeableData.CurrentStack or 1)
                        if have > left then sl.ChangeableData.CurrentStack = have - left; left = 0
                        else left = left - have; pcall(writeSlot, inv, i - 1, nil) end
                        changed = true
                    end
                end
            end)
            if changed then pushInv(ch, inv) end
        end
    end
    return amount - left
end
local function restore(c, inv, snap)
    if S.verbose then log("CONTAINER step: clearing to restore saved contents") end
    inv:RevertInventoryToEmpty()
    local n = inv.CurrentInventory:GetArrayNum()
    for i = 0, n - 1 do
        if snap.slots[i] then
            if S.verbose then log("CONTAINER step: writing slot %d (%s)", i, snap.slots[i].row) end
            local ok, err = pcall(writeSlot, inv, i, snap.slots[i])
            if not ok then log("container slot %d write failed: %s", i, tostring(err)) end
        end
    end
    pushInv(c, inv)
end
-- a brand-new roll of this container's loot list, done by the game itself: RevertInventoryToEmpty, then
-- TryRegenerateContainerLoot (= the container's own roll: GetSalvageRow + CalculateItemDrop per entry, so the
-- cheat menu's drop rate applies). No item spawning or struct writes from Lua.
local function freshSnapshot(c, inv)
    local listName = str(c.InitialContainerLoot.RowName)
    if S.verbose then log("CONTAINER step: clearing for a fresh roll") end
    inv:RevertInventoryToEmpty()
    if S.verbose then log("CONTAINER step: game rolls '%s'", listName) end
    IL.ownRegen = true
    local ok, err = pcall(function() c:TryRegenerateContainerLoot() end)
    IL.ownRegen = false
    if not ok then log("TryRegenerateContainerLoot failed: %s", tostring(err)) end
    pushInv(c, inv)
    return snapshot(inv), listName
end
local function containerSwap(c, ch)
    if not valid(c) or not valid(ch) or not isLootContainer(c) then return end
    local uid = uidOfChar(ch)
    local inv = invOf(c)
    if not uid or not inv then return end
    local key = contKey(c)
    local d = data()
    local st = d.containers[key] or { inv = {} }
    d.containers[key] = st
    -- someone else is still inside: leave it (their clients block this; see onContainerCanInteract)
    local othersInside = 0
    pcall(function()
        c.ContainerUsers:ForEach(function(_, u)
            local other = u:get()
            if valid(other) and other:GetAddress() ~= ch:GetAddress() then othersInside = othersInside + 1 end
        end)
    end)
    if othersInside > 0 and st.holder and st.holder ~= uid then
        if S.verbose then log("CONTAINER %s: %s opened it while %s is inside - showing %s's contents (their games should block this)",
            contShort(key), who(uid), who(st.holder), who(st.holder)) end
        return
    end
    if st.holder == uid then
        if S.verbose then log("CONTAINER %s: %s opened their own contents: %s", contShort(key), who(uid), snapItems(snapshot(inv))) end
        return
    end
    if st.holder then st.inv[st.holder] = snapshot(inv) end
    local how
    if st.inv[uid] then
        restore(c, inv, st.inv[uid]); how = "their saved contents"
    elseif st.holder == nil and S.existing == "keep" then
        how = "the contents already in it (first player to open it since the mod was added)"
    else
        local _, list = freshSnapshot(c, inv); how = "a fresh roll of '" .. list .. "' (by the game, drop rate applies)"
    end
    st.holder = uid
    st.inv[uid] = snapshot(inv)
    markDirty()
    if S.verbose then log("CONTAINER %s (%s): %s gets %s -> %s", contShort(key), c:GetClass():GetFName():ToString(), who(uid), how, snapItems(st.inv[uid])) end
end
local function onContainerInteract(ctx, pChar)
    if not S.enabled or not S.containers or not isServer() then return end
    local c = ctx:get(); local ch = pChar:get()
    gtDelay(10, function() containerSwap(c, ch) end)
end
local function onContainerLeft(ctx, pUser)
    if not S.enabled or not S.containers or not isServer() then return end
    local c = ctx:get()
    if not valid(c) or not isLootContainer(c) then return end
    local inv = invOf(c); if not inv then return end
    local key = contKey(c)
    local st = data().containers[key]
    if not st or not st.holder then return end
    st.inv[st.holder] = snapshot(inv)
    markDirty()
    if S.verbose then log("CONTAINER %s: %s closed it, left: %s", contShort(key), who(st.holder), snapItems(st.inv[st.holder])) end
end
local function onContainerRegen(ctx)
    if not S.enabled or not S.containers or not isServer() or IL.ownRegen then return end
    local c = ctx:get()
    if not valid(c) or not isLootContainer(c) then return end
    local inv = invOf(c); if not inv then return end
    local key = contKey(c)
    local st = data().containers[key]
    if not st or not st.holder or not st.inv[st.holder] then return end
    local now = snapItems(snapshot(inv))
    if now ~= snapItems(st.inv[st.holder]) then
        data().containers[key] = nil; markDirty()
        if S.verbose then log("CONTAINER %s: the game refilled it -> everyone's own contents reset, next opener gets the new roll", contShort(key)) end
    end
end
-- host: don't let a second player open a loot container someone else is inside.
-- IsContainerBeingUsed is NOT reliable (stays true after everyone leaves), and ContainerUsers is not
-- replicated, so this only blocks on the host; on clients it never blocks (server then shows the
-- current holder's copy, see onContainerInteract).
local function onContainerCanInteract(ctx, pComp, pSuccess)
    if not S.enabled or not S.containers or not isServer() then return end
    local c = ctx:get()
    if not valid(c) or not pSuccess:get() or not isLootContainer(c) then return end
    local me = nil
    pcall(function() me = localPC().Pawn end)
    if not valid(me) then return end
    local other = nil
    pcall(function()
        c.ContainerUsers:ForEach(function(_, u)
            local o = u:get()
            if valid(o) and o:GetAddress() ~= me:GetAddress() then other = o end
        end)
    end)
    if not other then return end
    pSuccess:set(false)
    if not IL.lockMsg or os.clock() - IL.lockMsg > 3 then
        IL.lockMsg = os.clock()
        if S.verbose then log("CONTAINER %s: blocked for you - %s is looting their own copy right now", contShort(contKey(c)), (function() local ou = uidOfChar(other); return ou and who(ou) or "another player" end)()) end
    end
end

-- every game: a dropped copy tagged for someone else can't be picked up by you (hiding alone did not stop
-- the interaction; seen 2026-11-12 picking up FAKE1/FAKE2 furniture copies)
local function onDroppedCanInteract(ctx, pComp, pSuccess)
    if not S.enabled then return end
    local a = ctx:get()
    if not valid(a) or not pSuccess:get() then return end
    local t = tagOf(a)
    local me = myUid()
    if not t or not me or t == me then return end
    pSuccess:set(false)
    if not IL.pickMsg or os.clock() - IL.pickMsg > 3 then
        IL.pickMsg = os.clock()
        if S.verbose then log("BLOCK pick-up of %s: tagged for %s, you are %s", itemName(a), who(t), who(me)) end
    end
end

-- ---------------------------------------------------------------- new items (every game)
local function onNewItem(a, kind)
    if not S.enabled then return end
    if IL.internal > 0 then IL.lastSpawned = a end
    local t = os.clock()
    if kind == "dropped" and IL.internal == 0 then
        IL.pendingNew[#IL.pendingNew + 1] = { obj = a, t = t }
        if #IL.pendingNew > 64 then table.remove(IL.pendingNew, 1) end
    end
    -- properties (and the replicated tag) are not there yet at construction
    for _, ms in ipairs({ 300, 2500 }) do
        gtDelay(ms, function()
            if not valid(a) then return end
            -- host: a saved copy came back from the world save without its tag -> re-tag from our data
            if isServer() and not tagOf(a) then
                local id = ""; pcall(function() id = str(a.ChangeableData.AssetID) end)
                local d = data()
                local e = id ~= "" and d.drops[id] or nil
                if e then
                    setTag(a, e.u, kind)
                    if S.verbose then log("RETAG %s (saved copy) for %s", itemName(a), who(e.u)) end
                end
            end
            if tagOf(a) then check(track(a, kind)) end
        end)
    end
end

-- ---------------------------------------------------------------- players joining (host)
IL.seen = {}
local function playerSweep()
    if not isServer() then return end
    local d = data()
    local online, here = onlinePlayers(), {}
    for _, p in ipairs(online) do here[p.uid] = true end
    -- someone who left is "new in this session" again when they come back (catch-up copies, see below)
    for u in pairs(IL.seen) do if not here[u] and not isSim(u) then IL.seen[u] = nil end end
    for _, p in ipairs(online) do
        if not IL.seen[p.uid] then
            IL.seen[p.uid] = true
            local isNew = not d.players[p.uid]
            d.players[p.uid] = nameOfUid(p.uid); markDirty()
            if S.verbose then log("PLAYER %s is in the world (%s)", who(p.uid), isNew and "first time with this mod" or "known") end
            if S.floorloot or S.lootables then   -- new or returning: items taken while they were away
                local n = 0
                for key, e in pairs(d.placed) do
                    local on = not e.node and S.floorloot
                    if on and not e.taken[p.uid] and not e.copies[p.uid] then
                        if not e.node then giveFloorCopies(key, e, { p.uid }) end
                        n = n + 1
                    end
                end
                if n > 0 then if S.verbose then log("FLOOR: made %d own copies of already-taken level items for %s", n, who(p.uid)) end end
            end
        end
    end
    --[[TESTMODE
    for _, f in ipairs(IL.fakes) do
        if not IL.seen[f] then
            IL.seen[f] = true
            if not d.players[f] then d.players[f] = f; markDirty() end
            if S.verbose then log("PLAYER %s (simulated) counts as online", f) end
        end
    end
    --TESTMODE]]
end

-- ---------------------------------------------------------------- test mode: switch identity
--[[TESTMODE
local function switchIdentity()
    if #IL.fakes == 0 then if S.verbose then log("F7: set fakeplayers = 2 in Mods\\InstancedLoot\\settings.txt to use test identities") end; return end
    local order = { false }
    for _, f in ipairs(IL.fakes) do order[#order + 1] = f end
    local cur = IL.acting or false
    local nxt = order[1]
    for i, v in ipairs(order) do if v == cur then nxt = order[i % #order + 1] end end
    IL.acting = nxt or nil
    local n, h = recheckAll()
    pcall(IL.nodeRefreshAll)
    if S.verbose then log("TEST: you are now %s. %d tagged copies tracked, %d hidden from you", who(myUid()), n, h) end
    pcall(function()
        local pc = localPC()
        StaticFindObject("/Script/Engine.Default__KismetSystemLibrary"):PrintString(pc, "InstancedLoot: you are now " .. who(myUid()),
            true, false, { R = 1, G = 0.8, B = 0.2, A = 1 }, 3.0, FName("None"))
    end)
end
--TESTMODE]]

-- ---------------------------------------------------------------- install hooks
local function hook(path, fn, label)
    local ok, err = pcall(RegisterHook, path, function(...)
        local ok2, e2 = IL.timed(label, fn, ...)
        if not ok2 then log("%s error: %s", label, tostring(e2)) end
    end)
    if ok then if S.verbose then log("hooked %s", label) end else log("could not hook %s: %s", label, tostring(err)) end
    return ok
end
IL.hooked = false
IL.bpDone = {}
local BP_HOOKS = {
    { P.GM, "GenerateLootDrop", function(...) return onGenerateLootDrop(...) end, "GenerateLootDrop" },
    { P.CORPSE, "InteractWith_A", function(...) return onCorpseInteract(...) end, "corpse InteractWith_A" },
    { P.CORPSE, "CanInteractWith_A", function(...) return onCorpseCanInteract(...) end, "corpse CanInteractWith_A" },
    { P.CORPSE, "InteractWith_A_LocalFX", function(...) return onCorpseLocalFX(...) end, "corpse InteractWith_A_LocalFX" },
    { P.CONT, "InteractWith_A", function(...) return onContainerInteract(...) end, "container InteractWith_A" },
    { P.CONT, "Server_UserLeftContainer", function(...) return onContainerLeft(...) end, "container Server_UserLeftContainer" },
    { P.CONT, "TryRegenerateContainerLoot", function(...) return onContainerRegen(...) end, "container TryRegenerateContainerLoot" },
    { P.CONT, "CanInteractWith_A", function(...) return onContainerCanInteract(...) end, "container CanInteractWith_A" },
    { P.DROPPED, "CanInteractWith_A", function(...) return onDroppedCanInteract(...) end, "dropped item CanInteractWith_A" },
    { P.PLAYER, "TryPickupItemAndFindBestSlotForIt", function(...) return onTryPickup(...) end, "TryPickupItemAndFindBestSlotForIt" },
    -- the game writes its world save here: flush our tags with it, or tags newer than our last write come back missing
    { P.GM, "SaveAllActors", function() saveData() end, "SaveAllActors" },
    { P.NODE, "GenerateItemDrop", function(...) return onNodeItemDrop(...) end, "lootable GenerateItemDrop" },
    { P.NODE, "InteractWith_A_LocalFX", function(...) return onNodeLocalFX(...) end, "lootable InteractWith_A_LocalFX" },
    { P.NODE, "CanInteractWith_A", function(...) return onNodeCanInteract(...) end, "lootable CanInteractWith_A" },
}
-- Blueprint classes only exist once a world has loaded them, so these are retried (startup, every ClientRestart)
-- until each one succeeds. Each is registered exactly once.
local function installBPHooks(when)
    local missing = 0
    for i, h in ipairs(BP_HOOKS) do
        if not IL.bpDone[i] then
            pcall(LoadAsset, h[1])
            local cls = StaticFindObject(h[1])
            if valid(cls) and hook(h[1] .. ":" .. h[2], h[3], h[4] .. " (" .. when .. ")") then IL.bpDone[i] = true
            else missing = missing + 1 end
        end
    end
    if missing ~= IL.bpMissing then
        if missing > 0 then if S.verbose then log("%d blueprint hooks not ready yet (%s); retrying every 5 s", missing, when) end
        else if S.verbose then log("all blueprint hooks installed (%s)", when) end end
        IL.bpMissing = missing
    end
    return missing
end
local function installHooks(when)
    if IL.hooked then return end
    IL.hooked = true
    for _, p in ipairs({ P.DROPPED, P.ITEM }) do pcall(LoadAsset, p) end
    hook("/Script/Engine.Actor:K2_DestroyActor", onDestroy, "Actor:K2_DestroyActor (native)")
    hook("/Script/Engine.GameplayStatics:FinishSpawningActor", function(ctx, pActor)
        local a = pActor:get()
        if not valid(a) then return end
        IL.clsItem = valid(IL.clsItem) and IL.clsItem or StaticFindObject(P.ITEM)
        if valid(IL.clsItem) and a:IsA(IL.clsItem) then IL.runtime[a:GetAddress()] = true end
    end, "GameplayStatics:FinishSpawningActor (native)")
    local okN1 = pcall(NotifyOnNewObject, P.DROPPED, function(a) IL.timed("new dropped item", onNewItem, a, "dropped") end)
    if S.verbose then log("new-item watcher: %s (installed %s)", tostring(okN1), when) end
end

-- keybind (F7, rebindable in the F4 menu)
--[[TESTMODE
local okMK, MK = pcall(require, "ModKeys")
if okMK then MK.bind("InstancedLoot.switch", "Instanced Loot", "Test mode: switch to next fake player", "F7", switchIdentity)
else pcall(RegisterKeyBind, Key.F7, function() ExecuteInGameThread(switchIdentity) end) end
--TESTMODE]]

-- start
installHooks("startup")
pcall(installBPHooks, "startup")
pcall(RegisterHook, "/Script/Engine.PlayerController:ClientRestart", function()
    ExecuteInGameThread(function() installBPHooks("world load") end)
    gtDelay(2000, function()
        IL.seen = {}
        IL.traceChannels = nil; traceChannels()
        if isServer() then data(); loadSalvage(); pcall(DR.init); DR.rT = -99; DR.r = 0; DR.rate()
        elseif S.lootables then pcall(loadSalvage) end    -- clients: to know what a lootable can give (see onNodeLocalFX)
        local me = realLocalUid()
        if S.verbose then log("world ready: you are %s (%s)%s", who(myUid()), isServer() and "host" or "client",
            #IL.fakes > 0 and (", test mode with " .. #IL.fakes .. " simulated players, F7 switches who you are") or "") end
        if me == nil then log("WARNING: could not read your UniquePlayerID; hiding is off until it can be read") end
        if S.lootables then
            pcall(IL.nodeRefreshAll)
            gtDelay(2000, function() pcall(IL.nodeRefreshAll) end)
        end
    end)
end)
gtLoop(5000, function()
    if (IL.bpMissing or 1) > 0 then pcall(installBPHooks, "retry") end
    if not S.enabled then return end
    playerSweep()
    for key, rec in pairs(IL.tracked) do if not check(rec) then IL.tracked[key] = nil end end
    if S.lootables then pcall(IL.nodeRefreshAll) end
end)
gtLoop(15000, function() saveData() end)
gtLoop(500, function()      -- host: fresh item counts per player, so a pick-up's gain can be measured
    if not S.enabled or not S.lootables or not isServer() then return end
    for _, p in ipairs(onlinePlayers()) do IL.invCache[p.uid] = invCounts(p.char) end
end)
log("loaded (InstancedLoot v1.17)")
