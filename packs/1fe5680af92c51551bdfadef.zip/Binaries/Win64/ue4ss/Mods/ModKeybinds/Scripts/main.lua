-- ModKeybinds: F4 menu listing every keybind of our mods (from Mods\ModKeybinds\keybinds.txt, see
-- Mods\shared\ModKeys\ModKeys.lua). Click a key, press the new key; the mods pick it up within a second.
-- Built like the F1 CheatMenu: UMG widgets under a rooted UserWidget, polled from a game-thread loop.
-- Styled with copies of the game's settings-menu widgets (panel/row textures, fonts, key button).
-- Key capture: each key button is covered by an invisible UMG InputKeySelector (Unreal's own key-capture
-- widget). It catches keyboard, mouse and controller buttons at the Slate level, which works while the
-- menu holds UI-only input (the game's input, and UE4SS keybinds, never see controller buttons there).

local MOD = "[ModKeybinds] "
local function log(fmt, ...) print(MOD .. string.format(fmt, ...) .. "\n") end
local function valid(o) return o ~= nil and o.IsValid ~= nil and o:IsValid() end

local okMK, MK = pcall(require, "ModKeys")
if not okMK then log("shared\\ModKeys missing: %s", tostring(MK)); return end

local SCALE = 0.6
local ROOTSET = (EInternalObjectFlags and EInternalObjectFlags.RootSet) or 0x40000000
local W = {
    UserWidget = "/Script/UMG.UserWidget", WidgetTree = "/Script/UMG.WidgetTree", Canvas = "/Script/UMG.CanvasPanel",
    Border = "/Script/UMG.Border", VBox = "/Script/UMG.VerticalBox", TextBlock = "/Script/UMG.TextBlock",
    Button = "/Script/UMG.Button", SizeBox = "/Script/UMG.SizeBox", ScrollBox = "/Script/UMG.ScrollBox",
    Title = "/Game/Blueprints/Widgets/MenuSystem/W_MenuTitleBig.W_MenuTitleBig_C",
    Overlay = "/Script/UMG.Overlay", Image = "/Script/UMG.Image", Selector = "/Script/UMG.InputKeySelector",
}
-- The game's own settings-menu widgets, used as templates (copies keep their look: fonts, textures,
-- button style, but none of their Blueprint logic). Missing one -> plain widget, logged once.
local UI = "/Game/SettingsMenu_MP/UI/"
local ARCH = {
    panelBG  = { "/Game/Blueprints/Widgets/MenuSystem/W_SettingsMenu.W_SettingsMenu_C", "NavBG" },
    category = { UI .. "W_SettingSubCategory.W_SettingSubCategory_C", "CategoryTextBlock" },
    rowBG    = { UI .. "InputRow.InputRow_C", "BG_Left" },
    rowText  = { UI .. "InputRow.InputRow_C", "Keybind_Text" },
    keyBtn   = { UI .. "StyledAutoSettings/Input/StyledBindCaptureButton.StyledBindCaptureButton_C", "Button_0" },
    keyText  = { UI .. "StyledAutoSettings/Input/StyledKeyLabel.StyledKeyLabel_C", "LabelText" },
}
local classCache = {}
local function cls(path)
    local c = classCache[path]
    if valid(c) then return c end
    c = StaticFindObject(path)
    if not valid(c) then pcall(LoadAsset, path); c = StaticFindObject(path) end
    classCache[path] = c
    return c
end
local function wbl() return StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary") end
local function getPC()
    local pcs = FindAllOf("PlayerController")
    if not pcs then return nil end
    for _, pc in ipairs(pcs) do if valid(pc) and pc:IsLocalController() then return pc end end
end
local n = 0
local function construct(path, outer, name)
    n = n + 1
    return StaticConstructObject(cls(path), outer, FName("ModKeybinds_" .. name .. n))
end
local archCache = {}
local function archetype(key)
    local a = archCache[key]
    if a == nil then
        local def = ARCH[key]
        pcall(LoadAsset, def[1])   -- load first: a StaticFindObject miss scans every object
        local ok, o = pcall(StaticFindObject, def[1] .. ":WidgetTree." .. def[2])
        a = (ok and valid(o)) and o or false
        if not a then log("game style %s not found, using a plain widget", key) end
        archCache[key] = a
    end
    return a or nil
end
-- vis: 0 Visible (clickable), 3 HitTestInvisible (backgrounds, text)
local function styled(key, plain, tree, name, vis)
    local a, w = archetype(key), nil
    if a then
        n = n + 1
        local ok, res = pcall(StaticConstructObject, a:GetClass(), tree, FName("ModKeybinds_" .. name .. n), 0, 0, false, false, a)
        if ok and valid(res) then w = res end
    end
    w = w or construct(plain, tree, name)
    pcall(function() w:SetVisibility(vis or 3) end)
    return w
end
local function text(tree, s, key)
    local tb = styled(key or "rowText", W.TextBlock, tree, "Text")
    tb:SetText(FText(s))
    return tb
end
-- background image under padded content, all filling the overlay (alignment 0 = Fill).
-- shade: a dark plain layer under the game image, so the panel is never see-through
local function backed(tree, bgKey, content, pad, shade)
    local ov = construct(W.Overlay, tree, "Back")
    local layers = {}
    if shade then
        local b = construct(W.Border, tree, "Shade")
        b:SetBrushColor(shade)
        pcall(function() b:SetVisibility(3) end)
        layers[#layers + 1] = b
    end
    layers[#layers + 1] = styled(bgKey, W.Image, tree, "BG")
    layers[#layers + 1] = content
    for i, w in ipairs(layers) do
        local s = ov:AddChildToOverlay(w)
        pcall(function() s:SetHorizontalAlignment(0); s:SetVerticalAlignment(0) end)
        if i == #layers then pcall(function() s:SetPadding(pad) end) end
    end
    return ov
end

local menu, menuOpen, built = nil, false, 0
local rows = {}          -- { e = entry, btn, sel, keyText, desc, selecting }
local capturing = nil    -- row waiting for a key
local focused = nil      -- row whose key selector has keyboard/controller focus (marked > <)
local NOKEY = { Key = { KeyName = FName("None") }, bShift = false, bCtrl = false, bAlt = false, bCmd = false }

local function sorted()
    local list = {}
    for _, e in ipairs(MK.read()) do list[#list + 1] = e end
    table.sort(list, function(a, b) if a.mod ~= b.mod then return a.mod < b.mod end return a.label < b.label end)
    return list
end

local function sig()
    local t = {}
    for _, e in ipairs(sorted()) do t[#t + 1] = e.id .. "|" .. e.mod .. "|" .. e.label end
    return table.concat(t, "\n")
end

local function refreshTexts()
    for _, r in ipairs(rows) do
        local others = {}
        for _, o in ipairs(rows) do if o ~= r and r.e.key ~= "" and o.e.key == r.e.key then others[#others + 1] = o.e.mod end end
        local k = (r == capturing) and "press a key or button..." or (r.e.key == "" and "not set" or r.e.key)
        k = k .. ((#others > 0 and r ~= capturing) and "  (!)" or "")
        if r == focused and r ~= capturing then k = ">  " .. k .. "  <" end
        pcall(function() r.keyText:SetText(FText("   " .. k .. "   ")) end)
        pcall(function() r.desc:SetText(FText(r.e.label .. (#others > 0 and ("   - same key as " .. table.concat(others, ", ")) or ""))) end)
    end
end

local selWarned = false
local function keySelector(tree)
    local sel = construct(W.Selector, tree, "Sel")
    local ok, err = pcall(function()
        sel:SetAllowGamepadKeys(true)
        sel:SetVisibility(0)
        sel:SetRenderOpacity(0)   -- invisible but still clickable/focusable: the styled button under it shows
    end)
    if not ok and not selWarned then selWarned = true; log("key selector setup: %s", tostring(err)) end
    pcall(function() sel:SetSelectedKey(NOKEY) end)
    return sel
end

local function buildMenu(pc)
    rows = {}
    local root = StaticConstructObject(cls(W.UserWidget), FindFirstOf("GameInstance"), FName("ModKeybinds_Root" .. n), 0, ROOTSET)
    root.WidgetTree = construct(W.WidgetTree, root, "Tree")
    local tree = root.WidgetTree
    local canvas = construct(W.Canvas, tree, "Canvas")
    tree.RootWidget = canvas
    local outer = construct(W.VBox, tree, "Outer")
    local border = backed(tree, "panelBG", outer, { Left = 32, Top = 20, Right = 32, Bottom = 24 },
        { R = 0.01, G = 0.012, B = 0.015, A = 0.94 })
    local cs = canvas:AddChildToCanvas(border)
    cs:SetAutoSize(true)
    cs:SetAnchors({ Minimum = { X = 0.5, Y = 0.5 }, Maximum = { X = 0.5, Y = 0.5 } })
    cs:SetAlignment({ X = 0.5, Y = 0.5 })
    cs:SetPosition({ X = 0, Y = 0 })
    pcall(function() border:SetRenderTransformPivot({ X = 0.5, Y = 0.5 }) end)
    pcall(function() border:SetRenderScale({ X = SCALE, Y = SCALE }) end)

    local title = wbl():Create(pc, cls(W.Title), pc)
    if valid(title) then pcall(function() title.TitleText = FText("MOD KEYBINDS") end); outer:AddChildToVerticalBox(title) end
    outer:AddChildToVerticalBox(text(tree, "Click a key (or pick it with the d-pad and press A), then press the new key or controller button. Click, Escape or Start cancels."))

    local sizer = construct(W.SizeBox, tree, "Sizer")
    pcall(function() sizer:SetMaxDesiredHeight(900) end)
    outer:AddChildToVerticalBox(sizer)
    local scroll = construct(W.ScrollBox, tree, "Scroll")
    pcall(function() scroll:SetScrollWhenFocusChanges(1) end)   -- d-pad moves keep the focused row in view
    sizer:SetContent(scroll)
    local vbox = construct(W.VBox, tree, "List")
    scroll:AddChild(vbox)

    for _, e in ipairs(sorted()) do
        local inner = construct(W.VBox, tree, "RowBox")
        local panel = backed(tree, "rowBG", inner, { Left = 14, Top = 8, Right = 14, Bottom = 10 },
            { R = 0.06, G = 0.07, B = 0.08, A = 0.9 })
        inner:AddChildToVerticalBox(text(tree, e.mod, "category"))
        local desc = text(tree, e.label)
        inner:AddChildToVerticalBox(desc)
        -- plain button wearing the game's key-button style: copying the template itself would bring its
        -- slot, and replacing that content would unhook the child from the game's own template.
        -- It is only the look now: the invisible key selector on top of it takes the clicks.
        local btn = construct(W.Button, tree, "Key")
        pcall(function() btn.IsFocusable = false end)
        local kb = archetype("keyBtn")
        if kb then
            local ok, err = pcall(function() btn:SetStyle(kb.WidgetStyle) end)
            if not ok then log("key button style: %s", tostring(err)) end
            pcall(function() btn:SetBackgroundColor(kb.BackgroundColor) end)
        else
            pcall(function() btn:SetBackgroundColor({ R = 0.3, G = 0.3, B = 0.3, A = 1.0 }) end)
        end
        local keyText = text(tree, e.key, "keyText")
        btn:SetContent(keyText)
        pcall(function() btn:SetVisibility(3) end)
        local sel = keySelector(tree)
        local keyOv = construct(W.Overlay, tree, "KeyOv")
        for _, w in ipairs({ btn, sel }) do
            local s = keyOv:AddChildToOverlay(w)
            pcall(function() s:SetHorizontalAlignment(0); s:SetVerticalAlignment(0) end)
        end
        local bs = inner:AddChildToVerticalBox(keyOv)
        pcall(function() bs:SetHorizontalAlignment(1) end)
        pcall(function() bs:SetPadding({ Left = 0, Top = 6, Right = 0, Bottom = 0 }) end)
        local s = vbox:AddChildToVerticalBox(panel)
        pcall(function() s:SetPadding({ Left = 0, Top = 0, Right = 0, Bottom = 6 }) end)
        rows[#rows + 1] = { e = e, btn = btn, sel = sel, keyText = keyText, desc = desc }
    end
    built = sig()
    refreshTexts()
    return root
end

-- input: while open the menu takes ALL controls. UI-only input mode stops the game seeing any key, mouse
-- button, wheel or controller button (no moving, looking, hotbar scrolling, game keybinds, polled keys of
-- our mods); the flag file makes ModKeys skip every other mod's press action. F4 and Escape still work
-- because UE4SS keybinds read the keyboard directly.
local hadCursor = false
local function setFlag(on)
    if on then local f = io.open(MK.MENU_FLAG, "w"); if f then f:write("1"); f:close() end
    else os.remove(MK.MENU_FLAG) end
end
setFlag(false)   -- left over from a crash
local function setInput(pc, open)
    local lib = wbl()
    if open then
        hadCursor = pc.bShowMouseCursor == true
        pcall(function() pc:FlushPressedKeys() end)   -- stop keys held while opening (walking etc.)
        pcall(function() menu:SetIsFocusable(true) end)
        local ok, err = pcall(function() lib:SetInputMode_UIOnlyEx(pc, menu, 0, false) end)
        if not ok then log("UI-only input failed: %s", tostring(err)) end
        pc.bShowMouseCursor = true
        pcall(function() pc:SetIgnoreLookInput(true) end)
        pcall(function() pc:SetIgnoreMoveInput(true) end)
        -- controller: start on the first key so the d-pad can move between keys
        if rows[1] then pcall(function() rows[1].sel:SetUserFocus(pc) end); pcall(function() rows[1].sel:SetKeyboardFocus() end) end
        setFlag(true)
    else
        setFlag(false)
        pcall(function() pc:ResetIgnoreLookInput() end)
        pcall(function() pc:ResetIgnoreMoveInput() end)
        pcall(function() pc:FlushPressedKeys() end)
        local ok = false
        if hadCursor then   -- a game menu (inventory...) was open underneath: give it the mouse back
            ok = pcall(function() lib:SetInputMode_GameAndUIEx(pc, nil, 0, false) end)
            if not ok then ok = pcall(function() lib:SetInputMode_GameAndUIEx(pc, CreateInvalidObject(), 0, false) end) end
        end
        if not ok then
            pcall(function() lib:SetInputMode_GameOnly(pc, true) end)
            pc.bShowMouseCursor = false
        end
    end
end

local function closeMenu()
    capturing = nil; MK.capture = nil
    for _, r in ipairs(rows) do r.selecting = false; pcall(function() r.sel:SetSelectedKey(NOKEY) end) end
    if valid(menu) then pcall(function() menu:SetVisibility(1) end) end
    menuOpen = false
    local pc = getPC()
    if valid(pc) then setInput(pc, false) end
end

local function openMenu()
    local pc = getPC()
    if not valid(pc) then log("no local player controller yet"); return end
    if valid(menu) and sig() ~= built then   -- keybinds added or renamed since we built: rebuild
        pcall(function() menu:RemoveFromParent() end); menu = nil
    end
    if not valid(menu) then
        local ok, res = pcall(buildMenu, pc)
        if not ok or not valid(res) then log("failed to build menu: %s", tostring(res)); return end
        local added, err = pcall(function() res:AddToViewport(450) end)
        if not added then log("could not show menu: %s", tostring(err)); return end
        menu = res
    else
        for _, r in ipairs(rows) do for _, e in ipairs(MK.read()) do if e.id == r.e.id then r.e = e end end end
        refreshTexts()
        pcall(function() menu:SetVisibility(0) end)
    end
    menuOpen = true
    setInput(pc, true)
end

-- a key selector finished: store what it caught (keys we can't bind, Escape or a click = cancel)
local function finishCapture(r)
    local name = nil
    pcall(function() name = r.sel.SelectedKey.Key.KeyName:ToString() end)
    pcall(function() r.sel:SetSelectedKey(NOKEY) end)
    local label = MK.labelOf(name)
    if label and label ~= r.e.key then
        local list = MK.read()
        for _, e in ipairs(list) do if e.id == r.e.id then e.key = label; r.e = e end end
        if not MK.write(list) then log("could not write %s", MK.FILE) end
    elseif not label and name and name ~= "None" and name ~= "Escape" and name ~= "LeftMouseButton" then
        log("%s can't be used as a mod key", name)
    end
end

local lastToggle = 0
MK.bind("ModKeybinds.open", "Mod Keybinds", "Open / close this menu", "F4", function()
    local now = os.clock()
    if now - lastToggle < 0.3 then return end
    lastToggle = now
    if menuOpen then closeMenu() else openMenu() end
end)
MK.listen()
-- Escape backs out of the menu (registered once, at load). During a capture the key selector gets the
-- Escape itself and cancels.
RegisterKeyBind(Key.ESCAPE, function()
    if not menuOpen then return end
    ExecuteInGameThread(function()
        if menuOpen and not capturing then closeMenu() end
    end)
end)

-- key selectors are polled (no UMG delegates from Lua)
LoopInGameThreadWithDelay(30, function()
    if not menuOpen then return end
    if not valid(menu) then menuOpen = false; return end
    local changed, foc = false, nil
    for _, r in ipairs(rows) do
        local ok, on = pcall(function() return r.sel:GetIsSelectingKey() end)
        on = ok and on == true
        if on and not r.selecting then
            capturing = r
            -- swallow the keyboard press UE4SS also sees, so e.g. F4 can be bound without closing the menu
            MK.capture = function() end
            changed = true
        elseif r.selecting and not on then
            if capturing == r then capturing = nil; MK.capture = nil end
            finishCapture(r)
            changed = true
        end
        r.selecting = on
        local okf, f = pcall(function() return r.sel:HasAnyUserFocus() or r.sel:HasFocusedDescendants() end)
        if okf and f == true then foc = r end
    end
    if foc ~= focused then focused = foc; changed = true end
    if changed then refreshTexts() end
end)

-- new world: our widget went with the old viewport
RegisterHook("/Script/Engine.PlayerController:ClientRestart", function()
    ExecuteInGameThread(function()
        if valid(menu) then pcall(function() menu:RemoveFromParent() end) end
        menu, menuOpen, capturing, focused, MK.capture = nil, false, nil, nil, nil
        setFlag(false)
    end)
end)

log("loaded (%d keybinds in %s)", #MK.read(), MK.FILE)
