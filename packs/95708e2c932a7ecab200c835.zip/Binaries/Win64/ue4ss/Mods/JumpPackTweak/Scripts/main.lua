-- JumpPackTweak: Jump Pack and Long Jump Pack get 38 slots and 60% weight reduction.
-- Edits just those two rows in memory, so it survives backpack-mod and game updates with no rebuild.
-- v1 edited only the ItemTable_Gear asset: the log showed it being unloaded and reloaded while the
-- game kept using the old numbers, so the game reads a different (runtime) table. v2 patches EVERY
-- loaded DataTable that has these rows, and logs which tables those are. Rechecked every 5 s.
local MOD = "[JumpPackTweak] "
local PATCH = {  -- row = { slots, weight reduction }
    backpack_jetpack      = { 38, 0.6 },
    backpack_longjumppack = { 38, 0.6 },
}
local function log(fmt, ...) print(MOD .. string.format(fmt, ...) .. "\n") end
local noRows = {}   -- "fullname@address" of item tables that don't have the jump pack rows: not re-scanned every 5 s

local function patchTable(dt)
    local hits, total = 0, 0
    dt:ForEachRow(function(rowName, row)
        total = total + 1
        local name = type(rowName) == "string" and rowName or rowName:ToString()
        local want = PATCH[name]
        if not want then return end
        hits = hits + 1
        local eq = row.EquipmentData
        if eq.ContainerCapacity ~= want[1] or math.abs(eq.ContainerWeightReduction - want[2]) > 1e-6 then
            eq.ContainerCapacity = want[1]
            eq.ContainerWeightReduction = want[2]
        end
    end)
    return hits, total
end

local function apply()
    local tables = FindAllOf("DataTable") or {}
    for _, cls in ipairs({ "AbioticModDataTable", "CompositeDataTable" }) do
        for _, t in ipairs(FindAllOf(cls) or {}) do tables[#tables + 1] = t end
    end
    for _, dt in ipairs(tables) do
        if dt:IsValid() then
            local key = dt:GetFullName() .. "@" .. tostring(dt:GetAddress())
            if not noRows[key] then
                -- only item tables (row struct AbioticInventoryItem)
                local okS, isItem = pcall(function() return dt.RowStruct:GetFName():ToString() == "AbioticInventoryItem" end)
                if okS and not isItem then noRows[key] = true
                elseif okS then
                    local ok, hits, total = pcall(patchTable, dt)
                    if not ok then log("skip %s: %s", dt:GetFullName(), tostring(hits))
                    elseif hits == 0 and total > 0 then noRows[key] = true end   -- a filled table without them won't gain them
                end
            end
        end
    end
end

LoopInGameThreadWithDelay(5000, function()
    local ok, err = pcall(apply)
    if not ok then log("error: %s", tostring(err)) end
end)
log("loaded")
