local MOD = "[CookingRadius] "
local function log(fmt, ...) print(MOD .. string.format(fmt, ...) .. "\n") end
local function valid(o) return o ~= nil and o.IsValid ~= nil and o:IsValid() end

local SETTINGS_FILE = "ue4ss/Mods/CookingRadius/settings.txt"

local settings = { radius = 100, hidejunk = 1, containerw = 564, recipew = 900, columns = 2, searchw = 320, searchh = 92, padl = 52, padt = 66, padr = 46, padb = 56, gap = 16, top = 132, height = 806, favsize = 40, favx = 0, favy = 20, tabsize = 56, searchz = 400 }
do
    local f = io.open(SETTINGS_FILE, "r")
    if f then
        for line in f:lines() do
            local k, v = line:match("^%s*(%w+)%s*=%s*(%S+)")
            if k and settings[k] ~= nil and tonumber(v) then settings[k] = tonumber(v) end
        end
        f:close()
    end
end

local function gtDelay(ms, fn)
    local ok = pcall(ExecuteInGameThreadWithDelay, ms, function() local ok2, err = pcall(fn); if not ok2 then log("timer: %s", tostring(err)) end end)
    if not ok then log("ExecuteInGameThreadWithDelay unavailable") end
end

local function gtLoop(ms, fn)
    local h
    local ok, res = pcall(LoopInGameThreadWithDelay, ms, function()
        local ok2, stop = pcall(fn)
        if not ok2 then log("loop: %s", tostring(stop)); stop = false end
        if stop and h then pcall(CancelDelayedAction, h) end
    end)
    if ok then h = res else log("LoopInGameThreadWithDelay unavailable: %s", tostring(res)) end
    return ok
end

local FAV_FILE = "ue4ss/Mods/CookingRadius/favorites.txt"
local favs = {}
do
    local f = io.open(FAV_FILE, "r")
    if f then
        for line in f:lines() do
            local r = line:match("^%s*(%S+)")
            if r then favs[r] = true end
        end
        f:close()
    end
end
local function saveFavs()
    local rows = {}
    for r, on in pairs(favs) do if on then rows[#rows + 1] = r end end
    table.sort(rows)
    local f = io.open(FAV_FILE, "w")
    if not f then log("could not write %s", FAV_FILE); return end
    f:write(table.concat(rows, "\n"), #rows > 0 and "\n" or "")
    f:close()
end

local ENTER_WHEEL = "/Game/Blueprints/Characters/Abiotic_PlayerCharacter.Abiotic_PlayerCharacter_C:EnterRadialWheel"
local SLOT_DOWN   = "/Game/Blueprints/Widgets/Inventory/W_InventoryItemSlot.W_InventoryItemSlot_C:PerformMouseButtonDown"
local IFL         = "/Game/Blueprints/Libraries/ItemFunctionLibrary.Default__ItemFunctionLibrary_C"
local INVCOMP     = "/Game/Blueprints/Characters/Abiotic_InventoryComponent.Abiotic_InventoryComponent_C"
local SOUPENTRY   = "/Game/Blueprints/Widgets/Journal/W_Compendium_SoupEntry.W_Compendium_SoupEntry_C"
local SOUPLIB     = "/Script/AbioticFactor.Default__SoupRecipeHandleFunctionLibrary"
local CHARBASE    = "/Script/AbioticFactor.AbioticCharacter"
local TABPKG      = "/Game/Blueprints/Widgets/W_RecipeFilterTab"
local TABCLASS    = TABPKG .. ".W_RecipeFilterTab_C"
local CRAFTAREA   = "/Game/Blueprints/Widgets/Inventory/W_Inventory_CraftingArea.W_Inventory_CraftingArea_C"
local donors      = {}
local PDA_BG      = "/Game/Textures/GUI/Journal/journal_pda_bg.journal_pda_bg"
local WBL         = "/Script/UMG.Default__WidgetBlueprintLibrary"
local CONTAINER_VIEW = 1

local SKIP_OWNER = { "Stove", "CookingProxy", "Trader", "Dispenser", "Vendor", "PotOfSoup" }

local LOADTAG = string.format("%x%04x", os.time() % 0xFFFFFF, math.random(0, 0xFFFF))
local ROOTSET = (EInternalObjectFlags and EInternalObjectFlags.RootSet) or 0x40000000
local seq = 0
local function cls(path) return StaticFindObject(path) end
local function construct(path, outer, internalFlags)
    seq = seq + 1
    return StaticConstructObject(cls(path), outer, FName("CookingRadius_" .. LOADTAG .. "_" .. seq), 0, internalFlags or 0)
end
local function addr(o) return valid(o) and o:GetAddress() or 0 end
local function nameOfClass(o)
    local ok, n = pcall(function() return o:GetClass():GetFName():ToString() end)
    return ok and n or ""
end

local S = {
    open = false, p = nil, pot = nil, potComp = nil,
    virt = nil,
    items = {},
    loop = false, busy = false, named = false,
    panel = nil,
}
local cookable = {}

local DATA
do
    local ok, d = pcall(require, "cr_data")
    if not ok or type(d) ~= "table" then ok, d = pcall(dofile, "ue4ss/Mods/CookingRadius/Scripts/cr_data.lua") end
    DATA = (ok and type(d) == "table") and d or { food = {}, soups = {} }
    local lower = {}
    for k in pairs(DATA.food) do lower[k:lower()] = true end
    DATA.foodLower = lower
    local n = 0; for _ in pairs(DATA.food) do n = n + 1 end
end

local function canGoInPot(row, slot, p)
    if not (DATA.food[row] or DATA.foodLower[row:lower()]) then return false end
    if DATA.junk and DATA.junk[row] then
        if settings.hidejunk == 2 then return false end
        if settings.hidejunk == 1 and not (DATA.recipeJunk and DATA.recipeJunk[row]) then return false end
    end
    local c = cookable[row]
    if c ~= nil then return c end
    local res = true
    local ok, err = pcall(function()
        local lib = cls(IFL)
        local r = lib:IsCookableItem(slot, p)
        if r ~= nil then res = (r == true) end
    end)
    cookable[row] = res
    return res
end

local function searchable(c, p, charClass)
    local o = c:GetOwner()
    if not valid(o) then return false, false end
    if addr(o) == addr(p) then

        local a = addr(c)
        if a == addr(p.CharacterInventory) or a == addr(p.CharacterHotbarInventory) then return true, true end
        return false, false
    end
    if charClass and o:IsA(charClass) then return false, false end
    local n = nameOfClass(o)
    for _, s in ipairs(SKIP_OWNER) do if n:find(s, 1, true) then return false, false end end
    return true, false, o
end

local function titleText()
    if S.quantum then return string.format("Nearby food (%d m)", settings.radius) end
    return "Your food"
end

local function scan(p)
    local list, byRow = {}, {}
    local ploc = p:K2_GetActorLocation()
    local r = settings.radius * 100
    local r2 = r * r
    local charClass = cls(CHARBASE)
    local comps = FindAllOf("Abiotic_InventoryComponent_C") or {}
    local nComp = 0
    for _, c in ipairs(comps) do
        if valid(c) and addr(c) ~= addr(S.virt) then
            local ok, own, o = searchable(c, p, charClass)
            if ok and (own or S.quantum) then
                local inRange = own
                if not own then
                    local l = o:K2_GetActorLocation()
                    local dx, dy, dz = l.X - ploc.X, l.Y - ploc.Y, l.Z - ploc.Z
                    inRange = dx * dx + dy * dy + dz * dz <= r2
                end
                if inRange then
                    nComp = nComp + 1
                    local inv = c.CurrentInventory
                    for i = 1, #inv do
                        local s = inv[i]
                        local row = s.ItemDataTable.RowName:ToString()
                        if row ~= "" and row ~= "None" then
                            local n = s.ChangeableData.CurrentStack
                            if n and n > 0 and canGoInPot(row, s, p) then
                                local e = byRow[row]
                                if not e then
                                    e = { row = row, total = 0, sources = {} }
                                    byRow[row] = e
                                    list[#list + 1] = e
                                end
                                e.total = e.total + n

                                local src = { comp = c, idx = i - 1, own = own }
                                if own then table.insert(e.sources, 1, src) else e.sources[#e.sources + 1] = src end
                            end
                        end
                    end
                end
            end
        end
    end
    table.sort(list, function(a, b) return a.row < b.row end)
    return list
end

local function getVirt()
    if valid(S.virt) then return S.virt end

    local gi = FindFirstOf("GameInstance")
    S.virt = construct(INVCOMP, gi, ROOTSET)

    pcall(function() S.virt.InventorySlotType = 1 end)
    pcall(function() S.virt.DisplayName = FText(titleText()) end)
    pcall(function() S.virt.CustomDisplayName = true end)
    return S.virt
end

local function sourceSlot(src)
    if not valid(src.comp) then return nil end
    local inv = src.comp.CurrentInventory
    if src.idx + 1 > #inv then return nil end
    return inv[src.idx + 1]
end

local function fillVirt(v, list)
    local slots = math.max(24, math.ceil(#list / 6) * 6)

    pcall(function() v:RevertInventoryToEmpty() end)
    v:UpdateInventorySlotCount(slots, false, { X = 0, Y = 0, Z = 0 })
    for i, e in ipairs(list) do
        local s
        for _, src in ipairs(e.sources) do s = sourceSlot(src); if s then break end end
        if s then
            v:UpdateInventorySlot(i - 1, s)
            local vs = v.CurrentInventory[i]
            vs.ChangeableData.CurrentStack = e.total
        end
    end
    pcall(function() v:OnInventoryUpdated() end)
end

local function unlockedSet(p)
    local set = {}
    pcall(function()
        local arr = p.CharacterProgressionComponent.RecipesUnlockedArray
        for i = 1, #arr do set[arr[i]:ToString()] = true end
    end)
    return set
end

local function soupRows()
    local rows = {}
    for _, r in ipairs(DATA.soups) do rows[#rows + 1] = r end
    table.sort(rows)
    return rows
end

local function loadTex(path)
    local t = StaticFindObject(path)
    if not valid(t) then pcall(LoadAsset, path:match("^(.-)%.") or path); t = StaticFindObject(path) end
    return t
end

local function buildPanel(p)
    local gi = FindFirstOf("GameInstance")
    local root = construct("/Script/UMG.UserWidget", gi, ROOTSET)
    root.WidgetTree = construct("/Script/UMG.WidgetTree", root)
    local tree = root.WidgetTree
    local canvas = construct("/Script/UMG.CanvasPanel", tree)
    tree.RootWidget = canvas

    local frame = construct("/Script/UMG.Overlay", tree, ROOTSET)

    local bg = construct("/Script/UMG.Image", tree)
    local tex = loadTex(PDA_BG)
    if valid(tex) then bg:SetBrushFromTexture(tex, false) else bg:SetColorAndOpacity({ R = 0.05, G = 0.06, B = 0.07, A = 0.95 }) end
    local bs = frame:AddChildToOverlay(bg)
    bs:SetHorizontalAlignment(0); bs:SetVerticalAlignment(0)

    local vb = construct("/Script/UMG.VerticalBox", tree)
    local vs = frame:AddChildToOverlay(vb)
    vs:SetHorizontalAlignment(0); vs:SetVerticalAlignment(0)

    vs:SetPadding({ Left = settings.padl, Top = settings.padt, Right = settings.padr, Bottom = settings.padb })

    local title = construct("/Script/UMG.TextBlock", tree)
    title:SetText(FText("SOUP RECIPES"))
    pcall(function() title:SetJustification(1) end)
    title:SetColorAndOpacity({ SpecifiedColor = { R = 0.03, G = 0.03, B = 0.03, A = 1 }, ColorUseRule = 0 })

    local head = construct("/Script/UMG.HorizontalBox", tree)
    local hs = vb:AddChildToVerticalBox(head)
    hs:SetPadding({ Left = 0, Top = 0, Right = 0, Bottom = 10 })
    local tsl = head:AddChildToHorizontalBox(title)
    tsl:SetSize({ Value = 1.0, SizeRule = 1 })
    tsl:SetVerticalAlignment(2)
    pcall(function() title:SetJustification(0) end)

    local ph = construct("/Script/UMG.SizeBox", tree)
    ph:SetWidthOverride(settings.searchw)
    ph:SetHeightOverride(settings.searchh)
    local phs = head:AddChildToHorizontalBox(ph)
    phs:SetVerticalAlignment(2)
    local sroot = construct("/Script/UMG.UserWidget", gi, ROOTSET)
    sroot.WidgetTree = construct("/Script/UMG.WidgetTree", sroot)
    local stree = sroot.WidgetTree
    local scanvas = construct("/Script/UMG.CanvasPanel", stree)
    stree.RootWidget = scanvas
    local sb = construct("/Script/UMG.VerticalBox", stree)
    local scs = scanvas:AddChildToCanvas(sb)
    scs:SetAutoSize(true)
    sb:SetRenderTransformPivot({ X = 0, Y = 0 })
    local function searchBox(hint)
        local size = construct("/Script/UMG.SizeBox", tree)
        size:SetWidthOverride(settings.searchw)

        local box
        pcall(function()
            local donor = cls(WBL):Create(p, cls(CRAFTAREA), p:GetController())
            donors[#donors + 1] = donor
            local b = donor.EditableTextBox_0
            if valid(b) then b:RemoveFromParent(); box = b end
        end)
        if not valid(box) then
            log("game search box not available, using a plain one")
            box = construct("/Script/UMG.EditableTextBox", tree)
        end
        pcall(function() box:SetHintText(FText(hint)) end)
        pcall(function() box:SetText(FText("")) end)
        size:AddChild(box)
        local sl = sb:AddChildToVerticalBox(size)
        sl:SetPadding({ Left = 0, Top = 2, Right = 0, Bottom = 2 })
        return box
    end
    local recipeBox = searchBox("Search recipes...")
    local ingBox = searchBox("Ingredients (up to 3, space between)")

    local tabRow = construct("/Script/UMG.HorizontalBox", tree)
    local trs = vb:AddChildToVerticalBox(tabRow)
    trs:SetPadding({ Left = 0, Top = 0, Right = 0, Bottom = 8 })
    local tabCls = cls(TABCLASS)
    if not valid(tabCls) then pcall(LoadAsset, TABPKG); tabCls = cls(TABCLASS) end
    local function makeTab(tex, text, isFav)
        local t
        local ok, err = pcall(function()
            t = cls(WBL):Create(p, tabCls, p:GetController())
            local tx = loadTex(tex)
            if valid(tx) then t.Icon_Texture = tx end
            t.DisplayText = FText(text)
            t.Favorites = isFav
            local size = construct("/Script/UMG.SizeBox", tree)
            size:SetWidthOverride(settings.tabsize); size:SetHeightOverride(settings.tabsize)
            size:AddChild(t)
            local sl = tabRow:AddChildToHorizontalBox(size)
            sl:SetPadding({ Left = 0, Top = 0, Right = 6, Bottom = 0 })
        end)
        if not ok then log("tab '%s' failed: %s", text, tostring(err)); return nil end
        return t
    end
    local tabAll = valid(tabCls) and makeTab("/Game/Textures/GUI/icon_allrecipes.icon_allrecipes", "All Recipes", false) or nil
    local tabFav = valid(tabCls) and makeTab("/Game/Textures/GUI/icon_star.icon_star", "Favorites", true) or nil
    if not valid(tabCls) then log("W_RecipeFilterTab_C not found, no tabs") end
    local tabLabel = construct("/Script/UMG.TextBlock", tree)
    tabLabel:SetText(FText("ALL RECIPES"))
    tabLabel:SetColorAndOpacity({ SpecifiedColor = { R = 0.03, G = 0.03, B = 0.03, A = 1 }, ColorUseRule = 0 })
    local tls = tabRow:AddChildToHorizontalBox(tabLabel)
    tls:SetVerticalAlignment(2); tls:SetPadding({ Left = 10, Top = 0, Right = 0, Bottom = 0 })

    local empty = construct("/Script/UMG.TextBlock", tree)
    empty:SetText(FText(""))
    empty:SetColorAndOpacity({ SpecifiedColor = { R = 0.03, G = 0.03, B = 0.03, A = 1 }, ColorUseRule = 0 })
    pcall(function() empty:SetAutoWrapText(true) end)
    empty:SetVisibility(1)
    local es = vb:AddChildToVerticalBox(empty)
    es:SetPadding({ Left = 6, Top = 10, Right = 6, Bottom = 0 })

    local scroll = construct("/Script/UMG.ScrollBox", tree)
    local ss = vb:AddChildToVerticalBox(scroll)
    ss:SetSize({ Value = 1.0, SizeRule = 1 })

    local grid = construct("/Script/UMG.UniformGridPanel", tree)
    pcall(function() grid:SetSlotPadding({ Left = 6, Top = 4, Right = 6, Bottom = 4 }) end)
    scroll:AddChild(grid)

    S.panel = { root = root, frame = frame, scroll = scroll, grid = grid, entries = {},
        ph = ph, sroot = sroot, scs = scs, sb = sb,
        recipeBox = recipeBox, ingBox = ingBox, lastQ = nil,
        tabAll = tabAll, tabFav = tabFav, tabLabel = tabLabel, empty = empty, mode = "all", tabsInit = false }
    return S.panel
end

local CRAFT_PKG = "/Game/Blueprints/Widgets/Inventory/W_Inventory_CraftingArea"
local FAV_ARCH  = CRAFT_PKG .. ".W_Inventory_CraftingArea_C:WidgetTree.Checkbox_AddToFavorites"
local STAR_TEX  = "/Game/Textures/GUI/icon_star.icon_star"
local starLogged = false
local function makeStar(p, tree)
    local arch = StaticFindObject(FAV_ARCH)
    if not valid(arch) then pcall(LoadAsset, CRAFT_PKG); arch = StaticFindObject(FAV_ARCH) end
    local cb, how
    if valid(arch) then
        pcall(function()
            seq = seq + 1
            cb = StaticConstructObject(cls("/Script/UMG.CheckBox"), tree, FName("CookingRadiusStar_" .. LOADTAG .. "_" .. seq),
                0, 0, false, false, arch)
        end)
        local ok = false
        pcall(function() ok = valid(cb) and addr(cb.WidgetStyle.CheckedImage.ResourceObject) == addr(arch.WidgetStyle.CheckedImage.ResourceObject)
            and addr(cb.WidgetStyle.CheckedImage.ResourceObject) ~= 0 end)
        how = ok and "crafting favourite checkbox" or nil
        if not ok then cb = nil end
    end
    if not cb then

        cb = construct("/Script/UMG.CheckBox", tree)
        local star = loadTex(STAR_TEX)
        local tints = { UncheckedImage = { 0.356, 0.356, 0.356, 1 }, UncheckedHoveredImage = { 1, 0.78, 0.2, 1 },
            UncheckedPressedImage = { 1, 1, 1, 1 }, CheckedImage = { 1, 0.78, 0.15, 1 },
            CheckedHoveredImage = { 1, 0.9, 0.5, 1 }, CheckedPressedImage = { 1, 1, 1, 1 } }
        pcall(function() cb.WidgetStyle.CheckBoxType = 1 end)
        for k, c in pairs(tints) do
            pcall(function()
                local br = cb.WidgetStyle[k]
                br.ResourceObject = star
                br.DrawAs = 3
                br.TintColor = { SpecifiedColor = { R = c[1], G = c[2], B = c[3], A = c[4] }, ColorUseRule = 0 }
            end)
        end
        how = "fallback star (archetype " .. (valid(arch) and "found" or "missing") .. ")"
    end
    pcall(function() cb.IsFocusable = false end)

    pcall(function() cb:SetVisibility(0) end)
    pcall(function() cb:SetRenderOpacity(1.0) end)
    if not starLogged then starLogged = true end
    return cb
end
local function recipeName(row) return ((DATA.recipeNames or {})[row] or row):lower() end

local function showPanel(p)
    local pn = (S.panel and valid(S.panel.root)) and S.panel or buildPanel(p)
    local unlocked = unlockedSet(p)

    pcall(function() pn.grid:ClearChildren() end)
    pn.entries = {}
    local main = p.InventoryReference
    pcall(function() pn.frame:RemoveFromParent() end)
    pn.frame:SetVisibility(0)
    local cs = main.Panel_Primary:AddChildToCanvas(pn.frame)
    local x = (1920 - settings.containerw - settings.gap - settings.recipew) / 2 + settings.containerw + settings.gap
    cs:SetPosition({ X = x, Y = settings.top })
    cs:SetSize({ X = settings.recipew, Y = settings.height })
    pcall(function() cs:SetZOrder(50) end)
    local entryClass = cls(SOUPENTRY)
    if not valid(entryClass) then pcall(LoadAsset, "/Game/Blueprints/Widgets/Journal/W_Compendium_SoupEntry"); entryClass = cls(SOUPENTRY) end
    if not valid(entryClass) then log("W_Compendium_SoupEntry_C not found"); return end
    local n = 0
    for _, row in ipairs(soupRows()) do
        local ok, err = pcall(function()
            local e = cls(WBL):Create(p, entryClass, p:GetController())
            e.SoupRecipeRow = FName(row)
            e.Unlocked = unlocked[row] == true
            local cols = math.max(1, math.floor(settings.columns))

            local tree = pn.root.WidgetTree
            local box = construct("/Script/UMG.Overlay", tree)
            local es = box:AddChildToOverlay(e)
            es:SetHorizontalAlignment(0); es:SetVerticalAlignment(0)
            local star
            do
                star = makeStar(p, tree)
                pcall(function() star:SetIsChecked(favs[row] == true) end)
                local size = construct("/Script/UMG.SizeBox", tree)
                size:SetWidthOverride(settings.favsize); size:SetHeightOverride(settings.favsize)
                size:AddChild(star)
                local ss = box:AddChildToOverlay(size)
                ss:SetHorizontalAlignment(3); ss:SetVerticalAlignment(1)
                ss:SetPadding({ Left = 0, Top = settings.favy, Right = settings.favx, Bottom = 0 })
            end
            local sl = pn.grid:AddChildToUniformGrid(box, n // cols, n % cols)
            pcall(function() sl:SetHorizontalAlignment(0) end)
            pn.entries[#pn.entries + 1] = { w = e, box = box, star = star, slot = sl, row = row,
                unlocked = unlocked[row] == true }
            n = n + 1
        end)
    end
    local stars = 0
    for _, en in ipairs(pn.entries) do if en.star and valid(en.star) then stars = stars + 1 end end
    pn.lastQ = nil
end

local function hidePanel()
    if S.panel and valid(S.panel.frame) then
        local f = S.panel.frame
        pcall(function() f:SetVisibility(1) end)
        local ok, err = pcall(function() f:RemoveFromParent() end)
        if not ok then log("recipe panel remove failed: %s", tostring(err)) end
    end
end

local function removeStalePanels()
    local cur = S.panel and addr(S.panel.frame) or 0
    local n = 0
    for _, w in ipairs(FindAllOf("Overlay") or {}) do
        if valid(w) and addr(w) ~= cur then
            local ok, name = pcall(function() return w:GetFName():ToString() end)
            if ok and name:find("^CookingRadius_") then
                pcall(function() w:SetVisibility(1) end)
                pcall(function() w:RemoveFromParent() end)
                n = n + 1
            end
        end
    end
end

local saved = nil
local function applyLayout(main)
    if saved then return end
    saved = { vis = {}, pos = nil }
    local hide = {}
    pcall(function() hide[#hide + 1] = main.W_Inventory_EquipSlots end)
    pcall(function() hide[#hide + 1] = main.CharacterBGGlow end)
    pcall(function() hide[#hide + 1] = main.W_Inventory_PlayerBackpack:GetParent() end)
    pcall(function() hide[#hide + 1] = main.W_InventoryGenericDropArea end)
    pcall(function() hide[#hide + 1] = main.TestTube_BG end)
    pcall(function() hide[#hide + 1] = main.W_PlayerHUD_Hotbar end)
    pcall(function() hide[#hide + 1] = main.HotbarTipIcon end)
    pcall(function() hide[#hide + 1] = main.W_Inventory_NavBar end)
    for _, w in ipairs(hide) do
        if valid(w) then
            saved.vis[#saved.vis + 1] = { w = w, v = w:GetVisibility() }
            w:SetVisibility(1)
        end
    end
    pcall(function()
        local sl = main.WS_PrimaryRightPanel.Slot
        local pos = sl:GetPosition()
        saved.pos = { X = pos.X, Y = pos.Y }
        saved.slot = sl
        sl:SetPosition({ X = (1920 - settings.containerw - settings.gap - settings.recipew) / 2, Y = pos.Y })
    end)
end
local function restoreLayout()
    if not saved then return end
    for _, e in ipairs(saved.vis) do
        if valid(e.w) then pcall(function() e.w:SetVisibility(e.v) end) end
    end
    if saved.pos and valid(saved.slot) then pcall(function() saved.slot:SetPosition(saved.pos) end) end
    saved = nil
end

local addToPot
local isCookingPot
local queue = {}
local flick = {}
local iconOwner = {}
local slotByIdx = {}
local hl = { key = "", idx = {} }

local function setOutline(idx, on)
    local w = slotByIdx[idx]
    if not valid(w) then return end
    local ok = pcall(function() w["Toggle Bounce Outline"](w, on, on) end)
    if not ok and on then
        pcall(function() w.ParentInventoryGrid:HighlightSlot(idx, true) end)
    end
end
local function ingredientRows(en, row)
    local rows = { row }
    for _, g in ipairs((DATA.recipes or {})[en.row] or {}) do
        local inGroup = false
        for _, r in ipairs(g) do if r == row then inGroup = true; break end end
        if inGroup then rows = g; break end
    end
    return rows
end
local function hoverTick(pn)
    local rows
    for _, en in ipairs(pn.entries) do
        local w = en.w
        if valid(w) and (not en.box or en.box:IsVisible()) then
            for _, k in ipairs({ "Item1", "Item2", "Item3", "Item4" }) do
                local sl = w[k]
                if valid(sl) and sl:IsHovered() then
                    local ok, r = pcall(function() return sl.ItemInSlot.ItemDataTable.RowName:ToString() end)
                    if ok and r and r ~= "" and r ~= "None" then rows = ingredientRows(en, r) end
                    break
                end
            end
        end
        if rows then break end
    end
    local want = {}
    if rows then
        for _, r in ipairs(rows) do
            for i, e in ipairs(S.items) do if e.row == r and e.total > 0 then want[#want + 1] = i - 1 end end
        end
    end
    table.sort(want)
    local key = table.concat(want, ",")
    if key == hl.key then return end
    for _, idx in ipairs(hl.idx) do setOutline(idx, false) end
    for _, idx in ipairs(want) do setOutline(idx, true) end
    hl.key, hl.idx = key, want
end

local function pretty(row) return (row:gsub("^food_", ""):gsub("^gib_", ""):gsub("_", " ")) end
local function warn(text)
    pcall(function() S.p:Client_DisplayWarningMessage(FText(text), 1, false) end)
end

local function cookRecipe(row)
    local groups = DATA.recipes and DATA.recipes[row]
    if not groups then warn("No ingredient list for " .. row); return end
    local have, missing, used, picks = {}, {}, {}, {}
    for _, e in ipairs(S.items) do have[e.row] = e.total end
    for _, g in ipairs(groups) do
        local pick
        for _, r in ipairs(g) do
            if (have[r] or 0) - (used[r] or 0) > 0 then pick = r; break end
        end
        if pick then used[pick] = (used[pick] or 0) + 1; picks[#picks + 1] = pick
        else missing[#missing + 1] = pretty(g[1]) end
    end

    if #missing > 0 then
        warn(string.format("Missing %d ingredient(s): %s", #missing, table.concat(missing, ", ")))
        return false
    end
    for _, r in ipairs(picks) do queue[#queue + 1] = r end
    return true
end

local function slotIndexOf(row)
    for i, e in ipairs(S.items) do if e.row == row and e.total > 0 then return i - 1 end end
end

local function lower(s) return (s or ""):lower() end
local function boxText(b)
    local ok, t = pcall(function() return b:GetText():ToString() end)
    return ok and t or ""
end
local function recipeMatches(en, rq, toks)
    if rq == "" and #toks == 0 then return true end
    if not en.unlocked then return false end
    if rq ~= "" then
        local name = lower((DATA.recipeNames or {})[en.row] or en.row)
        if not name:find(rq, 1, true) then return false end
    end
    local groups = (DATA.recipes or {})[en.row] or {}
    for _, t in ipairs(toks) do
        local hit = false
        for _, g in ipairs(groups) do
            for _, r in ipairs(g) do
                local nm = lower((DATA.itemNames or {})[r] or r)
                if nm:find(t, 1, true) or lower(r):find(t, 1, true) then hit = true; break end
            end
            if hit then break end
        end
        if not hit then return false end
    end
    return true
end
local function applySearch(pn)
    local rq = lower(boxText(pn.recipeBox)):gsub("^%s+", ""):gsub("%s+$", "")
    local iq = lower(boxText(pn.ingBox))
    local favMode = pn.mode == "fav"
    local key = rq .. "|" .. iq .. "|" .. (favMode and "fav" or "all")
    if key == pn.lastQ and not pn.refilter then return end

    local jump = key ~= pn.lastQ
    pn.lastQ = key
    pn.refilter = false
    local toks = {}
    for w in iq:gmatch("%S+") do if #toks < 3 then toks[#toks + 1] = w end end

    local order = {}
    for i, en in ipairs(pn.entries) do
        local fav = favs[en.row] == true
        order[#order + 1] = { en = en, i = i, show = (not favMode) or fav }
    end
    if favMode then
        table.sort(order, function(a, b)
            if a.show ~= b.show then return a.show end
            return recipeName(a.en.row) < recipeName(b.en.row)
        end)
    end
    local cols = math.max(1, math.floor(settings.columns))
    local n = 0
    for _, o in ipairs(order) do
        local en = o.en
        local cell = en.box or en.w
        if valid(cell) then
            if o.show and recipeMatches(en, rq, toks) then
                pcall(function()
                    en.slot:SetRow(n // cols)
                    en.slot:SetColumn(n % cols)
                end)
                pcall(function() cell:SetVisibility(0) end)
                n = n + 1
            else
                pcall(function() cell:SetVisibility(1) end)
            end
        end
    end
    if jump then
        pcall(function() pn.scroll:ScrollToStart() end)
        pn.holdTicks = 0
    elseif pn.holdTicks and pn.holdTicks > 0 then
        pcall(function() pn.scroll:SetScrollOffset(pn.holdOffset) end)
    end
    if valid(pn.empty) then
        pcall(function() pn.empty:SetVisibility((favMode and n == 0) and 4 or 1) end)
        pcall(function()
            local nothing = 0
            for _, en in ipairs(pn.entries) do if favs[en.row] then nothing = nothing + 1 end end
            pn.empty:SetText(FText(nothing == 0 and "No favorites yet. Click the star on a recipe to add it here."
                or "No favorite recipes match the search."))
        end)
    end
end

local typing = false
local SBL = "/Script/UMG.Default__SlateBlueprintLibrary"
local WLL = "/Script/UMG.Default__WidgetLayoutLibrary"

local placeErr = false
local function placeSearch(pn)
    if not valid(pn.sroot) then return end
    if not pn.sroot:IsInViewport() then pn.sroot:AddToViewport(settings.searchz) end
    local ok, err = pcall(function()

        local wll = cls(WLL)
        local px = wll:GetViewportSize(S.p)
        local dpi = wll:GetViewportScale(S.p)
        local vw, vh = px.X / dpi, px.Y / dpi
        local k = math.min(vw / 1920, vh / 1080)
        local ox, oy = (vw - 1920 * k) / 2, (vh - 1080 * k) / 2
        local frameX = (1920 - settings.containerw - settings.gap - settings.recipew) / 2 + settings.containerw + settings.gap
        local dx = frameX + settings.recipew - settings.padr - settings.searchw
        local dy = settings.top + settings.padt
        pn.scs:SetPosition({ X = ox + dx * k, Y = oy + dy * k })
        pn.sb:SetRenderScale({ X = k, Y = k })
    end)
    if not ok and not placeErr then placeErr = true; log("search placement failed: %s", tostring(err)) end
end
local function hideSearch(pn)
    if pn and valid(pn.sroot) then pcall(function() pn.sroot:RemoveFromParent() end) end
end

local function searchFocusTick(pn)
    local focused = false
    pcall(function() focused = pn.recipeBox:HasKeyboardFocus() or pn.ingBox:HasKeyboardFocus() end)
    if focused == typing then return end
    typing = focused
    local p = S.p
    pcall(function()
        local pc = p:GetController()
        if focused then

            cls(WBL):SetInputMode_UIOnlyEx(pc, pn.recipeBox:HasKeyboardFocus() and pn.recipeBox or pn.ingBox, 0, false)
            pcall(function() p:DisableInput(pc) end)
            pcall(function() pc.bShowMouseCursor = true end)
        else
            pcall(function() p:EnableInput(pc) end)
            cls(WBL):SetInputMode_GameAndUIEx(pc, p.InventoryReference, 0, true, false)
        end
    end)
end

local function cardsTick()
    local pn = S.panel
    if not pn then return end
    iconOwner = {}

    local off
    pcall(function() off = pn.scroll:GetScrollOffset() end)
    if pn.holdTicks and pn.holdTicks > 0 then
        pn.holdTicks = pn.holdTicks - 1
        if off ~= pn.holdOffset then pcall(function() pn.scroll:SetScrollOffset(pn.holdOffset) end) end
    elseif off then
        pn.lastOffset = off
    end

    local changed = false
    for _, en in ipairs(pn.entries) do
        if en.star and valid(en.star) then
            local ok, on = pcall(function() return en.star:IsChecked() end)
            if ok and type(on) == "boolean" and on ~= (favs[en.row] == true) then
                favs[en.row] = on or nil
                changed = true
            end
        end
    end
    if changed then
        saveFavs(); pn.refilter = true
        if pn.lastOffset then
            pn.holdOffset = pn.lastOffset; pn.holdTicks = 4
            pcall(function() pn.scroll:SetScrollOffset(pn.holdOffset) end)
        end
    end

    if valid(pn.tabAll) and valid(pn.tabFav) then
        local function on(t) local ok, v = pcall(function() return t.CheckBox:IsChecked() end); return ok and v == true end
        local function set(t, v) pcall(function() t:SetNewCheckState(v and 1 or 0) end) end
        if not pn.tabsInit then
            pn.tabsInit = true
            set(pn.tabAll, pn.mode == "all"); set(pn.tabFav, pn.mode == "fav")
        else
            local a, f = on(pn.tabAll), on(pn.tabFav)
            local want = pn.mode
            if pn.mode == "all" and f then want = "fav" elseif pn.mode == "fav" and a then want = "all" end
            if want ~= pn.mode then pn.mode = want; pn.lastQ = nil end
            if a ~= (pn.mode == "all") then set(pn.tabAll, pn.mode == "all") end
            if f ~= (pn.mode == "fav") then set(pn.tabFav, pn.mode == "fav") end
            pcall(function() pn.tabLabel:SetText(FText(pn.mode == "fav" and "FAVORITES" or "ALL RECIPES")) end)
        end
    end
    for _, en in ipairs(pn.entries) do
        local w = en.w
        if valid(w) then
            pcall(function()
                local icon = w.PrimarySoupItem
                if not valid(icon) then return end
                iconOwner[addr(icon)] = en
                for _, k in ipairs({ "PrimarySoupItem", "Item1", "Item2", "Item3", "Item4" }) do
                    local sl = w[k]
                    if valid(sl) and not sl.RepresentationOnly then sl.RepresentationOnly = true end
                end
                local f = flick[en]
                if f and f > 0 then

                    icon:SetRenderOpacity((f % 2 == 0) and 0.25 or 1.0)
                    icon:SetRenderScale({ X = 1.12, Y = 1.12 })
                    flick[en] = f - 1
                elseif icon:IsHovered() then
                    icon:SetRenderOpacity(1.0)
                    icon:SetRenderScale({ X = 1.12, Y = 1.12 })
                    pcall(function() icon:SetColorAndOpacity({ R = 1.0, G = 0.95, B = 0.55, A = 1.0 }) end)
                else
                    icon:SetRenderOpacity(1.0)
                    icon:SetRenderScale({ X = 1.0, Y = 1.0 })
                    pcall(function() icon:SetColorAndOpacity({ R = 1.0, G = 1.0, B = 1.0, A = 1.0 }) end)
                end
            end)
        end
    end
end

local function onRecipeIconClick(en)
    flick[en] = 6
    cookRecipe(en.row)
end

local function ourGrid()
    local p = S.p
    if not valid(p) then return nil end
    local main = p.InventoryReference
    if not valid(main) then return nil end
    local cw = main.CurrentContainerWidget
    if not valid(cw) then return nil end
    local g = cw.W_InventoryGrid
    if not valid(g) or addr(g.MainInventoryComponent) ~= addr(S.virt) then return nil end
    return g, cw, main
end

local ourSlots = {}
local lockErr = false
local function lockSlots(g)

    local ok, err = pcall(function()
        local panel = g.UGrid_InventorySlots
        local n = panel:GetChildrenCount()
        local map, byIdx = {}, {}
        for i = 0, n - 1 do
            local s = panel:GetChildAt(i)
            if valid(s) then
                if s.RepresentationOnly ~= nil and not s.RepresentationOnly then s.RepresentationOnly = true end
                local idx = i
                pcall(function() idx = s.SlotIndex end)
                map[addr(s)] = idx
                byIdx[idx] = s
            end
        end

        if addr(byIdx[0]) ~= addr(slotByIdx[0]) then hl.key = ""; hl.idx = {} end
        ourSlots = map
        slotByIdx = byIdx
    end)
    if not ok and not lockErr then lockErr = true; log("slot lock failed: %s", tostring(err)) end
    return ok
end

local function resetInteract(p, why)
    if not valid(p) then return end
    local before = ""
    pcall(function()
        before = string.format("keyHeld=%s performing=%s lastA=%s", tostring(p.Local_KeyHeld_Interact),
            tostring(p.PerformingInteraction), tostring(p.LastInteractionWasTypeA))
    end)

    pcall(function() p.Local_KeyHeld_Interact = false end)
    pcall(function() p.PerformingInteraction = false end)
    pcall(function() p:Toggle_HUDHoldInteract(false, true) end)
end

local function close(reason)
    if not S.open then return end
    S.open = false
    pcall(resetInteract, S.p, "close")
    ourSlots = {}
    for _, idx in ipairs(hl.idx) do setOutline(idx, false) end

    for _, sl in pairs(slotByIdx) do
        pcall(function() if valid(sl) and sl.RepresentationOnly then sl.RepresentationOnly = false end end)
    end
    slotByIdx, hl = {}, { key = "", idx = {} }
    hidePanel()
    restoreLayout()
    queue, flick, iconOwner = {}, {}, {}
    hideSearch(S.panel)
    if typing then
        typing = false
        pcall(function() S.p:EnableInput(S.p:GetController()) end)
        pcall(function() cls(WBL):SetInputMode_GameOnly(S.p:GetController(), false) end)
    end

    pcall(function()
        local m = S.p.InventoryReference
        if valid(m) and m.InventoryMode == CONTAINER_VIEW and addr(m.ActiveContainer) == addr(S.virt) or not valid(m.ActiveContainer) then
            m.InventoryMode = 0
        end
    end)
    pcall(function() if valid(S.virt) then S.virt:RevertInventoryToEmpty() end end)
    S.items = {}
end

local function watch()
    if not S.open then return end
    local g, cw, main = ourGrid()
    local shown = g and main:IsVisible() and cw:IsVisible() and main.InventoryMode == CONTAINER_VIEW
    if not shown then
        S.misses = (S.misses or 0) + 1
        if S.misses > 3 then
            local why = "inventory closed"
            pcall(function()
                local m = S.p.InventoryReference
                why = string.format("grid=%s mainVisible=%s mode=%s activeIsOurs=%s", tostring(g ~= nil),
                    tostring(m:IsVisible()), tostring(m.InventoryMode), tostring(addr(m.ActiveContainer) == addr(S.virt)))
            end)
            close(why)
        end
        return
    end
    S.misses = 0
    lockSlots(g)
    pcall(cardsTick)
    if S.panel then
        local ok, err = pcall(hoverTick, S.panel)
        if not ok and not S.hoverErr then S.hoverErr = true; log("ingredient hover failed: %s", tostring(err)) end
    end
    if S.panel then pcall(placeSearch, S.panel); pcall(applySearch, S.panel); pcall(searchFocusTick, S.panel) end
    if #queue > 0 and (not S.busy or os.clock() - (S.busyAt or 0) >= 2) then
        local row = table.remove(queue, 1)
        local idx = slotIndexOf(row)
        if idx then addToPot(idx) else warn("Ran out of " .. pretty(row)) end
    end
    if not S.named then
        pcall(function() cw.ContainerNameText:SetText(FText(titleText())) end)
        pcall(function() cw.Button_EditContainerName:SetVisibility(1) end)
        S.named = true
    end
end

local function startLoop()
    if S.loop then return end
    S.loop = true
    gtLoop(100, function()
        if not S.open then S.loop = false; return true end
        pcall(watch)
        if not S.open then S.loop = false; return true end
        return false
    end)
end

local function refresh()
    if not S.open or not valid(S.p) then return end
    S.items = scan(S.p)
    fillVirt(getVirt(), S.items)
    local g = ourGrid()
    if g then lockSlots(g) end
end

local function openCooking(p, pot, potComp)
    S.p, S.pot, S.potComp = p, pot, potComp
    S.quantum = true
    S.items = scan(p)
    local v = getVirt()
    if not valid(v) then log("could not create the virtual inventory"); return end
    pcall(function() v.DisplayName = FText(titleText()) end)
    fillVirt(v, S.items)
    S.open, S.named, S.misses = true, false, -10
    pcall(function() v.InventorySlotType = 1 end)
    local main = p.InventoryReference
    if valid(main) then pcall(function() main.ActiveContainer = v end) end
    p:ToggleInventory(false, CONTAINER_VIEW, {}, v, false)
    if valid(main) and addr(main.ActiveContainer) ~= addr(v) then
        main.ActiveContainer = v
        main.InventoryMode = CONTAINER_VIEW
        pcall(function() main:RefreshInventoryMode() end)
    end
    pcall(removeStalePanels)
    if valid(main) then pcall(applyLayout, main) end
    showPanel(p)
    startLoop()
end

function addToPot(slotIndex)
    if not S.open then return end
    local e = S.items[slotIndex + 1]

    if S.busy and os.clock() - (S.busyAt or 0) < 3 then
        if e and e.total > 0 then queue[#queue + 1] = e.row end
        return
    end
    local p, pot = S.p, S.pot
    if not e or e.total <= 0 then return end
    if not valid(p) or not valid(pot) then log("pot or player gone"); return end

    local ingr = {}
    pcall(function()
        local out = {}
        cls(IFL):ConvertIngredientsFromString(pot.ChangeableData.PlayerMadeString, p, out)
        local arr = out.Ingredients
        for i = 1, #arr do ingr[#ingr + 1] = arr[i]:ToString() end
    end)
    if #ingr >= 3 then warn("The pot is full"); queue = {}; return end
    for _, r in ipairs(ingr) do
        if r == e.row then warn(pretty(e.row) .. " is already in the pot"); return end
    end
    local src
    for _, s in ipairs(e.sources) do
        local sl = sourceSlot(s)
        if sl and sl.ItemDataTable.RowName:ToString() == e.row and sl.ChangeableData.CurrentStack > 0 then src = s; break end
    end
    if not src then refresh(); return end
    S.busy = true
    S.busyAt = os.clock()
    local rowName = FName(e.row)

    local function onYou()
        for _, inv in ipairs({ p.CharacterInventory, p.CharacterHotbarInventory }) do
            local slots = inv.CurrentInventory
            for i = 1, #slots do
                local sl = slots[i]
                if sl.ItemDataTable.RowName:ToString() == e.row and sl.ChangeableData.CurrentStack > 0 then return inv, i - 1 end
            end
        end
    end

    local function giveBack()
        local inv, idx = onYou()
        if not inv then return end
        local ok, err = pcall(function() p:Request_TryQuickMoveItem(inv, p, idx, false, src.comp, true, false) end)
        if not ok then log("return to container failed: %s", tostring(err)) end
    end
    local function done() S.busy = false; pcall(refresh) end
    local function cook()
        local ok, err = pcall(function() p:Request_RadialWheelSelectionInteract(pot, S.potComp, rowName) end)
        if not ok then log("pot add failed: %s", tostring(err)) end
        if src.own then gtDelay(350, done); return end

        gtDelay(p:HasAuthority() and 150 or 1000, function() pcall(giveBack); gtDelay(250, done) end)
    end
    if src.own then cook(); return end

    local ok, err = pcall(function()
        local sl = sourceSlot(src)
        p:GetController():Request_TransferItemsToPlayerByRowName(sl.ItemDataTable, src.comp, 1)
    end)
    if not ok then log("take from container failed: %s", tostring(err)); S.busy = false; return end
    gtDelay(p:HasAuthority() and 120 or 400, cook)
end

local function rowOf(h)
    local ok, r = pcall(function() return h.RowName:ToString() end)
    return ok and r or ""
end
function isCookingPot(proxy)
    if not valid(proxy) or not nameOfClass(proxy):find("CookingProxy", 1, true) then return false end
    local cw, orig = "", ""
    pcall(function() cw = rowOf(proxy.CookwareItem) end)
    pcall(function() orig = rowOf(proxy.OriginalItem) end)
    local pot = cw:find("^cookingpot") ~= nil or orig:find("^cookingpot") ~= nil

    pcall(function()
        local out = {}
        cls("/Game/Blueprints/Libraries/AbioticFunctionLibrary.Default__AbioticFunctionLibrary_C")
            :IsItemCookingPot(proxy.CookwareItem, proxy, out)
        if out.IsCookingPot ~= nil then pot = pot or out.IsCookingPot == true end
    end)
    return pot
end

local function hookAll()
    local ok1, e1 = pcall(RegisterHook, ENTER_WHEEL, function(ctx, classParam)
        local p = ctx:get()
        local c = classParam:get()
        local n = valid(c) and c:GetFName():ToString() or ""
        if not n:find("CookingItems", 1, true) then return end
        local pot, comp = p.BestInteractable_InteractA, p.BestInteractableComponent

        if not isCookingPot(pot) then return end
        ExecuteInGameThread(function()
            pcall(function() p:TryCloseRadialWheel(false, c, {}) end)
            if not valid(pot) then log("no pot in front of you"); return end
            local ok, err = pcall(openCooking, p, pot, comp)
            if not ok then log("open failed: %s", tostring(err)) end
        end)
    end)
    if not ok1 then log("hook EnterRadialWheel failed: %s", tostring(e1)) end

    local ok2, e2 = pcall(RegisterHook, SLOT_DOWN, function(ctx)
        if not S.open then return end
        local s = ctx:get()
        local en = iconOwner[addr(s)]
        if en then ExecuteInGameThread(function() pcall(onRecipeIconClick, en) end); return end
        local idx = ourSlots[addr(s)]
        if idx == nil then return end
        ExecuteInGameThread(function()

            if typing then pcall(function() S.p.InventoryReference:SetKeyboardFocus() end) end
            local ok, err = pcall(addToPot, idx)
            if not ok then log("add to pot failed: %s", tostring(err)) end
        end)
    end)
    if not ok2 then log("hook PerformMouseButtonDown failed: %s", tostring(e2)) end
end

local hooked = false
local function tryHook()
    if hooked then return true end
    -- Wait for a player character before looking up Blueprint classes: StaticFindObject on a class that isn't
    -- loaded yet (main menu, loading screen) misses, and on a miss UE4SS scans every UObject without a lock while
    -- the async loader creates objects -> crash in UObject::GetOutermost (2026-11-11, 2026-11-14).
    -- FindFirstOf only walks UE4SS's hash tables; the slot widget is loaded first so its lookup can't miss.
    if not valid(FindFirstOf("Abiotic_PlayerCharacter_C")) then return false end
    pcall(LoadAsset, "/Game/Blueprints/Widgets/Inventory/W_InventoryItemSlot")
    if not valid(StaticFindObject("/Game/Blueprints/Characters/Abiotic_PlayerCharacter.Abiotic_PlayerCharacter_C"))
        or not valid(StaticFindObject("/Game/Blueprints/Widgets/Inventory/W_InventoryItemSlot.W_InventoryItemSlot_C")) then
        return false
    end
    hooked = true
    pcall(removeStalePanels)
    hookAll()
    return true
end
gtLoop(2000, function()
    if hooked then return true end
    pcall(tryHook)
    return hooked
end)

log("loaded (radius %d m)", settings.radius)
