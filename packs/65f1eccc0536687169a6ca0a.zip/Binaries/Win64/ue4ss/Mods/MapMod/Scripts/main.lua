-- MapMod: full-screen facility map for Abiotic Factor (UE4SS Lua).
--   M            open / close the map
--   drag (LMB)   pan          wheel, = / -   zoom
--   right-click  add a marker and name it (right-click a marker to rename it, Shift+right-click to delete it)
--   Shift + wheel  change floor      middle click  centre on me (and follow my floor again)
--   W/A/S/D        pan the map
--   hover any icon, doorway or marker to see what it is and where it leads
--   click stairs, a lift, portal, tram or doorway to move the map to where it leads
-- Room and doorway names (Cafeteria, "To Level Two" ...) come from the game's own map boards.
-- The map is drawn from the game's own level geometry (floors, walls, stairs), one tile per area
-- and floor. Areas are grey until you take their map from a map board
-- (CharacterProgressionComponent.CurrentMaps); nothing unlocks by visiting.

local MOD = "[MapMod] "
local function log(fmt, ...) print(MOD .. string.format(fmt, ...) .. "\n") end
local function valid(o) return o ~= nil and o.IsValid ~= nil and o:IsValid() end

-- ---------------------------------------------------------------- paths
-- UE4SS runs with Binaries\Win64 as working dir; we also try the script's own folder
local MOD_DIR_REL = "ue4ss/Mods/MapMod/"
local function scriptDir()
    local src = debug.getinfo(1, "S").source or ""
    src = src:gsub("^@", ""):gsub("\\", "/")
    local dir = src:match("^(.*)/Scripts/[^/]+$")
    return dir and (dir .. "/") or nil
end
local MOD_DIR = scriptDir() or MOD_DIR_REL
local MARKERS_FILE = MOD_DIR .. "markers.txt"
local SETTINGS_FILE = MOD_DIR .. "settings.txt"

local okData, DATA = pcall(dofile, MOD_DIR .. "Scripts/tiles_data.lua")
if not okData then
    okData, DATA = pcall(require, "tiles_data")
end
if not okData or type(DATA) ~= "table" then
    log("could not load tiles_data.lua: %s", tostring(DATA))
    DATA = { tiles = {}, levels = {} }
end

-- ---------------------------------------------------------------- settings
local settings = { beacons = true, benches = true, quests = true, weather = true, others = true, custom = true, labels = true,
                   areaicons = true, rooms = true, zoom = 1.0, autoshot = false, panelscale = 0.5, legendscale = 0.5 }
local function loadSettings()
    local f = io.open(SETTINGS_FILE, "r"); if not f then return end
    for line in f:lines() do
        local k, v = line:match("^%s*(%w+)%s*=%s*(%S+)")
        if k and settings[k] ~= nil then
            if type(settings[k]) == "boolean" then settings[k] = (v == "true")
            else settings[k] = tonumber(v) or settings[k] end
        end
    end
    f:close()
end
local function saveSettings()
    local f = io.open(SETTINGS_FILE, "w"); if not f then return end
    for _, k in ipairs({ "beacons", "benches", "quests", "weather", "others", "custom", "labels", "rooms", "areaicons", "zoom", "autoshot",
                         "panelscale", "legendscale" }) do
        f:write(k .. "=" .. tostring(settings[k]) .. "\n")
    end
    f:close()
end
loadSettings()

-- ---------------------------------------------------------------- engine helpers
local cachedPC = nil
local function getPC()
    -- FindAllOf walks every object in the game: far too slow to do several times a frame, so keep the answer
    if cachedPC and valid(cachedPC) then return cachedPC end
    cachedPC = nil
    local pcs = FindAllOf("PlayerController")
    if not pcs then return nil end
    for _, pc in ipairs(pcs) do
        if valid(pc) then
            local ok, isLocal = pcall(function() return pc:IsLocalController() end)
            if ok and isLocal then cachedPC = pc; return pc end
        end
    end
    return nil
end
local function getPawn()
    local pc = getPC(); if not valid(pc) then return nil end
    local p = pc.Pawn
    return valid(p) and p or nil
end
local classCache = {}
local function cls(path)
    local c = classCache[path]
    if valid(c) then return c end
    c = StaticFindObject(path)
    if not valid(c) then pcall(LoadAsset, path); c = StaticFindObject(path) end
    classCache[path] = c
    return c
end
local function lib(path) return StaticFindObject(path) end
local WBL = "/Script/UMG.Default__WidgetBlueprintLibrary"
local WLL = "/Script/UMG.Default__WidgetLayoutLibrary"
local KRL = "/Script/Engine.Default__KismetRenderingLibrary"
local GPS = "/Script/Engine.Default__GameplayStatics"
local lastPanT = nil
local function key(name) return { KeyName = FName(name) } end
local function isPaused()
    local p = false
    pcall(function() p = StaticFindObject("/Script/Engine.Default__GameplayStatics"):IsGamePaused(getPC()) end)
    return p == true
end

-- map space: u = 100000 - worldY, v = worldX + 64000 (Unreal units); 1 canvas unit = BASE uu
local BASE = 25.0
local function worldToMap(x, y) return (100000 - y) / BASE, (x + 64000) / BASE end
local function mapToWorld(mu, mv) return mv * BASE - 64000, 100000 - mu * BASE end

-- ---------------------------------------------------------------- textures
local texCache = {}
local texName = {}       -- unique object name of each cached texture
local function texId(t) local n = nil; pcall(function() n = t:GetFName():ToString() end); return n end
local function loadTex(file)
    local t = texCache[file]
    -- a texture nothing else uses can be garbage collected (e.g. during a portal trip) and its memory
    -- reused by another object: only trust the cache while the object still has the name it was born with
    if valid(t) and texName[file] and texId(t) == texName[file] then return t end
    local krl = lib(KRL); local pc = getPC()
    for _, path in ipairs({ MOD_DIR .. "tiles/" .. file, MOD_DIR_REL .. "tiles/" .. file }) do
        local ok, res = pcall(function() return krl:ImportFileAsTexture2D(pc, path) end)
        if ok and valid(res) then texCache[file] = res; texName[file] = texId(res); return res end
    end
    log("could not load texture %s", file)
    return nil
end

-- ---------------------------------------------------------------- state
local ROOTSET = (EInternalObjectFlags and EInternalObjectFlags.RootSet) or 0x40000000
local VIS = { Visible = 0, Collapsed = 1, Hidden = 2, HitTestInvisible = 3, SelfHitTestInvisible = 4 }
local ui = nil            -- { root, tree, world, overlay, tiles = {...}, labels = {...}, ... }
local mapOpen = false
local readyAt = 0         -- os.clock() time after which the map may open (set after a world change)
local shotAt = nil        -- pending auto-screenshot time (settings.autoshot)
local zoom = settings.zoom
local panX, panY = 0, 0
local viewMode = "auto"   -- "auto" follows the player's height, "manual" after Shift+Wheel
local viewZ = 0           -- world height of the floor the map shows
local viewName = ""
local FEET = 100          -- player location is the capsule centre; the floor is about this far below
local unlocked = {}
local visited = {}         -- areas you have been to in this world: unlocks areas that have no map board
local VISIT = {}           -- which world the visited list belongs to, and its file
local markers = {}        -- { {x=,y=,z=,name=} }
local markerVisible
local tempWp = nil        -- temporary waypoint { x, y, z } (Shift+click on the map), shown on screen while playing
local hud = nil           -- on-screen waypoint widget
local uid = 0
-- every loaded copy of the mod names its objects differently: after a hot reload the new copy must not
-- construct objects with the old copy's names (UE would hand both copies the same widgets)
local LOADTAG = string.format("%x%04x", os.time() % 0xFFFFFF, math.random(0, 0xFFFF))
local function nextName(p) uid = uid + 1; return "MapMod_" .. p .. "_" .. LOADTAG .. "_" .. uid end
local RETIRED = 0.0123    -- render opacity the newer copy stamps on an older copy's widgets

local function construct(path, outer, name) return StaticConstructObject(cls(path), outer, FName(nextName(name))) end

-- after a hot reload the previous copy's (rooted) map widget would still be on screen: remove it
local reloadedOld = false
pcall(function()
    local all = FindAllOf("UserWidget") or {}
    for _, w in ipairs(all) do
        if valid(w) and w:GetFName():ToString():find("^MapMod_Root") then
            pcall(function() w:SetRenderOpacity(RETIRED) end)       -- tells the old copy's frame hook to stop
            pcall(function() w:RemoveFromParent() end)
            pcall(function() w:ClearInternalFlags(ROOTSET) end)
            reloadedOld = true
        end
    end
end)
-- if the old copy was reloaded while its map was open, it left the player's look/move input
-- disabled and the cursor showing: give them back (otherwise the game looks frozen)
if reloadedOld then
    ExecuteInGameThread(function()
        pcall(function()
            local pc = FindFirstOf("PlayerController")
            if not pc or not pc:IsValid() then return end
            pcall(function() pc:ResetIgnoreLookInput() end)
            pcall(function() pc:ResetIgnoreMoveInput() end)
            pcall(function() local p = pc.Pawn; if p and p:IsValid() then p:EnableInput(pc) end end)
            local paused = false
            pcall(function() paused = StaticFindObject("/Script/Engine.Default__GameplayStatics"):IsGamePaused(pc) end)
            if not paused then
                pcall(function() StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary"):SetInputMode_GameOnly(pc, true) end)
                pc.bShowMouseCursor = false
            end
            print("[MapMod] reloaded: restored player input left by the previous copy\n")
        end)
    end)
end

-- ---------------------------------------------------------------- markers file
local function loadMarkers()
    markers = {}
    local f = io.open(MARKERS_FILE, "r"); if not f then return end
    for line in f:lines() do
        local x, y, rest = line:match("^%s*([%-%d%.]+)%s*,%s*([%-%d%.]+)%s*,?%s*(.*)$")
        if x then
            local z, name = rest:match("^z=([%-%d%.]+)%s*,?%s*(.*)$")
            if not z then name = rest end
            table.insert(markers, { x = tonumber(x), y = tonumber(y), z = tonumber(z), name = name ~= "" and name or nil })
        end
    end
    f:close()
end
local function saveMarkers()
    local f = io.open(MARKERS_FILE, "w"); if not f then log("cannot write %s", MARKERS_FILE); return end
    f:write("# worldX, worldY, z=floor height, name   (one marker per line; edit freely while the game is closed)\n")
    for _, m in ipairs(markers) do
        if m.z then f:write(string.format("%.0f, %.0f, z=%.0f, %s\n", m.x, m.y, m.z, m.name or ""))
        else f:write(string.format("%.0f, %.0f, %s\n", m.x, m.y, m.name or "")) end
    end
    f:close()
end
loadMarkers()

-- ---------------------------------------------------------------- widgets
local function addToCanvas(canvas, w, x, y, sx, sy)
    local s = canvas:AddChildToCanvas(w)
    s:SetAutoSize(false)
    s:SetAnchors({ Minimum = { X = 0, Y = 0 }, Maximum = { X = 0, Y = 0 } })
    s:SetAlignment({ X = 0, Y = 0 })
    s:SetPosition({ X = x, Y = y })
    s:SetSize({ X = sx, Y = sy })
    return s
end

local function makeImage(tree, file, tint)
    local img = construct("/Script/UMG.Image", tree, "Img")
    local tex = loadTex(file)
    if tex then img:SetBrushFromTexture(tex, false) end
    if tint then img:SetColorAndOpacity(tint) end
    img:SetVisibility(VIS.HitTestInvisible)
    return img
end

local function makeText(tree, text, scale)
    local tb = construct("/Script/UMG.TextBlock", tree, "Txt")
    tb:SetText(FText(text))
    tb:SetVisibility(VIS.HitTestInvisible)
    pcall(function() tb:SetRenderTransformPivot({ X = 0.5, Y = 0.5 }) end)
    pcall(function() tb:SetRenderScale({ X = scale or 0.55, Y = scale or 0.55 }) end)
    pcall(function() tb:SetShadowOffset({ X = 1, Y = 1 }) end)
    return tb
end

-- Weather Clear buttons: world x, y, floor z (button height - 100), the weather it ends. From the level files
-- (Button_WeatherEnd_C: MFWest + DF_RadWaste = RadLeak, Office3 = Fog, DF_Overgrowth = Spores)
VISIT.weatherButtons = {
    { -5199, 36561, 514, "Radiation Leak" },
    { -23827, 18990, 2613, "Fog" },
    { 11845, 35544, -14284, "Spores" },
    { 8661, 8888, -17472, "Radiation Leak" },
}

local CATS = {
    { key = "beacons", label = "Beacons" },
    { key = "benches", label = "Crafting benches" },
    { key = "quests",  label = "Quest markers" },
    { key = "weather", label = "Weather Clear buttons" },
    { key = "others",  label = "Players & other" },
    { key = "custom",  label = "My markers" },
    { key = "labels",  label = "Area names" },
    { key = "rooms",   label = "Room names" },
    { key = "areaicons", label = "Stairs, lifts, doorways" },
}

-- what each icon is called (hover text and the legend at the bottom right)
local KIND_LABEL = { elevator = "Elevator", ladder = "Ladder", charge = "Charging Station", toilet = "Restroom",
                     mapboard = "Map Board", zipline = "Zipline", blastdoor = "Blast Door", tram = "Tram Station",
                     portal = "Portal", stairs = "Stairs", exit = "Doorway", link = "Passage" }
local LEGEND = { { "ui_arrow.png", "You" }, { "ui_pin.png", "My marker", { R = 0.95, G = 0.3, B = 0.35, A = 1 } },
                 { "ic_stairs.png", "Stairs" }, { "ic_elevator.png", "Elevator" }, { "ic_ladder.png", "Ladder" },
                 { "ic_exit.png", "Doorway" }, { "ic_link.png", "Passage" }, { "ic_tram.png", "Tram Station" },
                 { "ic_charge.png", "Charging Station" }, { "ic_toilet.png", "Restroom" }, { "ic_mapboard.png", "Map Board" },
                 { "ic_blastdoor.png", "Blast Door" }, { "ic_zipline.png", "Zipline" }, { "ic_portal.png", "Portal" },
                 { "ic_weather.png", "Weather Clear button", { R = 0.45, G = 0.85, B = 1, A = 1 } } }

local function buildUI()
    local gi = FindFirstOf("GameInstance")
    local root = StaticConstructObject(cls("/Script/UMG.UserWidget"), gi, FName(nextName("Root")), 0, ROOTSET)
    root.WidgetTree = construct("/Script/UMG.WidgetTree", root, "Tree")
    local tree = root.WidgetTree
    local canvas = construct("/Script/UMG.CanvasPanel", tree, "Canvas")
    tree.RootWidget = canvas

    -- dark full-screen background
    local bg = construct("/Script/UMG.Border", tree, "Bg")
    bg:SetBrushColor({ R = 0.055, G = 0.065, B = 0.08, A = 0.97 })
    bg:SetVisibility(VIS.HitTestInvisible)
    local bs = canvas:AddChildToCanvas(bg)
    bs:SetAnchors({ Minimum = { X = 0, Y = 0 }, Maximum = { X = 1, Y = 1 } })
    bs:SetOffsets({ Left = 0, Top = 0, Right = 0, Bottom = 0 })

    -- full-screen invisible button: it owns left-button drags (Slate gives it mouse capture while
    -- held), so panning no longer depends on the game's PlayerInput seeing the click
    local catcher = construct("/Script/UMG.Button", tree, "Catcher")
    pcall(function() catcher:SetBackgroundColor({ R = 0, G = 0, B = 0, A = 0 }) end)
    pcall(function() catcher:SetColorAndOpacity({ R = 0, G = 0, B = 0, A = 0 }) end)
    pcall(function() catcher.IsFocusable = false end)
    local cs = canvas:AddChildToCanvas(catcher)
    cs:SetAnchors({ Minimum = { X = 0, Y = 0 }, Maximum = { X = 1, Y = 1 } })
    cs:SetOffsets({ Left = 0, Top = 0, Right = 0, Bottom = 0 })

    -- map layer: tiles placed in map units, panned/zoomed by render transform
    local world = construct("/Script/UMG.CanvasPanel", tree, "World")
    world:SetVisibility(VIS.HitTestInvisible)
    addToCanvas(canvas, world, 0, 0, 10, 10)
    pcall(function() world:SetRenderTransformPivot({ X = 0, Y = 0 }) end)

    -- one image per (area, floor); textures load the first time a tile is shown
    local tiles = {}
    for _, t in ipairs(DATA.tiles) do
        local img = construct("/Script/UMG.Image", tree, "Tile")
        img:SetVisibility(VIS.Collapsed)
        local s = addToCanvas(world, img, t.u / BASE, t.v / BASE, t.w / BASE, t.h / BASE)
        table.insert(tiles, { def = t, img = img, slot = s, loaded = false })
    end
    -- area icons (lifts, ladders, charging stations ...) live in map space and are resized on zoom
    local sicons = {}
    for _, ic in ipairs(DATA.icons or {}) do
        local img = construct("/Script/UMG.Image", tree, "Ico")
        img:SetVisibility(VIS.Collapsed)
        local mu, mv = worldToMap(ic.x, ic.y)
        local s = addToCanvas(world, img, mu, mv, 1, 1)
        s:SetAlignment({ X = 0.5, Y = 0.5 })
        pcall(function() s:SetZOrder(ic.kind == "exit" and 12 or (ic.kind == "stairs" and 9 or 10)) end)
        table.insert(sicons, { def = ic, img = img, slot = s, mu = mu, mv = mv, loaded = false, shown = false })
    end

    -- overlay: things that keep their size while zooming
    local overlay = construct("/Script/UMG.CanvasPanel", tree, "Overlay")
    overlay:SetVisibility(VIS.SelfHitTestInvisible)
    local os_ = canvas:AddChildToCanvas(overlay)
    os_:SetAnchors({ Minimum = { X = 0, Y = 0 }, Maximum = { X = 1, Y = 1 } })
    os_:SetOffsets({ Left = 0, Top = 0, Right = 0, Bottom = 0 })

    local labels = {}
    for name, lv in pairs(DATA.levels) do
        if lv.cu then
            local tb = makeText(tree, string.upper(lv.name), 0.5)
            local s = overlay:AddChildToCanvas(tb)
            s:SetAutoSize(true)
            s:SetAlignment({ X = 0.5, Y = 0.5 })
            labels[name] = { tb = tb, slot = s, u = lv.cu / BASE, v = lv.cv / BASE }
        end
    end
    -- room names from the vanilla map boards (Cafeteria, Data Farm ...): screen space, shown when zoomed in
    local rooms = {}
    for _, n in ipairs(DATA.names or {}) do
        local tb = makeText(tree, string.upper(n.text), 0.36)
        tb:SetVisibility(VIS.Collapsed)
        pcall(function() tb:SetRenderOpacity(0.85) end)
        local s = overlay:AddChildToCanvas(tb)
        s:SetAutoSize(true); s:SetAlignment({ X = 0.5, Y = 0.5 })
        table.insert(rooms, { def = n, tb = tb, slot = s, u = n.u / BASE, v = n.v / BASE, visible = false })
    end
    -- links: places where two areas' floors meet (screen space, few at a time); name shows on hover
    local links = {}
    for _, l in ipairs(DATA.links or {}) do
        local img = makeImage(tree, "ic_link.png")
        img:SetVisibility(VIS.Collapsed)
        local s = addToCanvas(overlay, img, 0, 0, 20, 20)
        s:SetAlignment({ X = 0.5, Y = 0.5 })
        table.insert(links, { def = l, img = img, slot = s, u = l.u / BASE, v = l.v / BASE, visible = false })
    end

    local player = makeImage(tree, "ui_arrow.png", { R = 1, G = 1, B = 1, A = 1 })
    local ps = addToCanvas(overlay, player, 0, 0, 26, 26)
    ps:SetAlignment({ X = 0.5, Y = 0.5 })
    pcall(function() player:SetRenderTransformPivot({ X = 0.5, Y = 0.5 }) end)

    -- legend / toggles (top-left)
    local panel = construct("/Script/UMG.Border", tree, "Legend")
    panel:SetBrushColor({ R = 0.02, G = 0.025, B = 0.03, A = 0.85 })
    panel:SetPadding({ Left = 12, Top = 10, Right = 14, Bottom = 10 })
    local ls = canvas:AddChildToCanvas(panel)
    ls:SetAutoSize(true); ls:SetPosition({ X = 16, Y = 16 })
    -- shrink the whole panel around its top-left corner (clicks on the checkboxes follow the scaling)
    pcall(function() panel:SetRenderTransformPivot({ X = 0, Y = 0 }) end)
    pcall(function() panel:SetRenderScale({ X = settings.panelscale, Y = settings.panelscale }) end)
    local vbox = construct("/Script/UMG.VerticalBox", tree, "LegendBox")
    panel:SetContent(vbox)
    local title = makeText(tree, "FACILITY MAP", 1.0)
    pcall(function() title:SetRenderScale({ X = 1, Y = 1 }) end)
    vbox:AddChildToVerticalBox(title)
    local viewText = makeText(tree, "", 1.0)
    pcall(function() viewText:SetRenderScale({ X = 1, Y = 1 }) end)
    vbox:AddChildToVerticalBox(viewText)
    local checks = {}
    for _, c in ipairs(CATS) do
        local row = construct("/Script/UMG.HorizontalBox", tree, "Row")
        local cb = construct("/Script/UMG.CheckBox", tree, "Chk")
        cb:SetIsChecked(settings[c.key])
        row:AddChildToHorizontalBox(cb)
        local tb = makeText(tree, "  " .. c.label, 1.0)
        pcall(function() tb:SetRenderScale({ X = 1, Y = 1 }) end)
        row:AddChildToHorizontalBox(tb)
        vbox:AddChildToVerticalBox(row)
        checks[c.key] = cb
    end
    local help = makeText(tree, "Drag or W/A/S/D: pan   Wheel or = / -: zoom   Shift+Wheel: floor\nRight-click: add marker / rename it   Shift+Right-click: delete it\nShift+click: set a waypoint (on screen while you play; the orange pin and dots show the route)\nClick a quest icon: waypoint on that quest\nSearch box (top right): highlights matching icons in gold, greys out the rest\nHover an icon to see what it is / where it goes\nClick stairs, lifts, portals, trams, doorways: go there\nMiddle click: centre on me   M: close", 1.0)
    pcall(function() help:SetRenderScale({ X = 1, Y = 1 }) end)
    vbox:AddChildToVerticalBox(help)

    -- icon legend: one row in the bottom-right corner
    local leg = construct("/Script/UMG.Border", tree, "IconLegend")
    leg:SetBrushColor({ R = 0.02, G = 0.025, B = 0.03, A = 0.85 })
    leg:SetPadding({ Left = 14, Top = 8, Right = 6, Bottom = 8 })
    leg:SetVisibility(VIS.HitTestInvisible)
    local lgs = canvas:AddChildToCanvas(leg)
    lgs:SetAutoSize(true)
    lgs:SetAnchors({ Minimum = { X = 1, Y = 1 }, Maximum = { X = 1, Y = 1 } })
    lgs:SetAlignment({ X = 1, Y = 1 })
    lgs:SetPosition({ X = -16, Y = -16 })
    pcall(function() leg:SetRenderTransformPivot({ X = 1, Y = 1 }) end)
    pcall(function() leg:SetRenderScale({ X = settings.legendscale, Y = settings.legendscale }) end)
    local hb = construct("/Script/UMG.HorizontalBox", tree, "IconLegendRow")
    leg:SetContent(hb)
    for _, it in ipairs(LEGEND) do
        local img = makeImage(tree, it[1], it[3])
        local s1 = hb:AddChildToHorizontalBox(img)
        pcall(function() s1:SetVerticalAlignment(2) end)
        local tb = makeText(tree, it[2], 1.0)
        pcall(function() tb:SetRenderScale({ X = 1, Y = 1 }) end)
        local s2 = hb:AddChildToHorizontalBox(tb)
        pcall(function() s2:SetVerticalAlignment(2) end)
        pcall(function() s2:SetPadding({ Left = 6, Top = 0, Right = 22, Bottom = 0 }) end)
    end

    -- name editor for custom markers (shown while typing a name)
    local editor = construct("/Script/UMG.Border", tree, "MarkerEditor")
    editor:SetBrushColor({ R = 0.02, G = 0.025, B = 0.03, A = 0.95 })
    editor:SetPadding({ Left = 12, Top = 8, Right = 12, Bottom = 10 })
    editor:SetVisibility(VIS.Collapsed)
    local es = canvas:AddChildToCanvas(editor)
    es:SetAutoSize(true)
    pcall(function() es:SetZOrder(50) end)
    pcall(function() editor:SetRenderTransformPivot({ X = 0, Y = 0 }) end)
    pcall(function() editor:SetRenderScale({ X = 0.6, Y = 0.6 }) end)
    local evb = construct("/Script/UMG.VerticalBox", tree, "MarkerEditorBox")
    editor:SetContent(evb)
    local etitle = makeText(tree, "Name this marker", 1.0)
    pcall(function() etitle:SetRenderScale({ X = 1, Y = 1 }) end)
    evb:AddChildToVerticalBox(etitle)
    local ebox = construct("/Script/UMG.EditableTextBox", tree, "MarkerName")
    pcall(function() ebox:SetHintText(FText("Marker name")) end)
    pcall(function() ebox.MinimumDesiredWidth = 420 end)
    -- dark text on the light box (the default style draws it grey)
    local BLACK = { R = 0, G = 0, B = 0, A = 1 }
    pcall(function() ebox:SetForegroundColor(BLACK) end)
    pcall(function() ebox.WidgetStyle.ForegroundColor.SpecifiedColor = BLACK end)
    pcall(function() ebox.WidgetStyle.FocusedForegroundColor.SpecifiedColor = BLACK end)
    pcall(function() ebox.WidgetStyle.ForegroundColor.ColorUseRule = 0 end)
    pcall(function() ebox.WidgetStyle.FocusedForegroundColor.ColorUseRule = 0 end)
    pcall(function() ebox.WidgetStyle.TextStyle.ColorAndOpacity.SpecifiedColor = BLACK end)
    local ebs = evb:AddChildToVerticalBox(ebox)
    pcall(function() ebs:SetPadding({ Left = 0, Top = 6, Right = 0, Bottom = 6 }) end)
    local ehelp = makeText(tree, "Enter: save    Esc: cancel", 1.0)
    pcall(function() ehelp:SetRenderScale({ X = 0.8, Y = 0.8 }) end)
    evb:AddChildToVerticalBox(ehelp)

    -- search box (top right): icons that match get a golden ring, the rest are greyed out
    local sp = construct("/Script/UMG.Border", tree, "SearchPanel")
    sp:SetBrushColor({ R = 0.02, G = 0.025, B = 0.03, A = 0.85 })
    sp:SetPadding({ Left = 12, Top = 8, Right = 12, Bottom = 8 })
    sp:SetVisibility(VIS.Visible)
    local sps = canvas:AddChildToCanvas(sp)
    sps:SetAutoSize(true)
    sps:SetAnchors({ Minimum = { X = 1, Y = 0 }, Maximum = { X = 1, Y = 0 } })
    sps:SetAlignment({ X = 1, Y = 0 })
    sps:SetPosition({ X = -16, Y = 16 })
    pcall(function() sp:SetRenderTransformPivot({ X = 1, Y = 0 }) end)
    pcall(function() sp:SetRenderScale({ X = 0.6, Y = 0.6 }) end)
    local svb = construct("/Script/UMG.VerticalBox", tree, "SearchBox")
    sp:SetContent(svb)
    local sbox = construct("/Script/UMG.EditableTextBox", tree, "SearchText")
    pcall(function() sbox:SetHintText(FText("Search icons  (portal, lift, bench, quest, weather, a marker name ...)")) end)
    pcall(function() sbox.MinimumDesiredWidth = 520 end)
    do
        local BLK = { R = 0, G = 0, B = 0, A = 1 }
        pcall(function() sbox:SetForegroundColor(BLK) end)
        pcall(function() sbox.WidgetStyle.ForegroundColor.SpecifiedColor = BLK end)
        pcall(function() sbox.WidgetStyle.FocusedForegroundColor.SpecifiedColor = BLK end)
        pcall(function() sbox.WidgetStyle.ForegroundColor.ColorUseRule = 0 end)
        pcall(function() sbox.WidgetStyle.FocusedForegroundColor.ColorUseRule = 0 end)
        pcall(function() sbox.WidgetStyle.TextStyle.ColorAndOpacity.SpecifiedColor = BLK end)
    end
    svb:AddChildToVerticalBox(sbox)
    local sinfo = makeText(tree, "", 1.0)
    pcall(function() sinfo:SetRenderScale({ X = 0.85, Y = 0.85 }) end)
    sinfo:SetVisibility(VIS.Collapsed)
    svb:AddChildToVerticalBox(sinfo)

    -- hover tooltip (top of everything)
    local tip = construct("/Script/UMG.Border", tree, "Tip")
    tip:SetBrushColor({ R = 0.01, G = 0.012, B = 0.015, A = 0.92 })
    tip:SetPadding({ Left = 10, Top = 4, Right = 10, Bottom = 5 })
    tip:SetVisibility(VIS.Collapsed)
    local tips = canvas:AddChildToCanvas(tip)
    tips:SetAutoSize(true)
    pcall(function() tips:SetZOrder(60) end)
    pcall(function() tip:SetRenderTransformPivot({ X = 0, Y = 0 }) end)
    pcall(function() tip:SetRenderScale({ X = 0.62, Y = 0.62 }) end)
    local tipText = makeText(tree, "", 1.0)
    pcall(function() tipText:SetRenderScale({ X = 1, Y = 1 }) end)
    tip:SetContent(tipText)

    return { root = root, tree = tree, canvas = canvas, world = world, overlay = overlay, tiles = tiles,
             labels = labels, rooms = rooms, links = links, sicons = sicons, catcher = catcher, player = player, playerSlot = ps, checks = checks, viewText = viewText,
             editor = editor, editorSlot = es, editBox = ebox, editTitle = etitle,
             searchPanel = sp, searchBox = sbox, searchInfo = sinfo,
             tip = tip, tipSlot = tips, tipText = tipText, tipShown = nil,
             hits = {}, pool = {}, poolUsed = 0, customPool = {}, }
end

-- ---------------------------------------------------------------- marker pool (overlay icons)
local function poolIcon(kind)
    -- kind: "wp" (vanilla waypoint), "custom", "other"
    ui.poolUsed = ui.poolUsed + 1
    local e = ui.pool[ui.poolUsed]
    if not e then
        local img = makeImage(ui.tree, "ui_dot.png")
        local s = addToCanvas(ui.overlay, img, 0, 0, 18, 18)
        s:SetAlignment({ X = 0.5, Y = 0.5 })
        local tb = makeText(ui.tree, "", 0.5)
        local ts = ui.overlay:AddChildToCanvas(tb)
        ts:SetAutoSize(true); ts:SetAlignment({ X = 0, Y = 0.5 })
        e = { img = img, slot = s, tb = tb, tslot = ts, tex = nil, text = nil }
        ui.pool[ui.poolUsed] = e
    end
    return e
end
local function placeIcon(e, sx, sy, size, tex, tint, text)
    if tex and e.tex ~= tex then pcall(function() e.img:SetBrushFromTexture(tex, false) end); e.tex = tex end
    pcall(function() e.img:SetColorAndOpacity(tint or { R = 1, G = 1, B = 1, A = 1 }) end)
    e.slot:SetPosition({ X = sx, Y = sy })
    e.slot:SetSize({ X = size, Y = size })
    e.img:SetVisibility(VIS.HitTestInvisible)
    if text and text ~= "" then
        if e.text ~= text then e.tb:SetText(FText(text)); e.text = text end
        e.tslot:SetPosition({ X = sx + size * 0.5 + 2, Y = sy })
        e.tb:SetVisibility(VIS.HitTestInvisible)
    else
        e.tb:SetVisibility(VIS.Collapsed)
    end
end
local function hideUnusedIcons()
    for i = ui.poolUsed + 1, #ui.pool do
        ui.pool[i].img:SetVisibility(VIS.Collapsed)
        ui.pool[i].tb:SetVisibility(VIS.Collapsed)
    end
end

-- ---------------------------------------------------------------- game data
local function readUnlocked()
    unlocked = {}
    local pawn = getPawn(); if not pawn then return end
    pcall(function()
        local cpc = pawn.CharacterProgressionComponent
        cpc.CurrentMaps:ForEach(function(_, elem)
            unlocked[string.lower(elem:get():ToString())] = true   -- FNames are case-insensitive
        end)
    end)
end

local function playerPos()
    local pawn = getPawn(); if not pawn then return nil end
    local ok, loc = pcall(function() return pawn:K2_GetActorLocation() end)
    if not ok or not loc then return nil end
    local yaw = 0
    pcall(function() yaw = getPC():GetControlRotation().Yaw end)
    return loc.X, loc.Y, loc.Z, yaw
end

local function levelUnlocked(name)
    local lv = DATA.levels[name]; if not lv then return false end
    -- areas without a map board (portal worlds, some caves and sectors) unlock the first time you go there
    if lv.world or #(lv.unlock or {}) == 0 then
        -- cave/tunnel slices ("<area> surroundings") go with the area they surround
        if lv.parent == nil then
            lv.parent = false
            local base = (lv.name or ""):match("^(.-) surroundings$")
            if base then for k, o in pairs(DATA.levels) do if o.name == base and k ~= name then lv.parent = k end end end
        end
        return visited[name] == true or (lv.parent and visited[lv.parent] == true) or false
    end
    for _, r in ipairs(lv.unlock or {}) do
        if unlocked[string.lower(r)] then return true end
    end
    return visited[name] == true      -- an area you've walked into shows even before you hold its map board
end
local function storeyFor(lv, z)
    for i, st in ipairs(lv.storeys or {}) do
        if z >= st.zlo and z < st.zhi then return i, st end
    end
    return nil
end

-- portal worlds: each one is its own map, shown instead of the facility while you are in it or after
-- clicking a portal that leads there
local viewWorld = nil     -- level name of the portal world on screen, nil = the facility
local worldBox = nil
local function worldBoxes()
    if worldBox then return worldBox end
    worldBox = {}
    for _, t in ipairs(DATA.tiles) do
        local lv = DATA.levels[t.level]
        if lv and lv.world then
            local b = worldBox[t.level]
            if not b then b = { u0 = t.u, v0 = t.v, u1 = t.u + t.w, v1 = t.v + t.h, z0 = t.z, z1 = t.z }; worldBox[t.level] = b end
            b.u0 = math.min(b.u0, t.u); b.v0 = math.min(b.v0, t.v); b.u1 = math.max(b.u1, t.u + t.w); b.v1 = math.max(b.v1, t.v + t.h)
            b.z0 = math.min(b.z0, t.z); b.z1 = math.max(b.z1, t.z)
        end
    end
    return worldBox
end
local function worldAt(x, y, z)
    if not x then return nil end
    local u, v = 100000 - y, x + 64000
    local best, bd = nil, nil
    for name, b in pairs(worldBoxes()) do
        if u >= b.u0 - 3000 and u <= b.u1 + 3000 and v >= b.v0 - 3000 and v <= b.v1 + 3000
           and (not z or (z >= b.z0 - 4000 and z <= b.z1 + 4000)) then
            local d = math.abs((b.u0 + b.u1) / 2 - u) + math.abs((b.v0 + b.v1) / 2 - v)
            if not bd or d < bd then best, bd = name, d end
        end
    end
    return best
end
local function isWorld(name) local lv = DATA.levels[name]; return lv and lv.world end
-- the area whose map tile is under a world point (floor height z), or false
local function areaAt(x, y, z)
    local u, v = 100000 - y, x + 64000
    for _, t in ipairs(DATA.tiles) do
        if u >= t.u and u <= t.u + t.w and v >= t.v and v <= t.v + t.h and z >= t.zlo and z < t.zhi
            and z > t.z - 400 and z < t.z + 1200 then return t.level end
    end
    return false
end
local function inView(name)
    if isWorld(name) then return name == viewWorld end
    return viewWorld == nil
end

local NEAR = 260          -- tiles further than this from the shown height are drawn faint, underneath
local ICON = 22           -- on-screen size of area icons
local TINT_ON = { R = 0.36, G = 0.66, B = 1.0 }
local TINT_OFF = { R = 0.50, G = 0.53, B = 0.58 }
local TINT_WORLD = { R = 0.74, G = 0.52, B = 1.0 }
local WP_TINT = { R = 0.25, G = 1.0, B = 0.45, A = 1 }
local ROUTE_TINT = { R = 1.0, G = 0.78, B = 0.2, A = 1 }
local iconZoom = nil
local function resizeIcons()
    if not ui then return end
    iconZoom = zoom
    local sz = ICON / zoom
    for _, e in ipairs(ui.sicons) do
        if e.shown then e.slot:SetSize({ X = sz, Y = sz }) end
    end
end

local shownZ = nil
local hereLevel = nil     -- the area under the player / screen when the view was last set
local function applyView(z)
    viewZ = z
    if viewMode == "auto" then
        local px, py, pz = playerPos()
        if px then viewWorld = worldAt(px, py, pz) end
    end
    local chosen = {}
    for name, lv in pairs(DATA.levels) do
        local i = storeyFor(lv, z); if i then chosen[name] = i end
    end
    local px, py = playerPos()
    local cu, cv
    if viewMode == "auto" and px then cu, cv = worldToMap(px, py); cu, cv = cu * BASE, cv * BASE
    else
        -- browsing: name the area in the middle of the screen
        local w, h = 1920, 1080
        pcall(function()
            local s = lib(WLL):GetViewportSize(getPC()); local sc = lib(WLL):GetViewportScale(getPC())
            if s and sc and sc > 0 then w, h = s.X / sc, s.Y / sc end
        end)
        cu, cv = (w / 2 - panX) / zoom * BASE, (h / 2 - panY) / zoom * BASE
    end
    local here, hereFloor, hereCount = nil, 0, 0
    for _, t in ipairs(ui.tiles) do
        local d = t.def
        local ci = chosen[d.level]
        local top = ci == d.storey + 1
        local show = top or (ci and d.storey + 1 < ci and math.abs(z - DATA.levels[d.level].storeys[ci].z) < NEAR)
        if not inView(d.level) or not levelUnlocked(d.level) then show = false end     -- unknown areas stay hidden
        t.shown = show and true or false
        if show then
            if not t.loaded then
                t.loaded = true
                local tex = loadTex(d.file)
                if tex then pcall(function() t.img:SetBrushFromTexture(tex, false) end) end
            end
            local near = math.abs(z - d.z) < NEAR
            local c = isWorld(d.level) and TINT_WORLD or (levelUnlocked(d.level) and TINT_ON or TINT_OFF)
            -- the floor you're on is solid; floors below it in the same area show through faintly
            local alpha = top and (near and 1 or 0.18) or 0.28
            pcall(function() t.img:SetColorAndOpacity({ R = c.R, G = c.G, B = c.B, A = alpha }) end)
            pcall(function() t.slot:SetZOrder((top and near) and 3 or (top and 1 or 2)) end)
            t.img:SetVisibility(VIS.HitTestInvisible)
            if top and near and cu and cu >= d.u and cu <= d.u + d.w and cv >= d.v and cv <= d.v + d.h then
                here = d.level; hereFloor = d.storey + 1; hereCount = #(DATA.levels[d.level].storeys or {})
            end
        else
            t.img:SetVisibility(VIS.Collapsed)
        end
    end
    for _, e in ipairs(ui.sicons) do
        local d = e.def
        if e.world == nil then e.world = (isWorld(d.level) and d.level) or worldAt(d.x, d.y, d.z) or false end
        -- same floor test as the map tiles: the icon's own storey must be the one shown for its area
        local lvd = DATA.levels[d.level]
        local ci = chosen[d.level]
        local near
        if d.zlo then
            local zz = ci and lvd.storeys[ci].z or z
            near = zz >= d.zlo - 150 and zz <= d.zhi + 100 and math.abs(zz - z) < NEAR   -- stairs: every floor along the flight
        elseif ci then
            if e.si == nil then e.si = storeyFor(lvd, d.z) or false end
            near = e.si == ci and math.abs(d.z - z) < 350     -- an area's lowest storey can reach under another area's floor
        else near = math.abs(d.z - z) < 350 end
        -- an icon of the facility itself (portals, trams, lifts between areas) shows once the area around it does
        if e.under == nil then e.under = (d.level == "Facility" and areaAt(d.x, d.y, d.z)) or d.level end
        local show = settings.areaicons and near and e.under and levelUnlocked(e.under) and (e.world or nil) == viewWorld
        if show and not e.loaded then
            e.loaded = true
            local tex = loadTex("ic_" .. d.kind .. ".png")
            if tex then pcall(function() e.img:SetBrushFromTexture(tex, false) end) end
        end
        e.shown = show
        e.img:SetVisibility(show and VIS.HitTestInvisible or VIS.Collapsed)
    end
    resizeIcons()
    for _, l in ipairs(ui.links) do
        l.visible = settings.areaicons and math.abs(l.def.z - z) < 350 and inView(l.def.a) and inView(l.def.b)
            and levelUnlocked(l.def.a) and levelUnlocked(l.def.b)
        if not l.visible then l.img:SetVisibility(VIS.Collapsed) end
    end
    for name, l in pairs(ui.labels) do
        local _, st = storeyFor(DATA.levels[name], z)
        l.visible = settings.labels and st ~= nil and math.abs(z - st.z) < NEAR and inView(name) and levelUnlocked(name)
        l.tb:SetVisibility(l.visible and VIS.HitTestInvisible or VIS.Collapsed)
    end
    -- room names: only on the floor they belong to, and only once that area's map is taken
    for _, r in ipairs(ui.rooms) do
        local d = r.def
        local _, st = storeyFor(DATA.levels[d.level], z)
        r.visible = settings.rooms and st ~= nil and st.z == d.z and math.abs(z - st.z) < NEAR and levelUnlocked(d.level) and inView(d.level)
        if not r.visible then r.tb:SetVisibility(VIS.Collapsed); r.on = false end
    end
    hereLevel = here
    if here then
        viewName = (isWorld(here) and "Portal world: " or "") .. DATA.levels[here].name
            .. (hereCount > 1 and string.format("  -  floor %d of %d", hereFloor, hereCount) or "")
    elseif viewWorld then
        viewName = "Portal world: " .. DATA.levels[viewWorld].name
    else
        viewName = string.format("Height %.0f", z)
    end
    pcall(function()
        ui.viewText:SetText(FText(viewName .. (viewMode == "auto" and "  (following you)" or "")))
    end)
    shownZ = z
end

local function applyTransform()
    pcall(function() ui.world:SetRenderTranslation({ X = panX, Y = panY }) end)
    pcall(function() ui.world:SetRenderScale({ X = zoom, Y = zoom }) end)
    if iconZoom ~= zoom then resizeIcons() end
end

local function toScreen(mu, mv) return panX + mu * zoom, panY + mv * zoom end

-- vanilla HUD waypoints (beacons, crafting bench, quest, downed players, corpses, pager ...)
local function waypointCategory(className)
    if className:find("Beacon") then return "beacons" end
    if className:find("CraftingBench") then return "benches" end
    if className:find("Quest") then return "quests" end
    return "others"
end
local function waypointLocation(w)
    local loc = nil
    pcall(function()
        local a = w.LinkedActor
        if valid(a) then loc = a:K2_GetActorLocation() end
    end)
    if loc then return loc end
    pcall(function()
        local out = {}
        w:GetWaypointLocation(out)
        loc = out.Location
    end)
    return loc
end
local function waypointTexture(w)
    local tex = nil
    pcall(function()
        local r = w.WaypoointIcon.Brush.ResourceObject
        if valid(r) then tex = r end
    end)
    return tex
end
local function waypointText(w)
    local s = nil
    pcall(function() s = w.WaypointText:GetText():ToString() end)
    return s
end

local function friendlyClass(cn)
    local s = cn:gsub("^W_", ""):gsub("_C$", ""):gsub("_?Waypoint", ""):gsub("_", " ")
    s = s:gsub("(%l)(%u)", "%1 %2")
    if s == "" then s = "Waypoint" end
    return s
end
-- the HUD's live waypoint widgets (cached for half a second: FindAllOf is not free)
local wpCache, wpCacheAt, wpStats = {}, -1, ""
local PLACED = { "Deployed_Beacon_C", "Deployed_CraftingBench_Default_C", "Deployed_CraftingBench_Upgrade_C",
                 "Deployed_CraftingBench_SIGNAL_C", "Deployed_CraftingBench_Repair_C" }
local placed, placedAt = {}, -100
local function currentWaypoints()
    local now = os.clock()
    if now - wpCacheAt < 0.5 then return wpCache end
    wpCacheAt = now
    local list, seen = {}, {}
    local total, attached, located = 0, 0, 0
    pcall(function()
        for _, w in ipairs(FindAllOf("W_Waypoint_ParentBP_C") or {}) do
            total = total + 1
            local ok = valid(w)
            if ok then
                local nm = w:GetFName():ToString()
                if nm:find("^Default__") then ok = false end
            end
            if ok then
                local parentOk = false
                pcall(function() parentOk = valid(w:GetParent()) end)
                ok = parentOk
            end
            if ok then
                attached = attached + 1
                local loc = waypointLocation(w)
                if loc and (loc.X ~= 0 or loc.Y ~= 0) then
                    local k = string.format("%.0f_%.0f", loc.X / 50, loc.Y / 50)
                    if not seen[k] then
                        seen[k] = true; located = located + 1
                        local cn = w:GetClass():GetFName():ToString()
                        local label = friendlyClass(cn)
                        local txt = waypointText(w)
                        if txt and txt ~= "" and not txt:match("^[%d%.,]+%s*[mM]?$") and txt:lower() ~= label:lower() then
                            label = label .. ": " .. txt
                        end
                        local cat = waypointCategory(cn)
                        local row = nil
                        if cat == "quests" then pcall(function() row = w.QuestRow.RowName:ToString() end) end
                        list[#list + 1] = { cat = cat, loc = { X = loc.X, Y = loc.Y, Z = loc.Z }, tex = waypointTexture(w), label = label,
                                            pivot = cat == "beacons" or cat == "benches", row = row }
                    end
                end
            end
        end
    end)
    -- placed beacons and crafting benches straight from the world: the HUD only has widgets for some of them
    local now2 = os.clock()
    if now2 - placedAt > 3 then
        placedAt = now2; placed = {}
        for _, cn in ipairs(PLACED) do
            pcall(function()
                for _, a in ipairs(FindAllOf(cn) or {}) do
                    if valid(a) and not a:GetFName():ToString():find("^Default__") then
                        local l = a:K2_GetActorLocation()
                        placed[#placed + 1] = { cat = waypointCategory(cn), loc = { X = l.X, Y = l.Y, Z = l.Z }, pivot = true,
                                                label = cn:find("Beacon") and "Beacon" or "Crafting Bench" }
                    end
                end
            end)
        end
    end
    local tex = {}
    for _, it in ipairs(list) do if it.tex and not tex[it.cat] then tex[it.cat] = it.tex end end
    for _, it in ipairs(placed) do
        local k = string.format("%.0f_%.0f", it.loc.X / 50, it.loc.Y / 50)
        if not seen[k] then seen[k] = true; it.tex = tex[it.cat]; list[#list + 1] = it end
    end
    wpStats = string.format("%d widgets, %d in the HUD, %d with a location, %d placed beacons/benches", total, attached, located, #placed)
    wpCache = list
    return list
end

-- diagnostics: what the vanilla waypoint overlay holds right now
local function probeWaypoints()
    wpCacheAt = -1
    local list = currentWaypoints()
    log("waypoint probe: %s", wpStats)
    for i, it in ipairs(list) do
        if i > 12 then break end
        log("  wp %s [%s] at %.0f,%.0f,%.0f", it.label, it.cat, it.loc.X, it.loc.Y, it.loc.Z)
    end
end

-- the area floor a marker was placed on: the tile under it whose height band holds its z
local function markerFloor(m)
    if m.floorKey ~= nil then return m.floorKey end
    local u, v = (100000 - m.y), (m.x + 64000)
    local best, bd = false, nil
    for _, t in ipairs(DATA.tiles) do
        if u >= t.u and u <= t.u + t.w and v >= t.v and v <= t.v + t.h and m.z >= t.zlo - 50 and m.z < t.zhi + 50 then
            local d = math.abs(t.z - m.z)
            if not bd or d < bd then best, bd = { level = t.level, storey = t.storey + 1, z = t.z }, d end
        end
    end
    m.floorKey = best
    return best
end
markerVisible = function(m)
    if not m.z then return true end                 -- markers from before floors were saved: shown everywhere
    local f = markerFloor(m)
    if f then
        if not inView(f.level) then return false end
        local ci = storeyFor(DATA.levels[f.level], viewZ)
        return ci == f.storey
    end
    return math.abs(m.z - viewZ) < 300 and worldAt(m.x, m.y, m.z) == viewWorld
end

-- ---------------------------------------------------------------- route guide (waypoint on another floor / world)
-- route_data.lua (route.py): points at the ends of stairs, elevators, portals, trams and doorways, with the trips
-- between them and walking distances on each floor measured around the walls of the floor plans
local ROUTE = nil
local function loadRoute()
    if ROUTE ~= nil then return ROUTE end
    local ok, R = pcall(dofile, MOD_DIR .. "Scripts/route_data.lua")
    if not ok or type(R) ~= "table" or not R.nodes then log("no route data: %s", tostring(R)); ROUTE = false; return false end
    local adj, e, N, dropped = {}, R.edges, R.nodes, 0
    for k = 1, #e, 3 do
        -- floor-plan fallback walks that cost far more than their length crossed void or walls: not real ways
        -- (one of them led up a flight of stairs into a dead end in the Hydroplant)
        local a, b, c = N[e[k]], N[e[k + 1]], e[k + 2]
        local d = math.sqrt((a[1] - b[1]) ^ 2 + (a[2] - b[2]) ^ 2 + (a[3] - b[3]) ^ 2)
        if c > 30000 and c > 8 * d then dropped = dropped + 1
        else
            local l = adj[e[k]]; if not l then l = {}; adj[e[k]] = l end
            l[#l + 1] = e[k + 1]; l[#l + 1] = e[k + 2]
        end
    end
    log("route network: dropped %d walks through walls or void", dropped)
    R.adj = adj; R.edges = nil
    local B = {}
    for i, n in ipairs(R.nodes) do
        local key = math.floor(n[1] / 3000) .. ":" .. math.floor(n[2] / 3000)
        local b = B[key]; if not b then b = {}; B[key] = b end
        b[#b + 1] = i
    end
    R.buckets = B
    ROUTE = R
    log("route network: %d points", #R.nodes)
    return R
end
local function nearNodes(R, x, y, z, k)
    local out = {}
    local bx, by = math.floor(x / 3000), math.floor(y / 3000)
    for ring = 0, 6 do
        for i = bx - ring, bx + ring do
            for j = by - ring, by + ring do
                if math.max(math.abs(i - bx), math.abs(j - by)) == ring then
                    local b = R.buckets[i .. ":" .. j]
                    if b then
                        for _, id in ipairs(b) do
                            local n = R.nodes[id]
                            if math.abs(n[3] - z) < 320 then out[#out + 1] = { id, math.sqrt((n[1] - x) ^ 2 + (n[2] - y) ^ 2) } end
                        end
                    end
                end
            end
        end
        if #out >= k and ring >= 1 then break end
    end
    table.sort(out, function(a, b) return a[2] < b[2] end)
    while #out > k do out[#out] = nil end
    return out
end
local function hpush(h, d, v)
    h[#h + 1] = { d, v }; local i = #h
    while i > 1 do
        local p = i // 2
        if h[p][1] <= h[i][1] then break end
        h[p], h[i] = h[i], h[p]; i = p
    end
end
local function hpop(h)
    local top = h[1]; local last = table.remove(h)
    if #h > 0 then
        h[1] = last; local i = 1
        while true do
            local l, r, m = 2 * i, 2 * i + 1, i
            if l <= #h and h[l][1] < h[m][1] then m = l end
            if r <= #h and h[r][1] < h[m][1] then m = r end
            if m == i then break end
            h[m], h[i] = h[i], h[m]; i = m
        end
    end
    return top
end
-- shortest route from (px,py,pz) to (gx,gy,gz), z = floor height. Returns the list of route points ({} = just walk
-- straight there) and its length in uu, or nil when there is no route data
local function findRoute(px, py, pz, gx, gy, gz)
    local R = loadRoute(); if not R then return nil end
    local WALK = 2.0                                  -- off the network the walls are unknown: straight lines count double
    local best, bestEnd = math.huge, nil
    local straight = math.sqrt((gx - px) ^ 2 + (gy - py) ^ 2)
    -- walking straight there is only an option when it's close: far away, walls are certain (it led through them)
    if math.abs(gz - pz) < 180 and straight < 2500 then best = straight * 1.3 end
    local goal = {}
    local ok = VISIT.legOk or function() return true end
    for _, c in ipairs(nearNodes(R, gx, gy, gz, 6)) do
        local n = R.nodes[c[1]]
        -- a route point far from the waypoint is not a way there (it led to a dead end): better no route
        if c[2] < 8000 and ok(gx, gy, gz, n[1], n[2], n[3]) then goal[c[1]] = c[2] * WALK end
    end
    -- two layers: node id = no portal taken yet, -id = a portal was taken. A route through a portal wins when it
    -- costs at most PORTAL_PREF times the best route (the user prefers portals over trams on near ties)
    local PORTAL_PREF = 1.10
    local N = R.nodes
    local dist, prev, h = {}, {}, {}
    for _, c in ipairs(nearNodes(R, px, py, pz, 6)) do
        local d = c[2] * WALK
        local n = N[c[1]]
        if not ok(px, py, pz, n[1], n[2], n[3]) then d = math.huge end      -- the straight leg would go through a locked door
        if d < (dist[c[1]] or math.huge) then dist[c[1]] = d; prev[c[1]] = 0; hpush(h, d, c[1]) end
    end
    local bestP, bestPEnd = math.huge, nil
    local adj = R.adj
    while #h > 0 do
        local top = hpop(h); local d, s = top[1], top[2]
        if d >= best * PORTAL_PREF or d >= bestP then break end
        if d <= (dist[s] or math.huge) then
            local u, used = math.abs(s), s < 0
            local g = goal[u]
            if g and d + g < best then best, bestEnd = d + g, s end
            if g and used and d + g < bestP then bestP, bestPEnd = d + g, s end
            local l = adj[u]
            if l then
                local nu = N[u]
                local fromPortal = not used and nu[4] == "portal"
                local B = VISIT.blocked
                local came = prev[s] and math.abs(prev[s])
                for k = 1, #l, 2 do
                    local v, nd = l[k], d + l[k + 1]
                    if B and B[u * 10000 + v] then v, nd = 0, math.huge      -- through a door you can't open yet
                    -- never ride straight back the way you just came (a pipe there and back counted as "a portal
                    -- route" and won the 10% portal preference, so the guide looped you through the pipe)
                    elseif v == came and nu[4] ~= "walk" and N[v][4] == nu[4] then v, nd = 0, math.huge
                    elseif used then v = -v
                    elseif fromPortal then
                        local nv = N[v]
                        if (nv[1] - nu[1]) ^ 2 + (nv[2] - nu[2]) ^ 2 > 2000 ^ 2 then v = -v end
                    end
                    if v ~= 0 and nd < (dist[v] or math.huge) then dist[v] = nd; prev[v] = s; hpush(h, nd, v) end
                end
            end
        end
    end
    if bestPEnd and bestP <= best * PORTAL_PREF then best, bestEnd = bestP, bestPEnd end
    local path = {}
    local s = bestEnd
    while s and s ~= 0 do table.insert(path, 1, math.abs(s)); s = prev[s] end
    return path, best
end
-- the current route to the temporary waypoint (recomputed about once a second while it is set)
local route = nil         -- { path, len, at, wp }
local routeErrLogged = false
-- a walk on the game's own navmesh (what creatures use: real doors, stairs, ramps), or nil
local function navWalk(px, py, pz, gx, gy, gz)
    local pts, partial = {}, false
    local ok, err = pcall(function()
        local ns = StaticFindObject("/Script/NavigationSystem.Default__NavigationSystemV1")
        if not valid(ns) then return end
        local pawn = getPawn()
        local path = ns:FindPathToLocationSynchronously(pawn, { X = px, Y = py, Z = pz }, { X = gx, Y = gy, Z = gz }, pawn, nil)
        if not valid(path) then return end
        path.PathPoints:ForEach(function(_, e) local v = e:get(); pts[#pts + 1] = { x = v.X, y = v.Y, z = v.Z } end)
        pcall(function() partial = path:IsPartial() end)
    end)
    if not ok or #pts < 2 then return nil end
    local e = pts[#pts]
    if partial and ((e.x - gx) ^ 2 + (e.y - gy) ^ 2 > 600 ^ 2 or math.abs(e.z - gz) > 300) then return nil end
    local len = 0
    for i = 2, #pts do len = len + math.sqrt((pts[i].x - pts[i - 1].x) ^ 2 + (pts[i].y - pts[i - 1].y) ^ 2 + (pts[i].z - pts[i - 1].z) ^ 2) end
    return pts, len
end

local function currentRoute()
    if not tempWp then route = nil; return nil end
    local now = os.clock()
    -- keep following the same route (re-planning every second made the pin flip between two routes);
    -- plan again only when you have left it, or when there was no route to follow
    if route and route.wp == tempWp and not route.lost and (#route.pts > 0 or now - route.at < 1.0) then return route end
    local px, py, pz = playerPos(); if not px then return route end
    local t0 = os.clock()
    local ok, path, len = pcall(findRoute, px, py, pz - FEET, tempWp.x, tempWp.y, tempWp.z)
    if not ok then log("route error: %s", tostring(path)); path = nil end
    local dt = os.clock() - t0
    if not route or route.wp ~= tempWp then
        log("route to waypoint: %s, %.0f ms", path and (#path > 0 and (#path .. " points") or "walk straight there") or "none", dt * 1000)
    end
    -- the route as a polyline: route points plus the corners of the walk between them
    local pts = {}
    if path and #path > 0 and ROUTE then pts[1] = { x = px, y = py, z = pz - FEET } end     -- the leg from where you stand
    if path and ROUTE then
        local N, P = ROUTE.nodes, ROUTE.poly or {}
        for k, id in ipairs(path) do
            local n = N[id]
            pts[#pts + 1] = { x = n[1], y = n[2], z = n[3], id = id }
            local nxt = path[k + 1]
            local c = nxt and P[id .. ":" .. nxt]
            if nxt and not c then                       -- stored once for both directions: walk it backwards
                local r = P[nxt .. ":" .. id]
                if r then c = {}; for j = #r - 1, 1, -2 do c[#c + 1] = r[j]; c[#c + 1] = r[j + 1] end end
            end
            if c then
                local m = N[nxt]
                for j = 1, #c, 2 do
                    local f = (j + 1) / (#c + 2)
                    pts[#pts + 1] = { x = c[j], y = c[j + 1], z = n[3] + (m[3] - n[3]) * f }
                end
            end
        end
    end
    if #pts > 0 then pts[#pts + 1] = { x = tempWp.x, y = tempWp.y, z = tempWp.z } end
    -- if the game's navmesh can walk the whole way and that is shorter than our route (which may ride a
    -- tram or lift), walk: the navmesh knows the real doors and stairs
    local nt0 = os.clock()
    local wpts, wlen = navWalk(px, py, pz, tempWp.x, tempWp.y, tempWp.z + 50)
    local nms = (os.clock() - nt0) * 1000
    if not route or route.wp ~= tempWp then
        log("navmesh walk: %s (our route %s), %.0f ms", wpts and string.format("%.0f m", wlen / 100) or "none",
            len and len < math.huge and string.format("%.0f m", len / 100) or "none", nms)
    end
    if wpts and (not len or wlen < len) then
        pts = wpts; path = {}; len = wlen
        pts[#pts + 1] = { x = tempWp.x, y = tempWp.y, z = tempWp.z }
    end
    if route and route.wp == tempWp and route.lost then log("left the route: planning again") end
    route = { path = path, len = len, at = now, wp = tempWp, pts = pts, prog = 1 }
    return route
end
-- the next thing to head for: the first stairs/elevator/portal/tram/doorway on the route not yet reached
-- returns x, y, z, label, use (true = you are standing at it: use it)
-- how far along the route you are: the nearest bit of it in 3D (stairs and lifts are vertical bits, so
-- climbing moves you along them), never more than one step back
local function routeProgress(r, px, py, pz)
    local fz = pz - FEET
    local best, bk = math.huge, nil
    for k = math.max(1, (r.prog or 1) - 1), #r.pts - 1 do
        local a, b = r.pts[k], r.pts[k + 1]
        local vx, vy, vz = b.x - a.x, b.y - a.y, b.z - a.z
        local L2 = vx * vx + vy * vy + vz * vz
        local t = L2 > 0 and math.max(0, math.min(1, ((px - a.x) * vx + (py - a.y) * vy + (fz - a.z) * vz) / L2)) or 0
        local d = (a.x + vx * t - px) ^ 2 + (a.y + vy * t - py) ^ 2 + (2 * (a.z + vz * t - fz)) ^ 2
        if d <= best then best, bk = d, k end              -- ties go to the later bit (you're at its start)
    end
    local now = os.clock()
    if bk and best < 1500 ^ 2 then
        r.prog = bk; r.offAt = nil
    else
        r.offAt = r.offAt or now
        if now - r.offAt > 4 then r.lost = true end           -- off the route (or riding something) for a while
    end
    return r.prog or 1
end
-- a step of the route that is more than walking: up/down (stairs, lift, ladder) or a jump (portal, tram)
local function transitionAt(r, i)
    local a, b = r.pts[i], r.pts[i + 1]
    if not a or not b or not a.id then return nil end
    local dxy = math.sqrt((b.x - a.x) ^ 2 + (b.y - a.y) ^ 2)
    local kind = ROUTE.nodes[a.id][4]
    if dxy > 2000 and (kind == "portal" or kind == "tram") then return "jump" end
    if math.abs(b.z - a.z) > 150 and dxy < 400 then return "vertical" end
    return nil
end
-- the next thing to head for: the next stairs/lift/portal/tram the route uses
-- returns x, y, z, label, use (true = you are standing at it: use it)
local function nextHop(px, py, pz)
    local r = currentRoute()
    if not r or not r.pts or #r.pts < 2 or not ROUTE then return nil end
    local N = ROUTE.nodes
    local k = routeProgress(r, px, py, pz)
    local fz = pz - FEET
    for i = k, #r.pts - 1 do
        local kind = transitionAt(r, i)
        if kind then
            local a = r.pts[i]
            local n = N[a.id]
            local label = n[5]
            local nb = r.pts[i + 1]
            local el = ROUTE.elab and nb.id and ROUTE.elab[a.id .. ":" .. nb.id]
            if el then label = el end
            if kind == "vertical" and not el then
                -- name it by where the flight ends (the start node's own name may be for the other direction)
                local j = i
                while transitionAt(r, j) == "vertical" do j = j + 1 end
                local e = r.pts[j]
                if e.id and N[e.id][5] ~= "" and N[e.id][4] ~= "walk" then label = N[e.id][5] end
                if label == "" or label == "Stairs" then label = (e.z > a.z) and "Stairs up" or "Stairs down" end
            end
            local here = (a.x - px) ^ 2 + (a.y - py) ^ 2 < 350 ^ 2 and math.abs(a.z - fz) < 250
            local ride = n[4] == "portal" or n[4] == "tram" or n[4] == "elevator"
            return a.x, a.y, a.z, label, here and ride
        end
    end
    return nil
end

-- where to point the pin: the next corner ahead of you on the route, so it leads round walls; corners you
-- are standing on (like the spot a flight of stairs is filed under) are skipped so the pin never points back
local function routeAim(px, py, pz)
    local r = route
    if not r or not r.pts or #r.pts < 2 then return nil end
    local j = (r.prog or 1) + 1
    while r.pts[j + 1] and (r.pts[j].x - px) ^ 2 + (r.pts[j].y - py) ^ 2 < 250 ^ 2 and transitionAt(r, j) ~= "jump" do j = j + 1 end
    local p = r.pts[j]
    if not p then return nil end
    return p.x, p.y, p.z
end

local wpFloor = {}      -- vanilla waypoint positions -> floor (cached by markerFloor)
-- quests: quest_data.lua (mkquest.py) holds DT_Quests' start/completion world flags and the quest markers placed
-- in the maps. A step is current when its start flag is set and its completion flag is not (and so is its parent's)
function VISIT.quests()
    if VISIT.qd == nil then
        local ok, d = pcall(dofile, MOD_DIR .. "Scripts/quest_data.lua")
        VISIT.qd = ok and type(d) == "table" and d.quests and d or false
        if not VISIT.qd then log("no quest data: %s", tostring(d)) end
    end
    return VISIT.qd
end
function VISIT.questActive(row)     -- true / false, or nil when unknown (flags not read yet, or a row we don't have)
    local Q = VISIT.quests(); local q = Q and row and Q.quests[row]
    if not q or not VISIT.have then return nil end
    if q.start ~= "" and not VISIT.have[q.start] then return false end
    if q.done ~= "" and VISIT.have[q.done] then return false end
    if q.parent and VISIT.questActive(q.parent) == false then return false end
    return true
end
function VISIT.questItems()
    local Q, items = VISIT.quests(), {}
    for _, m in ipairs(Q and Q.markers or {}) do
        -- a quest with steps of its own: its marker only once those steps are done
        local stepsOpen = false
        for k, q in pairs(Q.quests) do if q.parent == m.quest and VISIT.questActive(k) then stepsOpen = true; break end end
        if not stepsOpen and VISIT.questActive(m.quest) then items[#items + 1] = { loc = { X = m.x, Y = m.y, Z = m.z }, row = m.quest } end
    end
    -- the HUD's own quest waypoints too (some follow a character), unless that step is done or already listed
    for _, it in ipairs(currentWaypoints()) do
        if it.cat == "quests" and VISIT.questActive(it.row) ~= false then
            local dup = false
            -- any placed marker there (current or not) already decides: the HUD widget can name the parent quest
            for _, m in ipairs(Q and Q.markers or {}) do if math.abs(m.x - it.loc.X) + math.abs(m.y - it.loc.Y) < 400 then dup = true end end
            if not dup then items[#items + 1] = { loc = it.loc, row = it.row, label = it.label } end
        end
    end
    for _, it in ipairs(items) do
        local q = Q and it.row and Q.quests[it.row]
        if q and q.text ~= "" then
            local p = q.parent and Q.quests[q.parent]
            it.label = "Quest: " .. q.text .. ((p and p.text ~= "") and ("   (" .. p.text .. ")") or "")
        end
        it.label = it.label or "Quest"
    end
    return items
end

-- ---------------------------------------------------------------- search
function VISIT.setQuery(t)
    VISIT.qtext = t
    local w = {}
    for x in (t or ""):lower():gmatch("%S+") do w[#w + 1] = x end
    VISIT.qw = #w > 0 and w or nil
    if ui then
        for _, e in ipairs(ui.sicons) do e.sstate = nil; e.smatch = nil end
        for _, l in ipairs(ui.links) do l.sstate = nil end
    end
    VISIT.infoText = nil
end
VISIT.SYN = { elevator = "lift", tram = "train station", exit = "door doorway", stairs = "staircase steps", ladder = "climb",
              charge = "charger charging", toilet = "bathroom restroom wc", mapboard = "map board", blastdoor = "blast door security",
              zipline = "zip line cable", portal = "teleporter teleport" }
function VISIT.match(text)                  -- every typed word must appear in the icon's text
    local w = VISIT.qw; if not w then return true end
    local t = (text or ""):lower()
    for _, x in ipairs(w) do if not t:find(x, 1, true) then return false end end
    return true
end
VISIT.DIM = { R = 0.5, G = 0.5, B = 0.5, A = 0.22 }
VISIT.WHITE = { R = 1, G = 1, B = 1, A = 1 }
-- one item drawn this frame: returns the tint to use, and notes a ring when it matches and is on this floor
function VISIT.mark(text, sx, sy, size, here, tint)
    if not VISIT.qw then return tint end
    if VISIT.match(text) then
        VISIT.nAll = VISIT.nAll + 1
        if here then VISIT.nHere = VISIT.nHere + 1; VISIT.rings[#VISIT.rings + 1] = { sx, sy, size } end
        return tint
    end
    return VISIT.DIM
end
-- up/down arrow at the lower right of a match on another floor: which way to scroll
function VISIT.arrow(sx, sy, size, z)
    if not z then return end
    local up = z > viewZ
    placeIcon(poolIcon("custom"), sx + size * 0.45, sy + size * 0.45, math.max(14, size * 0.5),
              loadTex(up and "ic_arrow_up.png" or "ic_arrow_down.png") or loadTex("ui_dot.png"), VISIT.WHITE, nil)
end
function VISIT.searchIcons()               -- area icons (stairs, lifts, portals ...) and passages
    local qw = VISIT.qw
    for _, e in ipairs(ui.sicons) do
        local avail = settings.areaicons and e.under and levelUnlocked(e.under) and (e.world or nil) == viewWorld
        local m = false
        if qw and avail then
            if e.smatch == nil then
                local d = e.def
                local t = VISIT.iconText and VISIT.iconText(d) or ""
                e.smatch = VISIT.match(t .. " " .. (KIND_LABEL[d.kind] or "") .. " " .. d.kind .. " " .. (VISIT.SYN[d.kind] or ""))
            end
            m = e.smatch
            if m then VISIT.nAll = VISIT.nAll + 1 end
            if m and not e.shown then      -- other floor: still shown, bigger, no gold ring
                local sx, sy = toScreen(e.mu, e.mv)
                placeIcon(poolIcon("custom"), sx, sy, ICON * 1.5, loadTex("ic_" .. e.def.kind .. ".png") or loadTex("ui_dot.png"), VISIT.WHITE, nil)
                VISIT.arrow(sx, sy, ICON * 1.5, e.def.z)
            end
        end
        if e.shown then
            local st = (not qw) and 0 or (m and 1 or 2)
            if e.sstate ~= st then
                e.sstate = st
                pcall(function() e.img:SetColorAndOpacity(st == 2 and VISIT.DIM or VISIT.WHITE) end)
            end
            if qw and m then
                VISIT.nHere = VISIT.nHere + 1
                local sx, sy = toScreen(e.mu, e.mv)
                VISIT.rings[#VISIT.rings + 1] = { sx, sy, ICON * 1.9 }
            end
        else e.sstate = nil end
    end
    for _, l in ipairs(ui.links) do
        if l.visible then
            local m = (not qw) or VISIT.match("passage " .. tostring(l.def.a) .. " " .. tostring(l.def.b))
            local st = (not qw) and 0 or (m and 1 or 2)
            if l.sstate ~= st then l.sstate = st; pcall(function() l.img:SetColorAndOpacity(st == 2 and VISIT.DIM or VISIT.WHITE) end) end
        else l.sstate = nil end
    end
end
function VISIT.searchFinish()              -- gold rings + the "n here / m elsewhere" line
    local t = os.clock()
    local pulse = 0.72 + 0.28 * math.sin(t * 4.5)
    for _, r in ipairs(VISIT.rings) do
        local e = poolIcon("custom")
        placeIcon(e, r[1], r[2], math.max(30, r[3]) * 1.5, loadTex("ic_glow.png"), { R = 1, G = 1, B = 1, A = pulse }, nil)
    end
    local info = ""
    if VISIT.qw then
        local els = VISIT.nAll - VISIT.nHere
        if VISIT.nAll == 0 then info = "No icons match"
        else info = string.format("%d on this floor, %d on other floors (Shift+wheel)", VISIT.nHere, els) end
    end
    if info ~= VISIT.infoText then
        VISIT.infoText = info
        pcall(function() ui.searchInfo:SetText(FText(info)) end)
        pcall(function() ui.searchInfo:SetVisibility(info ~= "" and VIS.HitTestInvisible or VIS.Collapsed) end)
    end
end

local function refreshDynamic()
    if not ui then return end
    ui.poolUsed = 0
    VISIT.rings = {}; VISIT.nHere = 0; VISIT.nAll = 0
    VISIT.searchIcons()
    -- labels
    for _, l in pairs(ui.labels) do
        if l.visible then
            local sx, sy = toScreen(l.u, l.v)
            l.slot:SetPosition({ X = sx, Y = sy })
        end
    end
    -- room names (only when zoomed in far enough to read them without clutter)
    local roomsOn = zoom >= 0.3
    for _, r in ipairs(ui.rooms) do
        if r.visible and roomsOn then
            local sx, sy = toScreen(r.u, r.v)
            r.slot:SetPosition({ X = sx, Y = sy })
            if not r.on then r.tb:SetVisibility(VIS.HitTestInvisible); r.on = true end
        elseif r.on or r.on == nil then
            r.tb:SetVisibility(VIS.Collapsed); r.on = false
        end
    end
    -- links between areas
    for _, l in ipairs(ui.links) do
        if l.visible then
            local sx, sy = toScreen(l.u, l.v)
            l.slot:SetPosition({ X = sx, Y = sy })
            l.img:SetVisibility(VIS.HitTestInvisible)
        end
    end
    -- player
    local x, y, z, yaw = playerPos()
    if x then
        local mu, mv = worldToMap(x, y)
        local sx, sy = toScreen(mu, mv)
        ui.playerSlot:SetPosition({ X = sx, Y = sy })
        -- world yaw 0 = +X = map "down" (v grows with X), yaw 90 = +Y = map left (u = 100000 - Y);
        -- UMG angles are clockwise with 0 = up, so the screen angle is yaw + 180
        pcall(function() ui.player:SetRenderTransformAngle(yaw + 180) end)
        ui.player:SetVisibility(VIS.HitTestInvisible)
    end
    -- vanilla waypoints (beacons, benches, quests ...): the HUD's own waypoint widgets
    local hits = {}
    ui.hits = hits
    local wps = {}
    for _, it in ipairs(currentWaypoints()) do if it.cat ~= "quests" then wps[#wps + 1] = it end end
    if settings.quests then
        for _, it in ipairs(VISIT.questItems()) do it.cat = "quests"; it.quest = true; wps[#wps + 1] = it end
    end
    -- Weather Clear buttons (Button_WeatherEnd_C, placed in the levels; which weather from each one's own data)
    for _, b in ipairs(settings.weather and VISIT.weatherButtons or {}) do
        wps[#wps + 1] = { loc = { X = b[1], Y = b[2], Z = b[3] }, cat = "weather", pivot = true,
                          label = "Weather Clear button: clears " .. b[4] }
    end
    for _, it in ipairs(wps) do
        local fk = string.format("%d:%d:%d", it.loc.X // 50, it.loc.Y // 50, it.loc.Z // 50)
        local fm = wpFloor[fk]; if not fm then fm = { x = it.loc.X, y = it.loc.Y, z = it.loc.Z - ((it.pivot or it.quest) and 0 or FEET) }; wpFloor[fk] = fm end
        local here = settings[it.cat] and markerVisible(fm)
        -- your beacons and benches stay findable from any floor: faded and smaller when not on the one shown
        local other = false
        local sm = VISIT.qw and not here and settings[it.cat] and VISIT.match((it.label or "") .. " " .. tostring(it.cat))
        if settings[it.cat] and not here and (it.pivot or it.quest or sm) then
            if fm.world == nil then fm.world = worldAt(fm.x, fm.y, fm.z) or false end
            other = (fm.world or nil) == viewWorld
        end
        if VISIT.qw and not (here or other) and settings[it.cat] and VISIT.match((it.label or "") .. " " .. tostring(it.cat)) then VISIT.nAll = VISIT.nAll + 1 end
        if here or other then
            local mu, mv = worldToMap(it.loc.X, it.loc.Y)
            local sx, sy = toScreen(mu, mv)
            local a = (here or sm) and 1 or 0.45
            local tint = ({ beacons = { R = 1, G = 0.8, B = 0.2, A = a }, benches = { R = 0.4, G = 0.95, B = 0.5, A = a },
                            quests = { R = 0.4, G = 0.8, B = 1, A = a }, others = { R = 1, G = 1, B = 1, A = a },
                            weather = { R = 0.45, G = 0.85, B = 1, A = a } })[it.cat]
            local own = (it.cat == "beacons" and loadTex("ic_beacon.png")) or (it.cat == "benches" and loadTex("ic_bench.png"))
                        or (it.quest and loadTex("ic_quest.png")) or (it.cat == "weather" and loadTex("ic_weather.png")) or nil
            if it.quest then tint = { R = 0.8, G = 0.55, B = 1, A = a } end
            local tex = own or it.tex
            local tnt = (it.tex and not own) and { R = 1, G = 1, B = 1, A = a } or tint
            tnt = VISIT.mark((it.label or "") .. " " .. tostring(it.cat), sx, sy, 22, here, tnt)
            placeIcon(poolIcon("wp"), sx, sy, here and 22 or (sm and 30 or 15), tex or loadTex("ui_dot.png"), tnt, nil)
            if sm then VISIT.arrow(sx, sy, 30, fm.z) end
            hits[#hits + 1] = { x = sx, y = sy, r = 13, text = it.label .. (here and "" or "  (another floor)") .. (it.quest and "   [click: waypoint here]" or ""),
                                quest = it.quest and { x = it.loc.X, y = it.loc.Y, z = fm.z } or nil }
        end
    end
    -- other players
    if settings.others then
        pcall(function()
            local me = getPawn()
            local all = FindAllOf("Abiotic_PlayerCharacter_C") or {}
            for _, p in ipairs(all) do
                if valid(p) and p ~= me then
                    local l = p:K2_GetActorLocation()
                    local mu, mv = worldToMap(l.X, l.Y)
                    local sx, sy = toScreen(mu, mv)
                    local name = nil
                    pcall(function() name = p.PlayerState:GetPlayerName():ToString() end)
                    placeIcon(poolIcon("other"), sx, sy, 16, loadTex("ui_dot.png"), VISIT.mark((name or "") .. " player", sx, sy, 16, true, { R = 0.3, G = 0.7, B = 1, A = 1 }), name)
                    hits[#hits + 1] = { x = sx, y = sy, r = 10, text = name or "Player" }
                end
            end
        end)
    end
    -- custom markers: each one only on the floor (and portal world) it was placed on
    if settings.custom then
        for i, m in ipairs(markers) do
          local mtext = (m.name or ("Marker " .. i)) .. " my marker custom"
          local vis = markerVisible(m)
          if VISIT.qw and not vis and VISIT.match(mtext) then
              VISIT.nAll = VISIT.nAll + 1
              if (worldAt(m.x, m.y, m.z) or nil) == viewWorld then
                  local sx, sy = toScreen(worldToMap(m.x, m.y))
                  placeIcon(poolIcon("custom"), sx, sy - 16, 36, loadTex("ui_pin.png"), { R = 0.95, G = 0.3, B = 0.35, A = 1 }, m.name or ("Marker " .. i))
                  VISIT.arrow(sx + 4, sy - 16, 36, m.z)
              end
          end
          if vis then
            local mu, mv = worldToMap(m.x, m.y)
            local sx, sy = toScreen(mu, mv)
            placeIcon(poolIcon("custom"), sx, sy - 12, 26, loadTex("ui_pin.png"), VISIT.mark(mtext, sx, sy - 12, 26, true, { R = 0.95, G = 0.3, B = 0.35, A = 1 }), m.name or ("Marker " .. i))
            hits[#hits + 1] = { x = sx, y = sy - 12, r = 16, text = (m.name or ("Marker " .. i)) .. "   (right-click: rename, Shift+right-click: delete)", marker = i }
          end
        end
    end
    -- route to the temporary waypoint: dots on the points of the route that are on the floor you are looking at
    if tempWp then
        local r = currentRoute()
        if r and r.path and ROUTE then
            r.vis = r.vis or {}
            local step = 0
            for k, p in ipairs(r.pts or {}) do
                local n = p.id and ROUTE.nodes[p.id]
                local big = n and n[4] ~= "walk"
                if big then step = step + 1 end
                if markerVisible(p) then
                    local sx, sy = toScreen(worldToMap(p.x, p.y))
                    placeIcon(poolIcon("custom"), sx, sy, big and 14 or 7, loadTex("ui_dot.png"), ROUTE_TINT, nil)
                    if big then hits[#hits + 1] = { x = sx, y = sy, r = 9, text = string.format("Route step %d: %s", step, n[5]) } end
                end
            end
        end
    end
    -- temporary waypoint
    if tempWp and markerVisible(tempWp) then
        local sx, sy = toScreen(worldToMap(tempWp.x, tempWp.y))
        placeIcon(poolIcon("custom"), sx, sy - 14, 32, loadTex("ui_pin.png"), WP_TINT, "Waypoint")
        hits[#hits + 1] = { x = sx, y = sy - 14, r = 18, text = "Waypoint: shown on screen while you play, orange dots = route   (Shift+click it to remove)", waypoint = true }
    end
    VISIT.searchFinish()
    hideUnusedIcons()
end

-- ---------------------------------------------------------------- input
local weChangedInput = false
local function setInput(pc, open)
    local wbl = lib(WBL)
    if open then
        -- the cursor may already be up (a game menu): then leave the look/move input alone on close,
        -- but still give the map the mouse, or the first press goes to the game and the drag snaps back
        weChangedInput = not pc.bShowMouseCursor
        log("map input: cursor was %s", tostring(pc.bShowMouseCursor))
        -- focus the map's own click catcher: with focus left on the game viewport, the first press only
        -- captured the mouse for the game (the drag snapped back) and the map saw clicks from the second on
        pcall(function() wbl:SetInputMode_GameAndUIEx(pc, ui.catcher or ui.root, 0, false) end)
        pcall(function() ui.catcher:SetKeyboardFocus() end)
        pc.bShowMouseCursor = true
        if not weChangedInput then return end
        pcall(function() pc:SetIgnoreLookInput(true) end)
        pcall(function() pc:SetIgnoreMoveInput(true) end)
        pcall(function() local p = getPawn(); if p then p:DisableInput(pc) end end)
    elseif weChangedInput then
        weChangedInput = false
        pcall(function() pc:ResetIgnoreLookInput() end)
        pcall(function() pc:ResetIgnoreMoveInput() end)
        pcall(function() local p = getPawn(); if p then p:EnableInput(pc) end end)
        -- if the game opened a menu (pause, inventory...) while the map was up, it owns the
        -- cursor and input mode now: don't take them away from it
        if isPaused() then
            log("game is paused/menu open: leaving input to the game")
            pc.bShowMouseCursor = true
            return
        end
        pcall(function() wbl:SetInputMode_GameOnly(pc, true) end)
        pc.bShowMouseCursor = false
    end
end

local function mousePos()
    local pc = getPC()
    local ok, v = pcall(function() return lib(WLL):GetMousePositionOnViewport(pc) end)
    if ok and v then return v.X, v.Y end
    return nil
end
local function viewportSize()
    local pc = getPC()
    local w, h = 1920, 1080
    pcall(function()
        local s = lib(WLL):GetViewportSize(pc); local sc = lib(WLL):GetViewportScale(pc)
        if s and sc and sc > 0 then w, h = s.X / sc, s.Y / sc end
    end)
    return w, h
end

local function zoomAt(factor, sx, sy)
    local nz = math.max(0.12, math.min(5.0, zoom * factor))
    if not sx then local w, h = viewportSize(); sx, sy = w / 2, h / 2 end
    -- keep the map point under (sx,sy) fixed
    local mu, mv = (sx - panX) / zoom, (sy - panY) / zoom
    zoom = nz
    panX, panY = sx - mu * zoom, sy - mv * zoom
    applyTransform()
end

local function centerOnPlayer()
    local x, y = playerPos()
    if not x then return end
    local mu, mv = worldToMap(x, y)
    local w, h = viewportSize()
    panX, panY = w / 2 - mu * zoom, h / 2 - mv * zoom
    applyTransform()
end

local drag = nil
local gamePress, refocusN, refocusAt = false, 0, -10
local PAN_RAW = 1 / 0.07   -- screen pixels per MouseX/MouseY axis unit: UE scales raw counts by its default mouse axis sensitivity 0.07
local press = nil         -- where/when the left button went down (click vs drag)
local dbgLmb = false
local frameErrors = 0
local frameCount = { hook = 0, timer = 0 }
-- mouse presses seen by UE4SS's own key reader (works even when the game's PlayerInput
-- doesn't get the click); a press seen by both paths only counts once
local clickAt = { rmb = -1, mmb = -1 }
local clickPending = { rmb = false, mmb = false }
local function takeClick(b)
    if clickPending[b] then clickPending[b] = false; return true end
    return false
end
local function noteClick(b, viaGame)
    local now = os.clock()
    if now - clickAt[b] < 0.25 then return false end
    clickAt[b] = now
    if not viaGame then clickPending[b] = true end
    return true
end
local rmbWasDown = false
local rmbPending = nil
local rmbShiftAt = -1
local lmbShiftAt = -1
local mmbWasDown = false

-- ---------------------------------------------------------------- hover tooltip
local editing = nil       -- { index = n, isNew = bool, opened = os.clock() } while the name box is up
-- where an icon leads, seen from the floor the map is showing
local function stairsEnds(d)
    local up, down = nil, nil
    for _, t in ipairs(d.dests or {}) do
        if t.up and t.z > viewZ + 100 then up = t end
        if t.down and t.z < viewZ - 100 then down = t end
    end
    return up, down
end
local function otherStops(d)
    local out = {}
    for _, t in ipairs(d.dests or {}) do
        if not (d.kind == "elevator" and math.abs(t.z - viewZ) < 120) then out[#out + 1] = t end
    end
    return out
end
local function joinNames(list, maxn)
    local names = {}
    for i, t in ipairs(list) do
        if i > (maxn or 4) then names[#names + 1] = "..."; break end
        names[#names + 1] = t.name
    end
    return table.concat(names, ", ")
end
local function iconLabel(d)
    local base = d.label or KIND_LABEL[d.kind] or d.kind
    local canGo = false
    if d.kind == "stairs" then
        local up, down = stairsEnds(d)
        if up and down then base = "Stairs up to " .. up.name .. ", down to " .. down.name
        elseif up then base = "Stairs up to " .. up.name
        elseif down then base = "Stairs down to " .. down.name
        else
            local u = d.zhi > viewZ + 150; local dn = d.zlo < viewZ - 150
            base = "Stairs" .. ((u and dn) and " (up and down)" or (u and " up" or (dn and " down" or "")))
        end
        canGo = (up or down or (d.dests and d.dests[1])) ~= nil
        if d.door then base = d.door .. "  -  " .. base end
    elseif d.kind == "elevator" then
        local stops = otherStops(d)
        if #stops > 0 then base = "Elevator to " .. joinNames(stops); canGo = true end
        if d.door then base = d.door .. "  -  " .. base end
    elseif d.kind == "tram" and d.dests then
        base = base .. "  -  to " .. joinNames(d.dests); canGo = true
    elseif d.dests and d.dests[1] then
        if d.door then base = d.door .. "  (" .. base .. ")" end
        if d.kind == "exit" or d.kind == "ladder" then base = base .. "  -  " .. d.dests[1].name end
        canGo = not d.dests[1].off
        if d.dests[1].off then base = base .. "  (not on this map)" end
    elseif d.door then
        base = d.door .. "  (" .. base .. ")"
    end
    if canGo then base = base .. "   [click to go there]" end
    return base
end
VISIT.iconText = function(d) return (iconLabel(d):gsub("%s+%[click to go there%]", "")) end
local function linkTarget(l)
    local other = (hereLevel == l.b) and l.a or l.b
    return other
end
local function linkLabel(l)
    local na = DATA.levels[l.a] and DATA.levels[l.a].name or l.a
    local nb = DATA.levels[l.b] and DATA.levels[l.b].name or l.b
    if hereLevel == l.a then return "Passage to " .. nb .. "   [click to go there]" end
    if hereLevel == l.b then return "Passage to " .. na .. "   [click to go there]" end
    return "Passage: " .. na .. "  /  " .. nb .. "   [click to go there]"
end
-- what is under the mouse: a text (markers, waypoints) or { icon = e } / { link = l }
local function hoverItem(mx, my)
    local best, bd = nil, nil
    local function try(sx, sy, r, item)
        local dx, dy = sx - mx, sy - my
        local d2 = dx * dx + dy * dy
        if d2 <= r * r and (not bd or d2 < bd) then best, bd = item, d2 end
    end
    for _, h in ipairs(ui.hits) do try(h.x, h.y, h.r, h.text) end
    local r = ICON * 0.5 + 3
    for _, e in ipairs(ui.sicons) do
        if e.shown then
            local sx, sy = toScreen(e.mu, e.mv)
            if math.abs(sx - mx) <= r and math.abs(sy - my) <= r then try(sx, sy, r, { icon = e }) end
        end
    end
    for _, l in ipairs(ui.links) do
        if l.visible then local sx, sy = toScreen(l.u, l.v); try(sx, sy, 12, { link = l }) end
    end
    return best
end
local function hoverText(mx, my)
    local it = hoverItem(mx, my)
    if type(it) == "table" then
        if it.icon then return iconLabel(it.icon.def) end
        return linkLabel(it.link.def)
    end
    return it
end

-- clicking something that leads elsewhere moves the map there (and to that floor)
-- smooth move: the map glides (and zooms in a little if far out) to centre on the target, then shows
-- the floor it leads to; the icon you arrive at is named for a moment
local anim = nil
local arrival = nil       -- { mu, mv, untilT }
local function jumpTo(x, y, z, why)
    viewMode = "manual"
    local mu, mv = worldToMap(x, y)
    local w, h = viewportSize()
    local tz = math.max(zoom, 0.8)
    local wnew = worldAt(x, y, z)
    local cross = wnew ~= viewWorld
    viewWorld = wnew
    if cross then
        -- into or out of a portal world: no glide across the empty space between them, just cut there
        zoom = math.max(zoom, 0.5)
        panX, panY = w / 2 - mu * zoom, h / 2 - mv * zoom
        applyTransform()
    end
    anim = { t0 = os.clock(), dur = cross and 0.25 or 0.45, z0 = zoom, z1 = tz, mu = mu, mv = mv,
             c0u = (w / 2 - panX) / zoom, c0v = (h / 2 - panY) / zoom, floorZ = z }
    applyView(z)                                   -- switch floors right away so the glide shows the new floor
    arrival = { mu = mu, mv = mv, untilT = os.clock() + 3.0 }
    log("jump: %s -> %.0f %.0f z%.0f", why or "?", x, y, z)
end
local function stepAnim()
    if not anim then return end
    local t = math.min(1, (os.clock() - anim.t0) / anim.dur)
    local e = t < 0.5 and 2 * t * t or 1 - (-2 * t + 2) ^ 2 / 2      -- ease in-out
    local w, h = viewportSize()
    zoom = anim.z0 + (anim.z1 - anim.z0) * e
    local cu = anim.c0u + (anim.mu - anim.c0u) * e
    local cv = anim.c0v + (anim.mv - anim.c0v) * e
    panX, panY = w / 2 - cu * zoom, h / 2 - cv * zoom
    applyTransform()
    if t >= 1 then
        local z = anim.floorZ; anim = nil
        applyView(z)                               -- names the area now in the middle of the screen
    end
end
local function clickAt(mx, my)
    local it = hoverItem(mx, my)
    if type(it) ~= "table" then return false end
    if it.link then
        local other = linkTarget(it.link.def)
        local lv = DATA.levels[other]
        if not lv then return false end
        -- the other area's floor nearest the passage, centred on the passage itself
        local best = nil
        for _, st in ipairs(lv.storeys or {}) do
            if not best or math.abs(st.z - it.link.def.z) < math.abs(best.z - it.link.def.z) then best = st end
        end
        local x, y = mapToWorld(it.link.u, it.link.v)
        hereLevel = other
        jumpTo(x, y, best and best.z or it.link.def.z, "passage to " .. other)
        return true
    end
    local e = it.icon; local d = e.def
    local target = nil
    if d.kind == "stairs" then
        local up, down = stairsEnds(d)
        target = up or down or (d.dests and d.dests[1])
    elseif d.kind == "elevator" or d.kind == "tram" then
        local stops = (d.kind == "elevator") and otherStops(d) or (d.dests or {})
        if #stops > 0 then
            e.next = ((e.next or 0) % #stops) + 1          -- click again for the next stop
            target = stops[e.next]
        end
    elseif d.dests and d.dests[1] and not d.dests[1].off then
        target = d.dests[1]
    end
    if not target or target.off then return false end
    jumpTo(target.x, target.y, target.z, (d.label or d.kind) .. " -> " .. target.name)
    return true
end
local function updateTip(mx, my)
    local text = (mx and not drag and not editing) and hoverText(mx, my) or nil
    if not text and arrival and not anim then
        if os.clock() < arrival.untilT then
            local sx, sy = toScreen(arrival.mu, arrival.mv)
            text = hoverText(sx, sy)
            if text then text = "You arrive at: " .. text:gsub("%s+%[click to go there%]", ""); mx, my = sx, sy end
        else
            arrival = nil
        end
    end
    if not text then
        if ui.tipShown then ui.tip:SetVisibility(VIS.Collapsed); ui.tipShown = nil end
        return
    end
    if text ~= ui.tipShown then
        ui.tipText:SetText(FText(text)); ui.tipShown = text
        ui.tip:SetVisibility(VIS.HitTestInvisible)
    end
    local w = viewportSize()
    local tw = #text * 14 * 0.62 + 20
    pcall(function() local ds = ui.tip:GetDesiredSize(); if ds and ds.X > 0 then tw = ds.X * 0.62 end end)
    local x = mx + 16
    if x + tw > w - 8 then x = mx - 12 - tw end
    ui.tipSlot:SetPosition({ X = x, Y = my + 14 })
end

-- ---------------------------------------------------------------- marker names
local function openEditor(i, isNew)
    local m = markers[i]; if not m then return end
    editing = { index = i, isNew = isNew, opened = os.clock() }
    local sx, sy = toScreen(worldToMap(m.x, m.y))
    local w, h = viewportSize()
    ui.editorSlot:SetPosition({ X = math.max(8, math.min(sx + 18, w - 300)), Y = math.max(8, math.min(sy - 20, h - 90)) })
    pcall(function() ui.editTitle:SetText(FText(isNew and "Name this marker" or "Rename marker")) end)
    pcall(function() ui.editBox:SetText(FText(m.name or "")) end)
    ui.editor:SetVisibility(VIS.Visible)
    pcall(function() ui.editBox:SetKeyboardFocus() end)
    log("marker %d: naming (%s)", i, isNew and "new" or "rename")
end
local function closeEditor(save)
    if not editing then return end
    local e = editing; editing = nil
    local text = nil
    pcall(function() text = ui.editBox:GetText():ToString() end)
    if ui then pcall(function() ui.editor:SetVisibility(VIS.Collapsed) end) end
    if save then
        text = text and text:gsub("[\r\n]", " "):gsub("^%s+", ""):gsub("%s+$", "") or ""
        if markers[e.index] then markers[e.index].name = text ~= "" and text or nil end
    elseif e.isNew then
        table.remove(markers, e.index)      -- cancelled before naming: don't leave a stray pin
    end
    saveMarkers()
    log("marker %s (%d total)", save and "saved" or "cancelled", #markers)
    -- give keyboard focus back to the map so the game doesn't take the next key
    pcall(function() lib(WBL):SetInputMode_GameAndUIEx(getPC(), ui.catcher or ui.root, 0, false) end)
    pcall(function() ui.catcher:SetKeyboardFocus() end)
end

local function onFrame()
    if not mapOpen or not ui then return end
    local pc = getPC(); if not valid(pc) then return end
    local mx, my = mousePos()
    pcall(function()
        local t = ui.searchBox:GetText():ToString()
        if t ~= (VISIT.qtext or "") then VISIT.setQuery(t) end
        VISIT.typing = ui.searchBox:HasKeyboardFocus() and true or false
        VISIT.overSearch = ui.searchPanel:IsHovered() and true or false
    end)
    -- zoom with the wheel
    local up, down = false, false
    pcall(function() up = pc:WasInputKeyJustPressed(key("MouseScrollUp")) end)
    pcall(function() down = pc:WasInputKeyJustPressed(key("MouseScrollDown")) end)
    local shift = false
    pcall(function() shift = pc:IsInputKeyDown(key("LeftShift")) or pc:IsInputKeyDown(key("RightShift")) end)
    if up or down then anim = nil end
    if shift and (up or down) then
        -- Shift + wheel: next floor up / down among the areas around the middle of the screen
        viewMode = "manual"
        local w, h = viewportSize()
        local cu, cv = (w / 2 - panX) / zoom * BASE, (h / 2 - panY) / zoom * BASE
        local best = nil
        -- only real floors (tiles_data.lua: minor = no walkable floor connected to the rest of the facility) of the
        -- areas under the middle of the screen
        for _, t in ipairs(DATA.tiles) do
            if not t.minor and inView(t.level) and cu >= t.u - 500 and cu <= t.u + t.w + 500 and cv >= t.v - 500 and cv <= t.v + t.h + 500 then
                if up and t.z > viewZ + 60 and (not best or t.z < best) then best = t.z end
                if down and t.z < viewZ - 60 and (not best or t.z > best) then best = t.z end
            end
        end
        applyView(best or (viewZ + (up and 400 or -400)))
    elseif up then zoomAt(1.2, mx, my) elseif down then zoomAt(1 / 1.2, mx, my) end
    -- W/A/S/D: pan (diagonals too), same speed at any frame rate
    local now = os.clock()
    pcall(function() local t = lib(GPS):GetRealTimeSeconds(pc); if type(t) == "number" then now = t end end)
    local dt = math.min(0.05, math.max(0, now - (lastPanT or now))); lastPanT = now
    if not editing and not VISIT.typing then
        local kx, ky = 0, 0
        pcall(function()
            if pc:IsInputKeyDown(key("W")) then ky = ky + 1 end
            if pc:IsInputKeyDown(key("S")) then ky = ky - 1 end
            if pc:IsInputKeyDown(key("A")) then kx = kx + 1 end
            if pc:IsInputKeyDown(key("D")) then kx = kx - 1 end
        end)
        if kx ~= 0 or ky ~= 0 then
            local n = math.sqrt(kx * kx + ky * ky)
            local speed = 900                                  -- screen pixels per second
            panX = panX + kx / n * speed * dt; panY = panY + ky / n * speed * dt
            anim = nil
            applyTransform()
        end
    end
    -- middle click: follow and centre on the player again
    local mmb = false
    pcall(function() mmb = pc:IsInputKeyDown(key("MiddleMouseButton")) end)
    local mmbEdge = mmb and not mmbWasDown and noteClick("mmb", true)
    if takeClick("mmb") or mmbEdge then
        viewMode = "auto"
        local x, y, z = playerPos(); if x then applyView(z - FEET) end
        centerOnPlayer()
    end
    mmbWasDown = mmb
    -- the map widget is only in the tree from the frame after opening: focus it again then, or the first press
    -- goes to the game viewport (which captures and re-centres the mouse, so the drag snaps back)
    if os.clock() - refocusAt < 0.5 and refocusN < 3 then
        refocusN = refocusN + 1
        pcall(function() lib(WBL):SetInputMode_GameAndUIEx(pc, ui.catcher or ui.root, 0, false) end)
        pcall(function() ui.catcher:SetKeyboardFocus() end)
    end
    -- drag to pan
    local lmb = false
    pcall(function() lmb = ui.catcher:IsPressed() end)
    if not lmb then pcall(function() lmb = pc:IsInputKeyDown(key("LeftMouseButton")) end) end
    if lmb ~= dbgLmb then
        dbgLmb = lmb
        local viaButton = false; pcall(function() viaButton = ui.catcher:IsPressed() end)
        if lmb and not viaButton and not VISIT.overSearch then
            -- the game viewport took this press (and the mouse with it): give focus back to the map
            pcall(function() lib(WBL):SetInputMode_GameAndUIEx(pc, ui.catcher or ui.root, 0, false) end)
            pcall(function() ui.catcher:SetKeyboardFocus() end)
            pcall(function() pc:FlushPressedKeys() end)          -- else the game never sees this press end
            log("press went to the game: gave the mouse back to the map")
            gamePress = true            -- the game holds the mouse until release (it re-centres it): don't pan with it
        end
        local pi = false; pcall(function() pi = pc:IsInputKeyDown(key("LeftMouseButton")) end)
        local cp = "?"; pcall(function() cp = tostring(ui.catcher:IsPressed()) end)
        log("LMB %s at %s,%s (button=%s playerinput=%s) frames hook=%d timer=%d", lmb and "down" or "up",
            tostring(mx), tostring(my), cp, tostring(pi), frameCount.hook, frameCount.timer)
    end
    if not lmb and gamePress and VISIT.rawSum then log("game-held press: raw mouse movement %.0f, panned by it", VISIT.rawSum); VISIT.rawSum = nil end
    if not lmb then gamePress = false end
    if lmb and mx and not editing and not VISIT.overSearch then
        anim = nil
        if press and shift then press.shift = true end
        if drag then
            if not gamePress then panX = panX + (mx - drag.x); panY = panY + (my - drag.y); applyTransform()
            else
                -- the game holds the cursor for this press (Slate high-precision capture: the cursor is frozen and put
                -- back on release), but the raw movement still reaches the player input as the MouseX/MouseY axes
                local dx, dy = 0, 0
                pcall(function() dx = pc:GetInputAnalogKeyState(key("MouseX")) or 0 end)
                pcall(function() dy = pc:GetInputAnalogKeyState(key("MouseY")) or 0 end)
                dx, dy = tonumber(dx) or 0, tonumber(dy) or 0
                VISIT.rawSum = (VISIT.rawSum or 0) + math.abs(dx) + math.abs(dy)
                if VISIT.rawSum > 6 and press then press.moved = true end     -- the frozen cursor can't tell a drag from a click
                if dx ~= 0 or dy ~= 0 then panX = panX + dx * PAN_RAW; panY = panY - dy * PAN_RAW; applyTransform() end
            end
            if math.abs(mx - press.x) + math.abs(my - press.y) > 6 then press.moved = true end
        else
            press = { x = mx, y = my, t = os.clock(), moved = false, shift = shift }
        end
        drag = { x = mx, y = my }
    else
        -- a short press that didn't move is a click: follow stairs, lifts, portals, trams, doorways
        if drag and press and not press.moved and os.clock() - press.t < 0.6 then
            if press.shift or shift or os.clock() - lmbShiftAt < 0.8 then
                -- Shift+click: set the temporary waypoint here (or remove it when clicking on it)
                local onIt = false
                for _, h in ipairs(ui.hits or {}) do
                    if h.waypoint and (h.x - press.x) ^ 2 + (h.y - press.y) ^ 2 <= 22 * 22 then onIt = true end
                end
                if onIt then
                    tempWp = nil; log("waypoint removed")
                else
                    local wx, wy = mapToWorld((press.x - panX) / zoom, (press.y - panY) / zoom)
                    tempWp = { x = wx, y = wy, z = viewZ }
                    log("waypoint set at %.0f %.0f z%.0f", wx, wy, viewZ)
                end
                lmbShiftAt = -1
            else
                local q = nil       -- a quest icon: the waypoint goes exactly on the quest
                for _, h in ipairs(ui.hits or {}) do
                    if h.quest and (h.x - press.x) ^ 2 + (h.y - press.y) ^ 2 <= h.r * h.r then q = h.quest end
                end
                if q then
                    tempWp = { x = q.x, y = q.y, z = q.z }
                    log("waypoint set on quest at %.0f %.0f z%.0f", q.x, q.y, q.z)
                else
                local ok, err = pcall(clickAt, press.x, press.y)
                if not ok then log("click failed: %s", tostring(err)) end
                end
            end
        end
        drag = nil
    end
    -- right-click: add a marker and name it; on a marker: rename it (Shift: delete it)
    local rmb = false
    pcall(function() rmb = pc:IsInputKeyDown(key("RightMouseButton")) end)
    local rmbEdge = rmb and not rmbWasDown and noteClick("rmb", true)
    if (takeClick("rmb") or rmbEdge) and mx and not rmbPending then
        rmbPending = { x = mx, y = my, t = os.clock(), shift = shift }
    end
    if rmb and rmbPending and shift then rmbPending.shift = true end
    -- act on release (or shortly after the press if the game never saw it), so Shift is always known
    if rmbPending and not rmb and os.clock() - rmbPending.t > 0.05 then
        local p = rmbPending; rmbPending = nil
        local mx, my = p.x, p.y
        local shift = p.shift or shift or (os.clock() - rmbShiftAt < 0.8)
        if editing then
            closeEditor(true)               -- right-click elsewhere while naming: keep what was typed
        else
            local hit, hd = nil, nil
            for _, h in ipairs(ui.hits or {}) do
                if h.marker then
                    local dx, dy = h.x - mx, h.y - my
                    local d = dx * dx + dy * dy
                    if d <= 20 * 20 and (not hd or d < hd) then hit, hd = h.marker, d end
                end
            end
            if hit and shift then
                table.remove(markers, hit)
                saveMarkers(); log("marker removed (%d total)", #markers)
            elseif hit then
                openEditor(hit, false)
            else
                local wx, wy = mapToWorld((mx - panX) / zoom, (my - panY) / zoom)
                table.insert(markers, { x = wx, y = wy, z = viewZ })
                settings.custom = true
                pcall(function() ui.checks.custom:SetIsChecked(true) end)
                openEditor(#markers, true)
            end
        end
    end
    rmbWasDown = rmb
    -- follow the player's floor
    if viewMode == "auto" then
        local x, y, z = playerPos()
        if x and (not shownZ or math.abs((z - FEET) - shownZ) > 30) then applyView(z - FEET) end
    end
    -- toggles
    for k, cb in pairs(ui.checks) do
        local ok, on = pcall(function() return cb:IsChecked() end)
        if ok and type(on) == "boolean" and on ~= settings[k] then
            settings[k] = on
            if k == "labels" or k == "areaicons" or k == "rooms" then applyView(shownZ or viewZ) end
        end
    end
    stepAnim()
    refreshDynamic()
    updateTip(mx, my)
    if shotAt and os.clock() >= shotAt then
        shotAt = nil
        pcall(function()
            StaticFindObject("/Script/Engine.Default__KismetSystemLibrary"):ExecuteConsoleCommand(pc, "shot showui", pc)
        end)
    end
end

local function safeFrame(src)
    frameCount[src] = frameCount[src] + 1
    local ok, err = pcall(onFrame)
    if not ok and frameErrors < 5 then frameErrors = frameErrors + 1; log("frame error (%s): %s", src, tostring(err)) end
end
-- ---------------------------------------------------------------- on-screen waypoint (map closed)
local function buildHud()
    local gi = FindFirstOf("GameInstance")
    local root = StaticConstructObject(cls("/Script/UMG.UserWidget"), gi, FName(nextName("RootHud")), 0, ROOTSET)
    root.WidgetTree = construct("/Script/UMG.WidgetTree", root, "HudTree")
    local tree = root.WidgetTree
    local canvas = construct("/Script/UMG.CanvasPanel", tree, "HudCanvas")
    tree.RootWidget = canvas
    local img = makeImage(tree, "ui_pin.png", WP_TINT)
    local s = canvas:AddChildToCanvas(img)
    s:SetSize({ X = 30, Y = 30 }); s:SetAlignment({ X = 0.5, Y = 1 })
    local tb = makeText(tree, "", 0.7)
    local ts = canvas:AddChildToCanvas(tb)
    ts:SetAutoSize(true); ts:SetAlignment({ X = 0.5, Y = 0 })
    root:SetVisibility(VIS.HitTestInvisible)
    root:AddToViewport(5)
    return { root = root, img = img, slot = s, tb = tb, tslot = ts, shown = true, text = nil }
end
local function hideHud()
    if hud and hud.shown then pcall(function() hud.root:SetVisibility(VIS.Collapsed) end); hud.shown = false end
end
local hudFailed = false
-- world point -> HUD position (DPI-scaled units). Tries the widget-layout call, then the player controller's own
-- (pixels / viewport scale); UE4SS may hand out-params back by name or flattened, so both shapes are read
local projLogged = false
local function vec2(o, name)
    local v = o[name]
    if v and v.X then return v.X, v.Y end
    if o.X then return o.X, o.Y end
end
local function projectToScreen(pc, loc)
    local out, on, a, b = {}, false, nil, nil
    local ok1, e1 = pcall(function() on = lib(WLL):ProjectWorldLocationToWidgetPosition(pc, loc, out, false) end)
    if ok1 then a, b = vec2(out, "ScreenPosition") end
    if a and on then return a, b, true end
    local out2, on2 = {}, false
    local ok2, e2 = pcall(function() on2 = pc:ProjectWorldLocationToScreen(loc, out2, false) end)
    local c, d = nil, nil
    if ok2 then c, d = vec2(out2, "ScreenLocation") end
    if not projLogged then
        projLogged = true
        local keys = {}
        for k in pairs(out) do keys[#keys + 1] = tostring(k) end
        for k in pairs(out2) do keys[#keys + 1] = "2:" .. tostring(k) end
        log("projection: widget ok=%s on=%s xy=%s | controller ok=%s on=%s xy=%s | keys %s | %s %s", tostring(ok1), tostring(on),
            tostring(a), tostring(ok2), tostring(on2), tostring(c), table.concat(keys, ","), tostring(e1), tostring(e2))
    end
    if c and on2 then
        local sc = 1; pcall(function() sc = lib(WLL):GetViewportScale(pc) end)
        if type(sc) ~= "number" or sc <= 0 then sc = 1 end
        return c / sc, d / sc, true
    end
    return nil, nil, false
end
-- the game's navmesh (what the creatures walk on): a path to the next step that goes through real doorways
local NAVSYS = nil
local nav = { at = -10 }
local navLogged = 0
local function navAim(px, py, pz, gx, gy, gz)
    local now = os.clock()
    if not (now - nav.at < 0.5 and nav.gx == gx and nav.gy == gy) then
        local old = nav
        nav = { at = now, gx = gx, gy = gy }
        if NAVSYS == nil then
            NAVSYS = StaticFindObject("/Script/NavigationSystem.Default__NavigationSystemV1")
            if not valid(NAVSYS) then NAVSYS = false; log("navmesh: no navigation system") end
        end
        if not NAVSYS then return nil end
        local pawn = getPawn()
        local ok, err = pcall(function()
            local path = NAVSYS:FindPathToLocationSynchronously(pawn, { X = px, Y = py, Z = pz }, { X = gx, Y = gy, Z = gz }, pawn, nil)
            if not valid(path) then if navLogged < 5 then navLogged = navLogged + 1; log("navmesh: no path object") end return end
            local pts = {}
            path.PathPoints:ForEach(function(_, e) local v = e:get(); pts[#pts + 1] = { x = v.X, y = v.Y, z = v.Z } end)
            local partial = false
            pcall(function() partial = path:IsPartial() end)
            if navLogged < 5 then navLogged = navLogged + 1; local e = pts[#pts]; log("navmesh path: %d points%s, ends %.0f from target", #pts, partial and " (partial)" or "", e and math.sqrt((e.x - gx) ^ 2 + (e.y - gy) ^ 2) or -1) end
            local e = pts[#pts]
            if #pts >= 2 and (not partial or ((e.x - gx) ^ 2 + (e.y - gy) ^ 2 < 600 ^ 2 and math.abs(e.z - gz) < 300)) then nav.pts = pts end
        end)
        if nav.pts then nav.okAt = now
        elseif old.pts and old.gx == gx and old.gy == gy and now - (old.okAt or 0) < 2 then nav.pts, nav.okAt = old.pts, old.okAt end   -- one miss doesn't flip the pin
        if not ok and navLogged < 5 then navLogged = navLogged + 1; log("navmesh failed: %s", tostring(err)) end
    end
    local pts = nav.pts
    if not pts then return nil end
    for i = 2, #pts do
        local p = pts[i]
        if (p.x - px) ^ 2 + (p.y - py) ^ 2 > 150 ^ 2 or i == #pts then return p.x, p.y, p.z end
    end
end

local lastHopLabel = nil
local function hudTick()
    if not tempWp or mapOpen or hudFailed then hideHud(); return end
    if isPaused() then hideHud(); return end
    local pc = getPC(); if not valid(pc) then return end
    local px, py, pz = playerPos(); if not px then return end
    local tz = tempWp.z + FEET
    local dx, dy, dz = tempWp.x - px, tempWp.y - py, tz - pz
    local flat = math.sqrt(dx * dx + dy * dy)
    if flat < 250 and math.abs(dz) < 300 then
        tempWp = nil; hideHud(); log("waypoint reached"); return
    end
    if not hud then
        local ok, res = pcall(buildHud)
        if not ok then hudFailed = true; log("waypoint widget failed: %s", tostring(res)); return end
        hud = res
        log("waypoint marker on screen (%d m away)", math.floor(math.sqrt(flat * flat + dz * dz) / 100 + 0.5))
    end
    local w, h = viewportSize()
    -- on another floor or in another world: aim at the next step of the route instead
    local total = flat
    local hx, hy, hz, hlabel, huse = nil, nil, nil, nil, nil
    local okh, errh = pcall(function() hx, hy, hz, hlabel, huse = nextHop(px, py, pz) end)
    if not okh and not routeErrLogged then routeErrLogged = true; log("route: %s", tostring(errh)) end
    if okh and hlabel ~= lastHopLabel then
        lastHopLabel = hlabel
        log("next step: %s%s (you at %.0f %.0f %.0f)", huse and "use " or "", tostring(hlabel), px, py, pz)
    end
    if route and route.len and route.len < math.huge then total = route.len end
    local tx, ty = tempWp.x, tempWp.y
    if okh and hx then
        tx, ty, tz = hx, hy, hz + FEET
        dx, dy, dz = tx - px, ty - py, tz - pz
        flat = math.sqrt(dx * dx + dy * dy)
    end
    -- the pin follows the corridors (corners of the route); the text still names the next step
    if not huse then
        local okA, ax, ay, az = pcall(routeAim, px, py, pz)
        if okA and ax then tx, ty, tz = ax, ay, az + FEET end
        -- nearby, on the same floor: the game's own navmesh knows the doors exactly. Aim it at the next corner of
        -- the route when that is on your floor: the leg from you to the route is a straight guess through walls
        local gx, gy, gz = tempWp.x, tempWp.y, tempWp.z
        if hx then gx, gy, gz = hx, hy, hz end
        if okA and ax and math.abs(az - (pz - FEET)) < 250 then gx, gy, gz = ax, ay, az end
        local dd = (gx - px) ^ 2 + (gy - py) ^ 2
        if dd < 8000 ^ 2 and dd > 400 ^ 2 and math.abs(gz - (pz - FEET)) < 400 then    -- at the step itself the route's own points lead on
            local okN, nx, ny, nz = pcall(navAim, px, py, pz, gx, gy, gz + 50)
            if okN and nx then tx, ty, tz = nx, ny, nz + FEET - 40 end
        end
    end
    local tint = hx and ROUTE_TINT or WP_TINT
    if hud.tint ~= tint then pcall(function() hud.img:SetColorAndOpacity(tint) end); hud.tint = tint end
    local loc = { X = tx, Y = ty, Z = tz + 40 }
    local sx, sy, on = projectToScreen(pc, loc)
    if not on then sx = nil end
    local M = 40
    if not sx then
        -- behind the camera: stick to the left or right edge, whichever way you need to turn
        local yaw = 0; pcall(function() yaw = pc:GetControlRotation().Yaw end)
        local a = math.deg(math.atan(ty - py, tx - px)) - yaw
        a = (a + 540) % 360 - 180
        sx, sy = (a < 0) and M or (w - M), h / 2
    else
        sx = math.max(M, math.min(w - M, sx)); sy = math.max(M + 30, math.min(h - M - 20, sy))
    end
    hud.slot:SetPosition({ X = sx, Y = sy }); hud.tslot:SetPosition({ X = sx, Y = sy + 2 })
    local d3 = math.sqrt(flat * flat + dz * dz)
    local text = string.format("%d m", math.floor(d3 / 100 + 0.5))
    if dz > 250 then text = text .. " (above)" elseif dz < -250 then text = text .. " (below)" end
    if hx then
        text = string.format("%s%s  %s\nwaypoint: about %d m by this route", huse and "Use: " or "", hlabel or "Next step", text,
                             math.floor(total / 100 + 0.5))
    end
    if text ~= hud.text then pcall(function() hud.tb:SetText(FText(text)) end); hud.text = text end
    if not hud.shown then pcall(function() hud.root:SetVisibility(VIS.HitTestInvisible) end); hud.shown = true end
end
local hudErrors = 0

-- per-frame callback: the waypoint manager component ticks every frame on the local controller
local frameHooked = false
local hudHooked = false
local lastHudTick = 0
local hudSlow, hudFallbackLogged = 0, false
local retired = false
local lastHookTick = 0
local function retiredCheck()
    if retired then return true end
    -- UE4SS keeps these hooks after a hot reload: once a newer copy has taken over, this one goes quiet
    for _, r in pairs({ ui and ui.root or false, hud and hud.root or false }) do
        if r then
            local op = nil
            pcall(function() op = r:GetRenderOpacity() end)
            if not valid(r) or (type(op) == "number" and math.abs(op - RETIRED) < 1e-4) then
                retired = true; mapOpen = false; tempWp = nil; ui = nil; hud = nil
                return true
            end
        end
    end
    return false
end
local function hookFrame()
    if frameHooked then return end
    local ok, err = pcall(function()
        RegisterHook("/Game/Blueprints/Meta/PlayerController_WaypointManagerComponent.PlayerController_WaypointManagerComponent_C:ReceiveTick",
            function()
                if retiredCheck() then return end
                lastHookTick = os.clock(); safeFrame("hook")
            end)
    end)
    frameHooked = ok
    if not ok then log("frame hook failed (%s); using a timer instead", tostring(err)) end
    -- the on-screen waypoint runs off the player character's tick: the waypoint manager above switches its
    -- own tick off and on (SetComponentTickEnabled), so it is not a reliable clock once the map is closed
    if not hudHooked then
        local ok2, err2 = pcall(function()
            RegisterHook("/Game/Blueprints/Characters/Abiotic_PlayerCharacter.Abiotic_PlayerCharacter_C:ReceiveTick",
                function(ctx)
                    if retired or not tempWp then if hud and hud.shown then pcall(hideHud) end; return end
                    -- every player character ticks (co-op): only act for our own
                    local mine = true
                    pcall(function()
                        local p = getPawn()
                        mine = p ~= nil and ctx:get():GetAddress() == p:GetAddress()
                    end)
                    if not mine then return end
                    if retiredCheck() then return end
                    lastHudTick = os.clock()
                    local ok3, e3 = pcall(hudTick)
                    if not ok3 and hudErrors < 5 then hudErrors = hudErrors + 1; log("waypoint error: %s", tostring(e3)) end
                end)
        end)
        hudHooked = ok2
        if not ok2 then log("waypoint hook failed: %s", tostring(err2)) end
    end
end
-- first visits unlock the areas that have no map board (checked about once a second, map open or not)
-- The visited list is kept per world (visited_<world>.txt): places you have walked into since this version, plus
-- places the world's story flags prove you have been: many areas set a flag the first time you walk in
-- (MFMines_Entered, Security_Entered...) or when you do something there.
VISIT.flags = (function()
return {  -- story flags set by walking into a place (flags/trig.py, namerefs.py): flag -> area
    Res_EnteredBotanicals = "Botanical",
    Labs_Containment_Entered = "Containment", Labs_Helmholtz_Opened = "Containment",
    Reactors_Central_ElectricityOff = "DF_Central", Reactors_DFLabs_SapperCine = "DF_Labs",
    Reactors_FirstContact = "DF_Labs", Reactors_S1Labs_Complete = "DF_Labs",
    Reactors_S3Overgrowth_Complete = "DF_Overgrowth", Reactors_S4RadWaste_Complete = "DF_RadWaste",
    Reactors_S2War_Button1_Pressed = "DF_War", Reactors_S2War_Button2_Pressed = "DF_War",
    Reactors_S2War_Button3_Pressed = "DF_War", Reactors_S2War_Complete = "DF_War",
    Reactors_S2War_GKLoss = "DF_War", Reactors_S2War_OrderLoss = "DF_War", Dams_ActivatedPump1 = "Dam",
    Dams_ActivatedPump2 = "Dam", Dams_ActivatedPump3 = "Dam", Dams_ReachedCentral = "Dam_Central",
    Reactors_SecondContact = "DarkFusion", Fracture_Forcefield_A = "Fracture", Fracture_Forcefield_B = "Fracture",
    H_Garden_A = "H_Garden", H_Garden_B = "H_Garden", H_Garden_C = "H_Garden", H_Japan_Z = "H_Japan",
    LABS_OpenVacuumDoor = "Labs", LABS_TurretsDeactivated = "Labs", MF_ExitOpened = "MFFoundry",
    MFMines_Mgt_Explored = "MFMaggot", MFMines_Entered = "MFMines", Office_CafeteriaUnlocked = "Office1",
    Office_FirstCombatEncounter = "Office1", Office_ReachedLobby = "Office1", Office_Silo3Opened = "Office3",
    Office_ThirdFloorReached = "Office3", Manufacturing_Arrived = "Office4", OfficeDemoEnd = "Office4",
    Office_ForkliftDoorOpened = "Office4", Salem_Opened = "Pens", Plant_EnteredPlant = "Plant",
    Res_HastaTria_PortalTriggered = "Residence", Residence_Entered = "Residence", MF_MetSoldier = "Security",
    Security_Entered = "Security", Security_ExitOpened = "Security", Security_FirstEncounterFailsafe = "Security",
    Security_Gate1Opened = "Security", Security_Gate2Opened = "Security", Security_Gate3Opened = "Security",
    Security_Gate4Opened = "Security", Security_SurfaceElevatorEvent = "Security",
    DAMS_CompletedVoussoir = "V_Alps", LABS_CompletedAnteverseB = "V_Anteverse_B",
    Residence_Kylie_LabHintGiven = "V_BOTANICAL", Flathill_CornWeb = "V_FOG", Fog_Completed = "V_FOG",
    End_Boss_FightStartedOnce = "V_ISLAND", End_CahnDisappears = "V_ISLAND", V_INQ_Entrance = "V_Inq",
    V_INQ_HastaMet = "V_Inq", V_INQ_SunDiskTouched = "V_Inq", NightRealm_Entered = "V_NIGHT",
    NightRealm_LakeVisitor = "V_NIGHT", Reactors_SG_Entered = "V_SUOMI", Reactors_SG_Interior = "V_SUOMI",
    Salem_MetRiggs = "V_Salem", V_Signal_AbductionStarted = "V_Signal", V_Signal_Complete = "V_Signal",
    V_Signal_DisabledJammer = "V_Signal", V_Signal_DisabledJammer_TalkFinished = "V_Signal",
    V_Signal_EncounteredHudson = "V_Signal", V_Signal_Entered = "V_Signal", V_Signal_FixedDish = "V_Signal",
    V_Signal_FixedDish_TalkFinished = "V_Signal", V_Signal_FixedFinalDish = "V_Signal",
    V_Signal_FixedSubstation = "V_Signal", V_Signal_ListenedToSignal = "V_Signal",
    V_Signal_ReachedRadar = "V_Signal", V_Signal_ReachedSubstation = "V_Signal",
    V_Signal_StartDoorDestroyed = "V_Signal", V_Signal_SunOfficeExplored = "V_Signal",
    V_Signal_SunOfficeUnlocked = "V_Signal", SnowglobeComplete = "V_SnowGlobe", Wall_AG_met = "V_TheWall",
    TrainCompletedOnce = "V_Train", VWinter_Complete = "V_Winter", VWinter_LamogiCave = "V_Winter",
    MirrorWorld_Entered = "Vignette_MirrorWorld",
}
end)()
function VISIT.add(name, why)
    if not name or visited[name] then return end
    visited[name] = true
    local f = io.open(VISIT.file, "a"); if f then f:write(name .. "\n"); f:close() end
    log("visited: %s (%s)", DATA.levels[name] and DATA.levels[name].name or name, why)
end
function VISIT.sync()
    local world = nil
    pcall(function()
        local gi = FindFirstOf("Abiotic_GameInstance_C")
        if gi and gi:IsValid() then world = gi.ActiveWorldSaveName:ToString() end
    end)
    if type(world) == "string" and world ~= "" and world ~= VISIT.world then
        VISIT.world = world
        VISIT.file = MOD_DIR .. "visited_" .. world:gsub("[^%w_%-]", "_") .. ".txt"
        for k in pairs(visited) do visited[k] = nil end
        local f = io.open(VISIT.file, "r")
        if f then for line in f:lines() do local n = line:match("^%s*([%w_]+)%s*$"); if n then visited[n] = true end end; f:close() end
        VISIT.flagsRead = nil
    end
    -- every 2 s while the map is open (quest markers follow the story), else every 30 s
    if not VISIT.file or (VISIT.flagsRead and os.clock() - VISIT.flagsRead < (mapOpen and 2 or 30)) then return end
    VISIT.flagsRead = os.clock()
    local okf, errf = pcall(function()
        local gs = FindFirstOf("Abiotic_Survival_GameState_C")
        if not (gs and gs:IsValid()) then return end
        local have = {}
        gs.WorldFlags:ForEach(function(_, e)
            local flag = e:get().RowName:ToString()
            have[flag] = true
            local area = VISIT.flags[flag]
            if area and DATA.levels[area] then VISIT.add(area, "story flag " .. flag) end
        end)
        VISIT.have = have
        if VISIT.rebuildBlocked then pcall(VISIT.rebuildBlocked) end
    end)
    if not okf then log("could not read the world flags: %s", tostring(errf)) end
end
local function checkVisit()
    VISIT.sync()
    if not VISIT.file then return end
    local px, py, pz = playerPos(); if not px then return end
    local name = worldAt(px, py, pz) or areaAt(px, py, pz - FEET)
    if name and not visited[name] then
        VISIT.add(name, "walked in")
        if mapOpen and ui then applyView(viewZ) end
    end
end
-- ---------------------------------------------------------------- doors on the route network
-- route_doors.lua (mkdoors.py): the doors placed in the maps that route walks pass through. A door you can't get
-- through yet (closed security/blast door, one-way door still locked, locked or fake door) takes its walks out of
-- the route. What each door was like when last seen is kept per world in doors_<world>.txt
VISIT.doorState = {}
VISIT.DOORS_SEC = { BlastDoor_C = true, SecurityDoor_C = true, SecurityDoor_Animated_C = true, SecurityDoor_Small_C = true,
                    SecurityDoor_Shutters_C = true, BlastDoor_ORD_Small_C = true, BlastDoor_ORD_Large_C = true }
function VISIT.doors()
    if VISIT.dd == nil then
        local ok, d = pcall(dofile, MOD_DIR .. "Scripts/route_doors.lua")
        VISIT.dd = ok and type(d) == "table" and d or false
        if not VISIT.dd then log("no door data: %s", tostring(d)) else
            VISIT.dclasses, VISIT.dcell = {}, {}
            for i, dr in ipairs(VISIT.dd) do
                dr.key = string.format("%.0f,%.0f,%.0f", dr[1], dr[2], dr[3])
                if not dr[6] then VISIT.dclasses[dr[4]] = true end
                local c = math.floor(dr[1] / 200) .. ":" .. math.floor(dr[2] / 200)
                VISIT.dcell[c] = VISIT.dcell[c] or {}; table.insert(VISIT.dcell[c], dr)
            end
        end
    end
    return VISIT.dd
end
function VISIT.doorAt(x, y, z)
    local cx, cy, best, bd = math.floor(x / 200), math.floor(y / 200), nil, 60 * 60
    for i = cx - 1, cx + 1 do for j = cy - 1, cy + 1 do
        for _, dr in ipairs(VISIT.dcell[i .. ":" .. j] or {}) do
            local d = (dr[1] - x) ^ 2 + (dr[2] - y) ^ 2
            if d < bd and math.abs(dr[3] - z) < 150 then best, bd = dr, d end
        end
    end end
    return best
end
function VISIT.doorLocked(a, cn)
    if VISIT.DOORS_SEC[cn] then return not a.IsDoorOpen end
    if a.FakeDoor then return true end
    local locked = a.OneWayDoor and not a.OneWayDoor_HasBeenUnlocked
    pcall(function()
        local o1, o2, o3 = {}, {}, {}
        a:IsDoorLocked(o1, o2, o3)
        if o1.OneWayLocked == true or o3.GenericLocked == true or o1.GenericLocked == true then locked = true end
    end)
    return locked and true or false
end
-- the straight legs from where you stand (and to the waypoint) onto the route network must not pass a locked door
function VISIT.legOk(x1, y1, z1, x2, y2, z2)
    for _, d in ipairs(VISIT.lockedPts or {}) do
        local dx, dy = x2 - x1, y2 - y1
        local l2 = dx * dx + dy * dy
        -- only a leg that passes the door (not one that starts beside it and leads away)
        local t = l2 > 0 and ((d[1] - x1) * dx + (d[2] - y1) * dy) / l2 or -1
        if t > 0 and t < 1 then
            local ex, ey, ez = x1 + t * dx - d[1], y1 + t * dy - d[2], z1 + t * (z2 - z1) - d[3]
            local r = (d[4]:find("Blast") or d[4]:find("Security")) and 300 or 150     -- blast/security doors are wide
            if ex * ex + ey * ey < r * r and ez > -400 and ez < 350 then return false end
        end
    end
    return true
end
function VISIT.rebuildBlocked()
    local B, n, pts = {}, 0, {}
    for _, dr in ipairs(VISIT.doors() or {}) do
        -- dr[6]: a tram station that stays locked until this story flag is set
        if VISIT.doorState[dr.key] == "L" or (dr[6] and VISIT.have and not VISIT.have[dr[6]]) then
            n = n + 1
            if not dr[6] then pts[#pts + 1] = dr end
            local e = dr[5]
            for k = 1, #e, 2 do B[e[k] * 10000 + e[k + 1]] = true; B[e[k + 1] * 10000 + e[k]] = true end
        end
    end
    -- portals and water pipes that are not running yet (IsTeleporterActive false): no ride from them
    local R = ROUTE
    for k, st in pairs(VISIT.doorState) do
        local id = st == "L" and tonumber(k:match("^p,(%d+)$"))
        if id and R and R.adj[id] then
            n = n + 1
            local nu, l = R.nodes[id], R.adj[id]
            for j = 1, #l, 2 do
                local nv = R.nodes[l[j]]
                if nv[4] == "portal" and (nv[1] - nu[1]) ^ 2 + (nv[2] - nu[2]) ^ 2 > 2000 ^ 2 then B[id * 10000 + l[j]] = true end
            end
        end
    end
    -- the Furniture Store portal needs a long chain of steps (an elevator to activate): never route through it
    if R then
        for id, nu in pairs(R.nodes) do
            if nu[4] == "portal" and tostring(nu[5]):find("Furniture Store", 1, true) and R.adj[id] then
                n = n + 1
                local l = R.adj[id]
                for j = 1, #l, 2 do
                    local nv = R.nodes[l[j]]
                    if (nv[1] - nu[1]) ^ 2 + (nv[2] - nu[2]) ^ 2 > 2000 ^ 2 then      -- the ride into the store world
                        B[id * 10000 + l[j]] = true; B[l[j] * 10000 + id] = true
                    end
                end
            end
        end
    end
    VISIT.blocked = n > 0 and B or nil
    VISIT.lockedPts = pts
    if n ~= VISIT.blockedN then
        local names = {}
        for _, dr in ipairs(VISIT.doors() or {}) do
            if VISIT.doorState[dr.key] == "L" or (dr[6] and VISIT.have and not VISIT.have[dr[6]]) then names[#names + 1] = dr[4] .. "@" .. dr.key .. (dr[6] and ("(" .. dr[6] .. ")") or "") end
        end
        for k, st in pairs(VISIT.doorState) do
            local id = st == "L" and tonumber(k:match("^p,(%d+)$"))
            if id and ROUTE and ROUTE.nodes[id] then names[#names + 1] = "inactive " .. ROUTE.nodes[id][5] .. " #" .. id end
        end
        log("locked: %s", table.concat(names, ", "))
    end
    if n ~= VISIT.blockedN then
        log("%d locked doors / tram stations kept out of routes", n)
        VISIT.blockedN = n
        if route then route.lost = true end
    end
    return n
end
function VISIT.loadDoors()
    for k in pairs(VISIT.doorState) do VISIT.doorState[k] = nil end
    local f = VISIT.file and io.open((VISIT.file:gsub("visited_", "doors_")), "r")
    if f then for line in f:lines() do local k, st = line:match("^(%S+)%s+([LO])"); if k then VISIT.doorState[k] = st end end; f:close() end
    VISIT.rebuildBlocked()
end
function VISIT.tramProbe()
    for _, cn in ipairs({ "TramSystem_Station_C", "Tram_ParentBP_C", "Tram_Default_C" }) do
        pcall(function()
            for _, a in ipairs(FindAllOf(cn) or {}) do
                if valid(a) and not a:GetFName():ToString():find("^Default__") then
                    local l = a:K2_GetActorLocation()
                    local info = {}
                    for _, k in ipairs({ "Station_TramDoorState", "IsAtStation", "Moving", "ButtonsDisabled", "CurrentStationCount" }) do
                        pcall(function() local v = a[k]; if v ~= nil and type(v) ~= "userdata" then info[#info + 1] = k .. "=" .. tostring(v) end end)
                    end
                    pcall(function() local o = {}; local r = a:IsStationLocked(o); info[#info + 1] = "locked=" .. tostring(o.Locked) .. "/" .. tostring(r) end)
                    pcall(function() info[#info + 1] = "flag=" .. a.WorldFlagToTrigger.RowName:ToString() end)
                    pcall(function() info[#info + 1] = "target=" .. a.TargetStation:GetFName():ToString() end)
                    pcall(function() info[#info + 1] = "prev=" .. a.PreviousStation:GetFName():ToString() end)
                    log("tram probe %s %s at %.0f %.0f %.0f %s", cn, a:GetFName():ToString(), l.X, l.Y, l.Z, table.concat(info, " "))
                end
            end
        end)
    end
end
function VISIT.scanDoors()
    if not VISIT.doors() or not VISIT.file then return end
    if not VISIT.tramProbed then VISIT.tramProbed = true; pcall(VISIT.tramProbe) end
    if VISIT.doorWorld ~= VISIT.file then VISIT.doorWorld = VISIT.file; VISIT.loadDoors() end
    local changed = {}
    for cn in pairs(VISIT.dclasses) do
        pcall(function()
            for _, a in ipairs(FindAllOf(cn) or {}) do
                if valid(a) and not a:GetFName():ToString():find("^Default__") then
                    local l = a:K2_GetActorLocation()
                    local dr = VISIT.doorAt(l.X, l.Y, l.Z)
                    if dr then
                        local ok, locked = pcall(VISIT.doorLocked, a, cn)
                        local st = ok and (locked and "L" or "O") or nil
                        if st and VISIT.doorState[dr.key] ~= st then VISIT.doorState[dr.key] = st; changed[#changed + 1] = cn .. " at " .. dr.key .. " " .. st end
                    end
                end
            end
        end)
    end
    -- portals and water pipes: a ride exists only while the teleporter is active (pipes fill with water later)
    local R = loadRoute()
    for _, cn in ipairs({ "Teleporter_WaterPipe_BP_C", "BP_Teleporter_ParentBP_C", "BP_Teleporter_HomeWorld_C" }) do
        pcall(function()
            for _, a in ipairs(FindAllOf(cn) or {}) do
                if R and valid(a) and not a:GetFName():ToString():find("^Default__") then
                    local act = a.IsTeleporterActive
                    if type(act) == "boolean" then
                        local l = a:K2_GetActorLocation()
                        for _, c in ipairs(nearNodes(R, l.X, l.Y, l.Z, 4)) do
                            local nd = R.nodes[c[1]]
                            if nd[4] == "portal" and c[2] < 400 and math.abs(nd[3] - l.Z) < 400 then
                                local key, st = "p," .. c[1], act and "O" or "L"
                                if VISIT.doorState[key] ~= st then VISIT.doorState[key] = st; changed[#changed + 1] = cn .. " " .. nd[5] .. " " .. st end
                            end
                        end
                    end
                end
            end
        end)
    end
    if #changed == 0 then return end
    local f = io.open((VISIT.file:gsub("visited_", "doors_")), "w")
    if f then for k, st in pairs(VISIT.doorState) do f:write(k, " ", st, "\n") end; f:close() end
    log("doors seen: %s", table.concat(changed, ", "))
    VISIT.blockedN = VISIT.blockedN or -1
    VISIT.rebuildBlocked()
end

-- fallback timer (also covers the case where the hook never fires)
-- (only used when the hook never fires: queuing game-thread work from the async loop every 20 ms is
-- something UE4SS has been unstable with, so it stays off while the hook works)
local openedAt = 0
LoopAsync(20, function()
    frameCount.visit = (frameCount.visit or 0) + 1
    frameCount.doors = (frameCount.doors or 0) + 1
    if frameCount.doors >= 250 and not retired and (mapOpen or tempWp) then
        frameCount.doors = 0
        ExecuteInGameThread(function() if not retired then local ok, e = pcall(VISIT.scanDoors); if not ok then log("door scan: %s", tostring(e)) end end end)
    end
    if frameCount.visit >= 50 and not retired then
        frameCount.visit = 0
        ExecuteInGameThread(function() if not retired then pcall(checkVisit) end end)
    end
    if mapOpen and (not frameHooked or (lastHookTick == 0 and os.clock() - openedAt > 1.0)) then
        ExecuteInGameThread(function() if mapOpen and lastHookTick == 0 then safeFrame("timer") end end)
    end
    -- Esc with the map open: undo the game's pause menu (watched for 0.6 s, every other tick)
    if VISIT.escAt and not retired then
        if os.clock() - VISIT.escAt > 0.6 then VISIT.escAt = nil
        elseif frameCount.visit % 2 == 0 then ExecuteInGameThread(function() if VISIT.escAt and VISIT.undoEscMenu then pcall(VISIT.undoEscMenu) end end) end
    end
    -- waypoint fallback: only if the character tick hook is not running (checked about 5 times a second)
    if tempWp and not mapOpen and not retired and os.clock() - lastHudTick > 1.0 then
        hudSlow = (hudSlow or 0) + 1
        if hudSlow >= 10 then
            hudSlow = 0
            if not hudFallbackLogged then hudFallbackLogged = true; log("waypoint: character tick not seen, using a timer") end
            ExecuteInGameThread(function() if tempWp and not mapOpen and not retired then pcall(hudTick) end end)
        end
    end
    return false
end)

-- ---------------------------------------------------------------- open / close
local probedOnce = false
local function openMap()
    local pc = getPC()
    if not valid(pc) or os.clock() < readyAt then log("not in game yet"); return end
    if not getPawn() then return end
    if isPaused() then log("game is paused, map not opened"); return end
    if not ui then
        local ok, res = pcall(buildUI)
        if not ok then log("failed to build map: %s", tostring(res)); return end
        ui = res
        local added, err = pcall(function() ui.root:AddToViewport(400) end)
        if not added then log("could not show map: %s", tostring(err)); ui = nil; return end
    else
        local shown = pcall(function() ui.root:SetVisibility(VIS.SelfHitTestInvisible) end)
        if not shown then ui = nil; return openMap() end
    end
    hookFrame()
    readUnlocked()
    VISIT.flagsRead = nil
    pcall(checkVisit)
    local x, y, z = playerPos()
    -- always open on the player's own floor and follow it (Shift+Wheel switches to manual until next open)
    viewMode = "auto"
    applyView(x and (z - FEET) or viewZ)
    centerOnPlayer()
    mapOpen = true
    setInput(pc, true)
    refreshDynamic()
    local n, names = 0, {}
    for k in pairs(unlocked) do n = n + 1; table.insert(names, k) end
    local vis, missing = {}, {}
    for _, t in ipairs(ui.tiles) do
        if t.shown then table.insert(vis, t.def.file) end
        if t.loaded and not valid(texCache[t.def.file]) then table.insert(missing, t.def.file) end
    end
    local x, y, z = playerPos()
    log("map opened: view %s (z %.0f), player %.0f %.0f %.0f, maps [%s]", viewName, viewZ, x or 0, y or 0, z or 0, table.concat(names, " "))
    log("visible tiles: %s", table.concat(vis, " "))
    pcall(function() local q = {}; for _, it in ipairs(VISIT.questItems()) do q[#q + 1] = it.label end
        log("current quest markers (%d): %s", #q, table.concat(q, " | ")) end)
    if #missing > 0 then log("textures that failed to load: %s", table.concat(missing, " ")) end
    if not probedOnce then probedOnce = true; local okp, ep = pcall(probeWaypoints); if not okp then log("probe failed: %s", tostring(ep)) end end
    -- optional screenshot shortly after opening: taken from the frame callback (no delayed callbacks)
    if settings.autoshot then shotAt = os.clock() + 0.7 end
    openedAt = os.clock(); refocusAt = os.clock(); refocusN = 0
end

local function closeMap()
    if editing then closeEditor(true) end
    if ui then pcall(function() ui.tip:SetVisibility(VIS.Collapsed) end); ui.tipShown = nil end
    if ui then pcall(function() ui.root:SetVisibility(VIS.Collapsed) end) end
    mapOpen = false; drag = nil
    local pc = getPC()
    if valid(pc) then setInput(pc, false) end
    settings.zoom = zoom
    saveSettings()
end

-- any text box in the game or another mod (chat, search, a name box) that has the keyboard: M is a letter then
function VISIT.textFocus()
    for _, cn in ipairs({ "EditableTextBox", "EditableText", "MultiLineEditableTextBox", "MultiLineEditableText" }) do
        local hit = false
        pcall(function()
            for _, w in ipairs(FindAllOf(cn) or {}) do
                if valid(w) and w:HasKeyboardFocus() == true then hit = true; break end
            end
        end)
        if hit then return true end
    end
    return false
end
local lastM = 0
RegisterKeyBind(Key.M, function()
    if editing or VISIT.typing then return end            -- typing a marker name / a search
    local now = os.clock(); if now - lastM < 0.25 then return end; lastM = now
    ExecuteInGameThread(function()
        if editing or VISIT.typing or VISIT.textFocus() then return end
        if mapOpen then closeMap() else openMap() end
    end)
end)
-- Esc closes the map (also while naming a marker). The game sees the same Esc and opens its pause menu:
-- the timer below closes that menu again right after (CloseEscapeMenuAndResumeGame, the menu's own Resume)
RegisterKeyBind(Key.ESCAPE, function()
    if not mapOpen then return end
    VISIT.escAt = os.clock()
    ExecuteInGameThread(function()
        if editing then closeEditor(false) end
        if mapOpen then closeMap() end
    end)
end)
local function escMenuUp(pc)
    local up = false
    pcall(function() local m = pc.EscapeMenu; up = m:IsValid() and m:IsInViewport() and m:IsVisible() end)
    return up or isPaused()
end
function VISIT.undoEscMenu()
    local pc = getPC()
    if not valid(pc) or not escMenuUp(pc) then return end
    VISIT.escAt = nil
    local ok, err = pcall(function() pc:CloseEscapeMenuAndResumeGame() end)
    log("Esc closed the map; %s", ok and "closed the pause menu it opened" or ("could not close the pause menu: " .. tostring(err)))
end
-- Enter saves the marker name being typed
RegisterKeyBind(Key.RETURN, function()
    if mapOpen and editing then ExecuteInGameThread(function() if editing then closeEditor(true) end end) end
    if mapOpen and VISIT.typing then ExecuteInGameThread(function()         -- Enter: leave the search box, keep the search
        pcall(function() lib(WBL):SetInputMode_GameAndUIEx(getPC(), ui.catcher or ui.root, 0, false) end)
        pcall(function() ui.catcher:SetKeyboardFocus() end)
    end) end
end)
-- F5: screenshot + state dump for debugging (works with the map open or closed)
local lastF5 = 0
RegisterKeyBind(Key.F5, function()
    local now = os.clock(); if now - lastF5 < 0.5 then return end; lastF5 = now
    ExecuteInGameThread(function()
        local okp, ep = pcall(probeWaypoints); if not okp then log("probe failed: %s", tostring(ep)) end
        local x, y, z, yaw = playerPos()
        local mu, mv = 0, 0
        if x then mu, mv = worldToMap(x, y) end
        log("F5 capture: open=%s view=%s mode=%s player=%.0f,%.0f,%.0f yaw=%.0f map=%.0f,%.0f zoom=%.2f pan=%.0f,%.0f paused=%s",
            tostring(mapOpen), viewName .. " z" .. tostring(math.floor(viewZ)), viewMode, x or 0, y or 0, z or 0, yaw or 0,
            mu, mv, zoom, panX, panY, tostring(isPaused()))
        if ui and mapOpen then
            local vis = {}
            for _, t in ipairs(ui.tiles) do
                if t.shown then table.insert(vis, t.def.file) end
            end
            log("F5 visible tiles: %s", table.concat(vis, " "))
        end
        pcall(function()
            local pc = getPC()
            StaticFindObject("/Script/Engine.Default__KismetSystemLibrary"):ExecuteConsoleCommand(pc, "shot showui", pc)
        end)
    end)
end)

local function onKey(k, fn) RegisterKeyBind(k, function() if mapOpen and not editing and not VISIT.typing then ExecuteInGameThread(fn) end end) end
pcall(function() RegisterKeyBind(Key.RIGHT_MOUSE_BUTTON, function() if mapOpen then noteClick("rmb", false) end end) end)
pcall(function() RegisterKeyBind(Key.RIGHT_MOUSE_BUTTON, { ModifierKey.SHIFT }, function()
    if mapOpen then rmbShiftAt = os.clock(); noteClick("rmb", false) end
end) end)
pcall(function() RegisterKeyBind(Key.LEFT_MOUSE_BUTTON, { ModifierKey.SHIFT }, function()
    if mapOpen then lmbShiftAt = os.clock() end
end) end)
pcall(function() RegisterKeyBind(Key.MIDDLE_MOUSE_BUTTON, function() if mapOpen then noteClick("mmb", false) end end) end)
onKey(Key.OEM_PLUS, function() zoomAt(1.25) end)
onKey(Key.ADD, function() zoomAt(1.25) end)
onKey(Key.OEM_MINUS, function() zoomAt(0.8) end)
onKey(Key.SUBTRACT, function() zoomAt(0.8) end)

-- new world / new player controller: our widget died with the old world
RegisterHook("/Script/Engine.PlayerController:ClientRestart", function()
    if ui then pcall(function() ui.root:RemoveFromParent() end) end
    ui = nil; mapOpen = false; weChangedInput = false; texCache = {}; texName = {}
    if hud then pcall(function() hud.root:RemoveFromParent() end); pcall(function() hud.root:ClearInternalFlags(ROOTSET) end); hud = nil end
    readyAt = os.clock() + 2          -- give the new world a moment (openMap also needs a pawn)
end)

log("loaded from %s (%d tiles, %d areas). Press M in game.", MOD_DIR, #DATA.tiles,
    (function() local n = 0; for _ in pairs(DATA.levels) do n = n + 1 end; return n end)())
