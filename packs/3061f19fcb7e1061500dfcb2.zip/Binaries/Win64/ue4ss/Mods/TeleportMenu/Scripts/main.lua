-- TeleportMenu: F6 (rebind in F4) lists the other players; click a name to teleport next to them,
-- or Bring to teleport them next to you.
-- The game is server-authoritative for movement (no client-authoritative position in its config), so a
-- client moving itself gets snapped back. The move is therefore always done on the host:
--   * you are the host (or single player): done directly.
--   * you are a client: the request goes to the host through the game's own controller RPC
--     Request_ExecuteGameCommand (an unused developer command channel, no validation, does nothing for an
--     unknown command), and the host's copy of this mod does the teleport. So the HOST needs this mod.
-- UI built like the F4 ModKeybinds menu: UMG under a rooted UserWidget, buttons polled from a game-thread loop.

local MOD = "[TeleportMenu] "
local function log(fmt, ...) print(MOD .. string.format(fmt, ...) .. "\n") end
local function valid(o) return o ~= nil and o.IsValid ~= nil and o:IsValid() end

local TAG = "TeleportMenu.v1"   -- FirstParam of the RPC: marks our requests
local MAXROWS = 8               -- Abiotic Factor allows 6 players
local SCALE = 0.6
local ROOTSET = (EInternalObjectFlags and EInternalObjectFlags.RootSet) or 0x40000000

---------------------------------------------------------------- host side: the actual teleport
local function findPlayerState(id)
    for _, ps in ipairs(FindAllOf("PlayerState") or {}) do
        if valid(ps) and ps.PlayerId == id then return ps end
    end
end

-- move `who` (player pawn) next to `target` (player pawn). Runs where the pawn has authority (the host).
local function teleportPawn(who, target)
    if not (valid(who) and valid(target)) or who == target then return false end
    local tl, rot = target:K2_GetActorLocation(), target:K2_GetActorRotation()
    local fwd, right = target:GetActorForwardVector(), target:GetActorRightVector()
    local yaw = { Pitch = 0, Yaw = rot.Yaw, Roll = 0 }
    -- behind them, then to the sides, then in front; TeleportPlayer (the game's own, used by portals)
    -- refuses a spot where the capsule doesn't fit
    local spots = { { -1, 0 }, { 0, 1 }, { 0, -1 }, { 1, 0 } }
    for _, s in ipairs(spots) do
        local d = { X = tl.X + (fwd.X * s[1] + right.X * s[2]) * 110, Y = tl.Y + (fwd.Y * s[1] + right.Y * s[2]) * 110, Z = tl.Z + 10 }
        local ok, res = pcall(function() return who:TeleportPlayer(d, yaw, false, false, true) end)
        if not ok then log("TeleportPlayer: %s", tostring(res)) end
        if ok and res then
            pcall(function() who.CharacterMovement:StopMovementImmediately() end)
            pcall(function() who.StartOfLastFall = d end)   -- no fall damage from the old height (portals do this too)
            pcall(function() who:FlushNetDormancy() end)
            return true
        end
    end
    log("no free spot next to the target")
    return false
end

-- requests from clients (native server RPC: this callback only runs on the host)
local okHook, hookErr = pcall(RegisterHook, "/Script/AbioticFactor.AbioticPlayerController:Request_ExecuteGameCommand",
    function(ctx, row, first, second)
        local ok, err = pcall(function()
            if first:get():ToString() ~= TAG then return end
            local arg = second:get():ToString()
            local bring = arg:sub(1, 6) == "bring:"   -- "bring:<id>" = move that player to the requester
            local id = tonumber(bring and arg:sub(7) or arg)
            local pc = ctx:get()
            -- only read here; the move happens in a queued game-thread action (see ue4ss-hook rules)
            ExecuteInGameThread(function()
                local ps = id and findPlayerState(id)
                local who = valid(pc) and pc.Pawn or nil
                local target = valid(ps) and ps.PawnPrivate or nil
                local done
                if bring then done = teleportPawn(target, who) else done = teleportPawn(who, target) end
                log("request from %s, %s player %s: %s", valid(pc) and valid(pc.PlayerState) and pc.PlayerState:GetPlayerName():ToString() or "?",
                    bring and "bring" or "go to", tostring(id), done and "done" or "failed")
            end)
        end)
        if not ok then log("request hook: %s", tostring(err)) end
    end)
if not okHook then log("could not hook the request RPC (host side will not work): %s", tostring(hookErr)) end

---------------------------------------------------------------- client side: the menu
local okMK, MK = pcall(require, "ModKeys")
if not okMK then log("shared\\ModKeys missing (%s), using F6", tostring(MK)); MK = nil end

local W = {
    UserWidget = "/Script/UMG.UserWidget", WidgetTree = "/Script/UMG.WidgetTree", Canvas = "/Script/UMG.CanvasPanel",
    Border = "/Script/UMG.Border", VBox = "/Script/UMG.VerticalBox", TextBlock = "/Script/UMG.TextBlock",
    Button = "/Script/UMG.Button", HBox = "/Script/UMG.HorizontalBox", Overlay = "/Script/UMG.Overlay", Image = "/Script/UMG.Image",
    Title = "/Game/Blueprints/Widgets/MenuSystem/W_MenuTitleBig.W_MenuTitleBig_C",
}
local UI = "/Game/SettingsMenu_MP/UI/"
local ARCH = {   -- the game's settings-menu widgets as style templates (same as the F4 menu)
    panelBG  = { "/Game/Blueprints/Widgets/MenuSystem/W_SettingsMenu.W_SettingsMenu_C", "NavBG" },
    rowText  = { UI .. "InputRow.InputRow_C", "Keybind_Text" },
    keyBtn   = { UI .. "StyledAutoSettings/Input/StyledBindCaptureButton.StyledBindCaptureButton_C", "Button_0" },
    keyText  = { UI .. "StyledAutoSettings/Input/StyledKeyLabel.StyledKeyLabel_C", "LabelText" },
}
local classCache = {}
local function cls(path)
    local c = classCache[path]
    if valid(c) then return c end
    pcall(LoadAsset, path)   -- load first: a StaticFindObject miss scans every object
    c = StaticFindObject(path)
    classCache[path] = c
    return c
end
local function wbl() return StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary") end
local function getPC()
    for _, pc in ipairs(FindAllOf("PlayerController") or {}) do if valid(pc) and pc:IsLocalController() then return pc end end
end
local n = 0
local function construct(path, outer, name)
    n = n + 1
    return StaticConstructObject(cls(path), outer, FName("TeleportMenu_" .. name .. n))
end
local archCache = {}
local function archetype(key)
    local a = archCache[key]
    if a == nil then
        local def = ARCH[key]
        pcall(LoadAsset, def[1])
        local ok, o = pcall(StaticFindObject, def[1] .. ":WidgetTree." .. def[2])
        a = (ok and valid(o)) and o or false
        if not a then log("game style %s not found, using a plain widget", key) end
        archCache[key] = a
    end
    return a or nil
end
local function styled(key, plain, tree, name, vis)
    local a, w = archetype(key), nil
    if a then
        n = n + 1
        local ok, res = pcall(StaticConstructObject, a:GetClass(), tree, FName("TeleportMenu_" .. name .. n), 0, 0, false, false, a)
        if ok and valid(res) then w = res end
    end
    w = w or construct(plain, tree, name)
    pcall(function() w:SetVisibility(vis or 3) end)
    return w
end
local function text(tree, s, key)
    local tb = styled(key or "rowText", W.TextBlock, tree, "Text")
    tb:SetText(FText(s))
    return tb
end

local menu, menuOpen = nil, false
local rows, status = {}, nil   -- rows[i] = { btn, label, ps, was }

local function buildMenu(pc)
    rows = {}
    local root = StaticConstructObject(cls(W.UserWidget), FindFirstOf("GameInstance"), FName("TeleportMenu_Root" .. n), 0, ROOTSET)
    root.WidgetTree = construct(W.WidgetTree, root, "Tree")
    local tree = root.WidgetTree
    local canvas = construct(W.Canvas, tree, "Canvas")
    tree.RootWidget = canvas
    local outer = construct(W.VBox, tree, "Outer")
    -- dark shade + game panel image + content, all filling the overlay
    local ov = construct(W.Overlay, tree, "Back")
    local shade = construct(W.Border, tree, "Shade")
    shade:SetBrushColor({ R = 0.01, G = 0.012, B = 0.015, A = 0.94 })
    pcall(function() shade:SetVisibility(3) end)
    for i, w in ipairs({ shade, styled("panelBG", W.Image, tree, "BG"), outer }) do
        local s = ov:AddChildToOverlay(w)
        pcall(function() s:SetHorizontalAlignment(0); s:SetVerticalAlignment(0) end)
        if i == 3 then pcall(function() s:SetPadding({ Left = 32, Top = 20, Right = 32, Bottom = 24 }) end) end
    end
    local cs = canvas:AddChildToCanvas(ov)
    cs:SetAutoSize(true)
    cs:SetAnchors({ Minimum = { X = 0.5, Y = 0.5 }, Maximum = { X = 0.5, Y = 0.5 } })
    cs:SetAlignment({ X = 0.5, Y = 0.5 })
    cs:SetPosition({ X = 0, Y = 0 })
    pcall(function() ov:SetRenderTransformPivot({ X = 0.5, Y = 0.5 }) end)
    pcall(function() ov:SetRenderScale({ X = SCALE, Y = SCALE }) end)

    local title = wbl():Create(pc, cls(W.Title), pc)
    if valid(title) then pcall(function() title.TitleText = FText("TELEPORT TO PLAYER") end); outer:AddChildToVerticalBox(title) end
    outer:AddChildToVerticalBox(text(tree, "Click a name to go to them, or Bring to pull them to you. Escape closes."))
    local kb = archetype("keyBtn")
    for i = 1, MAXROWS do   -- fixed pool: rows are re-labelled / collapsed, never removed (removed widgets get GC'd)
        local function button(caption)
            local btn = construct(W.Button, tree, "Btn")
            pcall(function() btn.IsFocusable = false end)
            if kb then
                pcall(function() btn:SetStyle(kb.WidgetStyle) end)
                pcall(function() btn:SetBackgroundColor(kb.BackgroundColor) end)
            end
            local label = text(tree, caption, "keyText")
            btn:SetContent(label)
            return btn, label
        end
        local hb = construct(W.HBox, tree, "Row")
        local btn, label = button("")
        local bring = button("   Bring   ")
        local s1 = hb:AddChildToHorizontalBox(btn)
        pcall(function() s1:SetSize({ SizeRule = 1, Value = 1.0 }) end)   -- name button fills the row
        local s2 = hb:AddChildToHorizontalBox(bring)
        pcall(function() s2:SetPadding({ Left = 8, Top = 0, Right = 0, Bottom = 0 }) end)
        local s = outer:AddChildToVerticalBox(hb)
        pcall(function() s:SetPadding({ Left = 0, Top = 8, Right = 0, Bottom = 0 }) end)
        rows[i] = { box = hb, btn = btn, bring = bring, label = label }
    end
    status = text(tree, "")
    local ss = outer:AddChildToVerticalBox(status)
    pcall(function() ss:SetPadding({ Left = 0, Top = 12, Right = 0, Bottom = 0 }) end)
    return root
end

local function setStatus(s) if valid(status) then pcall(function() status:SetText(FText(s)) end) end end

-- other players, by name (from PlayerStates: always replicated, unlike far-away pawns)
local function fillRows(pc)
    local mine, list = pc.PlayerState, {}
    for _, ps in ipairs(FindAllOf("PlayerState") or {}) do
        if valid(ps) and ps ~= mine and not ps.bIsSpectator then
            local ok, name = pcall(function() return ps:GetPlayerName():ToString() end)
            list[#list + 1] = { ps = ps, name = ok and name or "?" }
        end
    end
    table.sort(list, function(a, b) return a.name:lower() < b.name:lower() end)
    for i, r in ipairs(rows) do
        local e = list[i]
        r.ps, r.name = e and e.ps, e and e.name
        pcall(function()
            if e then r.label:SetText(FText("   " .. e.name .. "   ")); r.box:SetVisibility(4)
            else r.box:SetVisibility(1) end
        end)
        r.was, r.wasB = true, true   -- ignore a button held down as we open
    end
    setStatus(#list == 0 and "No other players in this world." or "")
end

local hadCursor = false
local function setInput(pc, open)
    local lib = wbl()
    if open then
        hadCursor = pc.bShowMouseCursor == true
        pcall(function() pc:FlushPressedKeys() end)
        pcall(function() menu:SetIsFocusable(true) end)
        local ok, err = pcall(function() lib:SetInputMode_UIOnlyEx(pc, menu, 0, false) end)
        if not ok then log("UI-only input failed: %s", tostring(err)) end
        pc.bShowMouseCursor = true
        pcall(function() pc:SetIgnoreLookInput(true) end)
        pcall(function() pc:SetIgnoreMoveInput(true) end)
    else
        pcall(function() pc:ResetIgnoreLookInput() end)
        pcall(function() pc:ResetIgnoreMoveInput() end)
        pcall(function() pc:FlushPressedKeys() end)
        local ok = false
        if hadCursor then
            ok = pcall(function() lib:SetInputMode_GameAndUIEx(pc, nil, 0, false) end)
            if not ok then ok = pcall(function() lib:SetInputMode_GameAndUIEx(pc, CreateInvalidObject(), 0, false) end) end
        end
        if not ok then
            pcall(function() lib:SetInputMode_GameOnly(pc, true) end)
            pc.bShowMouseCursor = false
        end
    end
end

local function closeMenu()
    if valid(menu) then pcall(function() menu:SetVisibility(1) end) end
    menuOpen = false
    local pc = getPC()
    if valid(pc) then setInput(pc, false) end
end

local function openMenu()
    local pc = getPC()
    if not valid(pc) then log("no local player controller yet"); return end
    if not valid(menu) then
        local ok, res = pcall(buildMenu, pc)
        if not ok or not valid(res) then log("failed to build menu: %s", tostring(res)); return end
        local added, err = pcall(function() res:AddToViewport(440) end)
        if not added then log("could not show menu: %s", tostring(err)); return end
        menu = res
    end
    fillRows(pc)
    pcall(function() menu:SetVisibility(0) end)
    menuOpen = true
    setInput(pc, true)
end

local function dist(a, b) local x, y, z = a.X - b.X, a.Y - b.Y, a.Z - b.Z; return math.sqrt(x * x + y * y + z * z) end

local function teleportTo(r, bring)
    local pc = getPC()
    local me = valid(pc) and pc.Pawn or nil
    if not (valid(me) and valid(r.ps)) then return end
    local name = r.name or "?"
    if me:HasAuthority() then   -- host / single player: do it here
        local target = r.ps.PawnPrivate
        if not valid(target) then log("%s has no body right now (dead / loading?)", name); return end
        local done
        if bring then done = teleportPawn(target, me) else done = teleportPawn(me, target) end
        log("%s %s: %s", bring and "bring" or "go to", name, done and "done" or "no free spot")
        return
    end
    -- client: ask the host, then check we actually moved
    local from = me:K2_GetActorLocation()
    local ok, err = pcall(function() pc:Request_ExecuteGameCommand({ RowName = FName("None") }, TAG, (bring and "bring:" or "") .. tostring(r.ps.PlayerId)) end)
    if not ok then log("request failed: %s", tostring(err)); return end
    log("asked the host to %s %s", bring and "bring" or "go to", name)
    if bring then
        -- their body may be too far away to exist on our PC, so only check when it does
        ExecuteInGameThreadWithDelay(2000, function()
            local t = valid(r.ps) and r.ps.PawnPrivate or nil
            local p = getPC()
            local m = valid(p) and p.Pawn or nil
            if valid(t) and valid(m) and dist(t:K2_GetActorLocation(), m:K2_GetActorLocation()) > 600 then
                log("they did not arrive: the host probably doesn't have TeleportMenu installed")
                if not menuOpen then openMenu() end
                setStatus("Nothing happened. The host needs the Teleport Menu mod too.")
            end
        end)
        return
    end
    ExecuteInGameThreadWithDelay(2000, function()
        local p = getPC()
        local m = valid(p) and p.Pawn or nil
        if valid(m) and dist(m:K2_GetActorLocation(), from) < 200 then
            log("did not move: the host probably doesn't have TeleportMenu installed")
            if not menuOpen then openMenu() end   -- say so where the player is looking
            setStatus("Nothing happened. The host needs the Teleport Menu mod too.")
        end
    end)
end

local lastToggle = 0
local function toggle()
    local now = os.clock()
    if now - lastToggle < 0.3 then return end
    lastToggle = now
    if menuOpen then closeMenu() else openMenu() end
end
if MK then
    MK.bind("TeleportMenu.open", "Teleport Menu", "Open / close the teleport-to-player menu", "F6", toggle)
else
    RegisterKeyBind(Key.F6, function() ExecuteInGameThread(toggle) end)
end
RegisterKeyBind(Key.ESCAPE, function()
    if menuOpen then ExecuteInGameThread(function() if menuOpen then closeMenu() end end) end
end)

LoopInGameThreadWithDelay(30, function()
    if not menuOpen then return end
    if not valid(menu) then menuOpen = false; return end
    for _, r in ipairs(rows) do
        local ok, down = pcall(function() return r.btn:IsPressed() end)
        down = ok and down == true
        local okB, downB = pcall(function() return r.bring:IsPressed() end)
        downB = okB and downB == true
        if r.ps and ((down and not r.was) or (downB and not r.wasB)) then
            closeMenu()
            local ok2, err = pcall(teleportTo, r, downB and not r.wasB)
            if not ok2 then log("teleport: %s", tostring(err)) end
            return
        end
        r.was, r.wasB = down, downB
    end
end)

-- new world: our widget went with the old viewport
RegisterHook("/Script/Engine.PlayerController:ClientRestart", function()
    ExecuteInGameThread(function()
        if valid(menu) then pcall(function() menu:RemoveFromParent() end) end
        menu, menuOpen = nil, false
    end)
end)

log("loaded")
