local MOD = "[CookingRadius] "
local function log(fmt, ...) print(MOD .. string.format(fmt, ...) .. "\n") end
local function valid(o) return o ~= nil and o.IsValid ~= nil and o:IsValid() end

local SETTINGS_FILE = "ue4ss/Mods/CookingRadius/settings.txt"

local settings = { radius = 100, hidejunk = 1, containerw = 564, recipew = 900, columns = 2, searchw = 320, searchh = 92, padl = 52, padt = 66, padr = 46, padb = 56, gap = 16, top = 132, height = 806, favsize = 40, favx = 0, favy = 20, tabsize = 56, searchz = 400 }
do
    local f = io.open(SETTINGS_FILE, "r")
    if f then
        for line in f:lines() do
            local k, v = line:match("^%s*(%w+)%s*=%s*(%S+)")
            if k and settings[k] ~= nil and tonumber(v) then settings[k] = tonumber(v) end
        end
        f:close()
    end
end

local function gtDelay(ms, fn)
    local ok = pcall(ExecuteInGameThreadWithDelay, ms, function() local ok2, err = pcall(fn); if not ok2 then log("timer: %s", tostring(err)) end end)
    if not ok then log("ExecuteInGameThreadWithDelay unavailable") end
end

local function gtLoop(ms, fn)
    local h
    local ok, res = pcall(LoopInGameThreadWithDelay, ms, function()
        local ok2, stop = pcall(fn)
        if not ok2 then log("loop: %s", tostring(stop)); stop = false end
        if stop and h then pcall(CancelDelayedAction, h) end
    end)
    if ok then h = res else log("LoopInGameThreadWithDelay unavailable: %s", tostring(res)) end
    return ok
end

local FAV_FILE = "ue4ss/Mods/CookingRadius/favorites.txt"
local favs = {}
do
    local f = io.open(FAV_FILE, "r")
    if f then
        for line in f:lines() do
            local r = line:match("^%s*(%S+)")
            if r then favs[r] = true end
        end
        f:close()
    end
end
local function saveFavs()
    local rows = {}
    for r, on in pairs(favs) do if on then rows[#rows + 1] = r end end
    table.sort(rows)
    local f = io.open(FAV_FILE, "w")
    if not f then log("could not write %s", FAV_FILE); return end
    f:write(table.concat(rows, "\n"), #rows > 0 and "\n" or "")
    f:close()
end

local ENTER_WHEEL = "/Game/Blueprints/Characters/Abiotic_PlayerCharacter.Abiotic_PlayerCharacter_C:EnterRadialWheel"
local SLOT_DOWN   = "/Game/Blueprints/Widgets/Inventory/W_InventoryItemSlot.W_InventoryItemSlot_C:PerformMouseButtonDown"
local IFL         = "/Game/Blueprints/Libraries/ItemFunctionLibrary.Default__ItemFunctionLibrary_C"
local INVCOMP     = "/Game/Blueprints/Characters/Abiotic_InventoryComponent.Abiotic_InventoryComponent_C"
local SOUPENTRY   = "/Game/Blueprints/Widgets/Journal/W_Compendium_SoupEntry.W_Compendium_SoupEntry_C"
local SOUPLIB     = "/Script/AbioticFactor.Default__SoupRecipeHandleFunctionLibrary"
local CHARBASE    = "/Script/AbioticFactor.AbioticCharacter"
local TABPKG      = "/Game/Blueprints/Widgets/W_RecipeFilterTab"
local TABCLASS    = TABPKG .. ".W_RecipeFilterTab_C"
local CRAFTAREA   = "/Game/Blueprints/Widgets/Inventory/W_Inventory_CraftingArea.W_Inventory_CraftingArea_C"
local donors      = {}
local PDA_BG      = "/Game/Textures/GUI/Journal/journal_pda_bg.journal_pda_bg"
local WBL         = "/Script/UMG.Default__WidgetBlueprintLibrary"
local CONTAINER_VIEW = 1

local QROW, QSUB, QRECIPE, QINDEX = "cookingpot_quantum", "AnyCookingPot", "recipe_quantumpot", 4
local PROXY        = "/Game/Blueprints/Items/FakeItems/CookingProxy_BP.CookingProxy_BP_C"
local SET_MESH     = PROXY .. ":Set Cookware Mesh"
local SET_INITIAL  = PROXY .. ":SetInitialStoveware"
local LIQUID       = "/Game/Blueprints/Characters/Abiotic_PlayerCharacter.Abiotic_PlayerCharacter_C:Server_TryChangeValueInLiquidContainer"
local TABLES = {
    global  = "/Game/Blueprints/Items/ItemTable_Global.ItemTable_Global",
    pickups = "/Game/Blueprints/Items/ItemTable_Pickups.ItemTable_Pickups",
    subs    = "/Game/Blueprints/Items/ItemTable_RecipeSubstitutes.ItemTable_RecipeSubstitutes",
    recipes = "/Game/Blueprints/DataTables/DT_Recipes.DT_Recipes",
}
local function qRow(h)
    local ok, r = pcall(function() return h.RowName:ToString() end)
    return ok and r or ""
end
function isQuantumPot(proxy)
    if not valid(proxy) then return false end
    local q = false
    pcall(function() q = qRow(proxy.CookwareItem) == QROW or qRow(proxy.OriginalItem) == QROW end)
    if not q then pcall(function() q = proxy.StovewareMeshType == QINDEX end) end
    return q
end

local function findTable(path)
    local t = StaticFindObject(path)
    if valid(t) then return t end
    return nil
end

local quantumRows = false
local function addQuantumRows()
    if quantumRows then return true end
    local g, pk, sb, rc = findTable(TABLES.global), findTable(TABLES.pickups), findTable(TABLES.subs), findTable(TABLES.recipes)
    if not (g and pk and sb and rc) then return false end
    quantumRows = true

    for _, t in ipairs({ pk, g }) do
        local ok, err = pcall(function()
            if not t:FindRow(QROW) then
                local src = t:FindRow("cookingpot")
                if not src then error("no cookingpot row") end
                t:AddRow(QROW, src)
            end
            local r = t:FindRow(QROW)
            if not r then error("row not added") end
            r.ItemName = FText("Quantum Pot")
            r.ItemDescription = FText("A cooking pot bound to an exor heart. Cooks with food from any storage within " .. settings.radius .. " m.")
        end)
        if not ok then log("Quantum Pot item row (%s): %s", t:GetFName():ToString(), tostring(err)) end
    end

    local ok2, err2 = pcall(function()
        if not sb:FindRow(QSUB) then sb:AddRow(QSUB, sb:FindRow("AnyPipe")) end
        local r = sb:FindRow(QSUB)
        r.ItemTypeName = FText("Any Cooking Pot")
        r.ItemTypeDescription = FText("A Cooking Pot or a Makeshift Cooking Pot.")
        r.ItemsOfType[1].RowName = FName("cookingpot")
        r.ItemsOfType[2].RowName = FName("cookingpot_makeshift")

        local pot = g:FindRow("cookingpot")
        if pot then r.ItemTypeIcon = pot.InventoryIcon end
    end)
    if not ok2 then log("AnyCookingPot group: %s", tostring(err2)) end

    local ok3, err3 = pcall(function()
        if not rc:FindRow(QRECIPE) then rc:AddRow(QRECIPE, rc:FindRow("recipe_pot")) end
        local r = rc:FindRow(QRECIPE)
        r.ItemToCreate.RowName = FName(QROW)
        r.CountToCreate = 1
        local a, b = r.RecipeItems[1], r.RecipeItems[2]
        a.Item.Table = 1; a.Item.RowName = FName(QSUB); a.Count = 1
        b.Item.Table = 0; b.Item.RowName = FName("gib_exorheart"); b.Count = 1
    end)
    if not ok3 then log("Quantum Pot recipe: %s", tostring(err3)) end
    local check = {}
    pcall(function() check[#check + 1] = "global=" .. tostring(g:FindRow(QROW) ~= nil) end)
    pcall(function() check[#check + 1] = "group=" .. tostring(sb:FindRow(QSUB) ~= nil) end)
    pcall(function() check[#check + 1] = "recipe=" .. tostring(rc:FindRow(QRECIPE) ~= nil) end)
    return true
end

local unlockErr, unlockWhy, unlockSeen, craftErr = false, false, nil, false
local function unlockQuantumRecipe()
    if not quantumRows then return end
    local ps = FindAllOf("Abiotic_PlayerCharacter_C") or {}
    if not unlockSeen or unlockSeen ~= #ps then unlockSeen = #ps end
    for _, p in ipairs(ps) do
        if valid(p) then
            local ok, err = pcall(function()
                local loc = p:IsLocallyControlled()
                local cp = p.CharacterProgressionComponent
                if not loc or not valid(cp) then return end
                local arr = cp.RecipesUnlockedArray
                for i = 1, #arr do
                    if arr[i]:ToString() == QRECIPE then
                        if unlockWhy ~= "have" then unlockWhy = "have" end
                        return
                    end
                end

                local seen = false
                local picked = cp.ItemsPickedUpArray
                for i = 1, #picked do
                    if picked[i]:ToString() == "gib_exorheart" then seen = true; break end
                end
                if not seen then

                    for _, inv in ipairs({ p.CharacterInventory, p.CharacterHotbarInventory }) do
                        if valid(inv) then
                            local cur = inv.CurrentInventory
                            for i = 1, #cur do
                                if cur[i].ItemDataTable.RowName:ToString() == "gib_exorheart" then seen = true; break end
                            end
                        end
                    end
                end
                local why = "check:" .. tostring(seen)
                if unlockWhy ~= why then
                    unlockWhy = why
                end
                if not seen then return end
                cp:Server_TryUnlockRecipe({ Table = 0, RowName = FName(QRECIPE) })
                local now = false
                local arr2 = cp.RecipesUnlockedArray
                for i = 1, #arr2 do if arr2[i]:ToString() == QRECIPE then now = true end end
            end)
            if not ok and not unlockErr then unlockErr = true; log("Quantum Pot recipe unlock: %s", tostring(err)) end
        end
    end
end

local itemFixStep = nil
local rebuilds = {}
local function itemResolves()
    local gl = StaticFindObject("/Script/AbioticFactor.Default__GlobalItemHandleFunctionLibrary")
    local d, p = {}, {}
    gl:GetGlobalItemRow({ RowName = FName(QROW) }, d, p)
    local v = p.ReturnPath
    if type(v) == "userdata" and v.get then v = v:get() end
    return v == 0
end

local function ensureItemResolves()
    local ok = itemResolves()
    if not ok then
        quantumRows = false
        addQuantumRows()
        ok = itemResolves()
    end
    if ok ~= itemFixStep then itemFixStep = ok end
    return ok
end
local function refreshCraftingLists()
    if not quantumRows then return end
    local okr, res = pcall(ensureItemResolves)
    if not okr then log("Quantum Pot item check: %s", tostring(res)); return end
    if not res then return end
    for _, w in ipairs(FindAllOf("W_Inventory_CraftingArea_C") or {}) do
        if valid(w) then
            local ok, err = pcall(function()
                if not w.HasSortedRecipeArray then return end
                local arr = w.CachedAlphabetizedArray
                local n = #arr
                if n == 0 then return end
                local listed = false
                for i = 1, n do if arr[i]:ToString() == QRECIPE then listed = true end end
                if listed then

                    local es = w.CraftingEntries
                    for i = 1, #es do if valid(es[i]) and es[i].ItemToCreate.RowName:ToString() == QROW then return end end
                    local id = tostring(w:GetAddress())
                    if #es == 0 or (rebuilds[id] or 0) >= 3 then return end
                    rebuilds[id] = (rebuilds[id] or 0) + 1
                    es:Empty()
                    pcall(function() w:SetRecipeListNeedsRefresh() end)
                    return
                end

                arr[n + 1] = FName(QRECIPE)
                local added = #arr == n + 1 and arr[n + 1]:ToString() == QRECIPE
                w.CraftingEntries:Empty()
                pcall(function() w:SetRecipeListNeedsRefresh() end)
                if not added then error("could not add to CachedAlphabetizedArray") end
            end)
            if not ok and not craftErr then craftErr = true; log("crafting list reset: %s", tostring(err)) end
        end
    end
end

local function stovewareProp(slot)
    local props = slot.ChangeableData.DynamicProperties
    for i = 1, #props do
        if props[i].Key == 22 then return props[i] end
    end
    return nil
end

local pendingEmpty = nil
local skinProxyNow = nil
local function hookQuantum()
    local function forceIndex(ctx)
        local proxy = ctx:get()
        if valid(proxy) and qRow(proxy.CookwareItem) == QROW and proxy.StovewareMeshType ~= QINDEX then
            proxy.StovewareMeshType = QINDEX
        end
    end
    local ok1, e1 = pcall(RegisterHook, SET_MESH, function() end, function(ctx)
        pcall(forceIndex, ctx)
        if skinProxyNow then pcall(skinProxyNow, ctx:get()) end
    end)
    if not ok1 then log("hook Set Cookware Mesh failed: %s", tostring(e1)) end
    local ok2, e2 = pcall(RegisterHook, SET_INITIAL, function(ctx) pcall(forceIndex, ctx) end)
    if not ok2 then log("hook SetInitialStoveware failed: %s", tostring(e2)) end

    local ok3, e3 = pcall(RegisterHook, LIQUID, function(ctx, invP, idxP, valP)
        pendingEmpty = nil
        local ok, err = pcall(function()
            if valP:get() > 0 then return end
            local inv, idx = invP:get(), idxP:get()
            local slot = inv.CurrentInventory[idx + 1]
            local prop = slot and stovewareProp(slot)
            if prop and prop.Value == QINDEX then
                prop.Value = 1
                pendingEmpty = { inv = inv, idx = idx }
            end
        end)
        if not ok then log("quantum empty (pre): %s", tostring(err)) end
    end, function()
        local pe = pendingEmpty
        pendingEmpty = nil
        if not pe then return end
        local ok, err = pcall(function()
            local slot = pe.inv.CurrentInventory[pe.idx + 1]
            local row = slot.ItemDataTable.RowName:ToString()
            if row == "cookingpot" then
                slot.ItemDataTable.RowName = FName(QROW)
                pcall(function() pe.inv:OnRep_CurrentInventory() end)
            else
                local prop = stovewareProp(slot)
                if prop and prop.Value == 1 then prop.Value = QINDEX end
            end
        end)
        if not ok then log("quantum empty (post): %s", tostring(err)) end
    end)
    if not ok3 then log("hook Server_TryChangeValueInLiquidContainer failed: %s", tostring(e3)) end
end

gtLoop(500, function() return addQuantumRows() end)
gtLoop(3000, function()
    local ok, err = pcall(unlockQuantumRecipe); if not ok then log("recipe unlock loop: %s", tostring(err)) end
    ok, err = pcall(refreshCraftingLists); if not ok then log("crafting list loop: %s", tostring(err)) end
    return false
end)
local quantumHooked = false
gtLoop(2000, function()
    if quantumHooked then return true end
    if not valid(StaticFindObject(PROXY))
        or not valid(StaticFindObject("/Game/Blueprints/Characters/Abiotic_PlayerCharacter.Abiotic_PlayerCharacter_C")) then
        return false
    end
    quantumHooked = true
    pcall(hookQuantum)
    return true
end)

local SKIP_OWNER = { "Stove", "CookingProxy", "Trader", "Dispenser", "Vendor", "PotOfSoup" }

local LOADTAG = string.format("%x%04x", os.time() % 0xFFFFFF, math.random(0, 0xFFFF))
local ROOTSET = (EInternalObjectFlags and EInternalObjectFlags.RootSet) or 0x40000000
local seq = 0
local function cls(path) return StaticFindObject(path) end
local function construct(path, outer, internalFlags)
    seq = seq + 1
    return StaticConstructObject(cls(path), outer, FName("CookingRadius_" .. LOADTAG .. "_" .. seq), 0, internalFlags or 0)
end
local function addr(o) return valid(o) and o:GetAddress() or 0 end
local function nameOfClass(o)
    local ok, n = pcall(function() return o:GetClass():GetFName():ToString() end)
    return ok and n or ""
end

local S = {
    open = false, p = nil, pot = nil, potComp = nil,
    virt = nil,
    items = {},
    loop = false, busy = false, named = false,
    panel = nil,
}
local cookable = {}

local DATA
do
    local ok, d = pcall(require, "cr_data")
    if not ok or type(d) ~= "table" then ok, d = pcall(dofile, "ue4ss/Mods/CookingRadius/Scripts/cr_data.lua") end
    DATA = (ok and type(d) == "table") and d or { food = {}, soups = {} }
    local lower = {}
    for k in pairs(DATA.food) do lower[k:lower()] = true end
    DATA.foodLower = lower
    local n = 0; for _ in pairs(DATA.food) do n = n + 1 end
end

local function canGoInPot(row, slot, p)
    if not (DATA.food[row] or DATA.foodLower[row:lower()]) then return false end
    if DATA.junk and DATA.junk[row] then
        if settings.hidejunk == 2 then return false end
        if settings.hidejunk == 1 and not (DATA.recipeJunk and DATA.recipeJunk[row]) then return false end
    end
    local c = cookable[row]
    if c ~= nil then return c end
    local res = true
    local ok, err = pcall(function()
        local lib = cls(IFL)
        local r = lib:IsCookableItem(slot, p)
        if r ~= nil then res = (r == true) end
    end)
    cookable[row] = res
    return res
end

local function searchable(c, p, charClass)
    local o = c:GetOwner()
    if not valid(o) then return false, false end
    if addr(o) == addr(p) then

        local a = addr(c)
        if a == addr(p.CharacterInventory) or a == addr(p.CharacterHotbarInventory) then return true, true end
        return false, false
    end
    if charClass and o:IsA(charClass) then return false, false end
    local n = nameOfClass(o)
    for _, s in ipairs(SKIP_OWNER) do if n:find(s, 1, true) then return false, false end end
    return true, false, o
end

local function titleText()
    if S.quantum then return string.format("Nearby food (%d m)", settings.radius) end
    return "Your food"
end

local function scan(p)
    local list, byRow = {}, {}
    local ploc = p:K2_GetActorLocation()
    local r = settings.radius * 100
    local r2 = r * r
    local charClass = cls(CHARBASE)
    local comps = FindAllOf("Abiotic_InventoryComponent_C") or {}
    local nComp = 0
    for _, c in ipairs(comps) do
        if valid(c) and addr(c) ~= addr(S.virt) then
            local ok, own, o = searchable(c, p, charClass)
            if ok and (own or S.quantum) then
                local inRange = own
                if not own then
                    local l = o:K2_GetActorLocation()
                    local dx, dy, dz = l.X - ploc.X, l.Y - ploc.Y, l.Z - ploc.Z
                    inRange = dx * dx + dy * dy + dz * dz <= r2
                end
                if inRange then
                    nComp = nComp + 1
                    local inv = c.CurrentInventory
                    for i = 1, #inv do
                        local s = inv[i]
                        local row = s.ItemDataTable.RowName:ToString()
                        if row ~= "" and row ~= "None" then
                            local n = s.ChangeableData.CurrentStack
                            if n and n > 0 and canGoInPot(row, s, p) then
                                local e = byRow[row]
                                if not e then
                                    e = { row = row, total = 0, sources = {} }
                                    byRow[row] = e
                                    list[#list + 1] = e
                                end
                                e.total = e.total + n

                                local src = { comp = c, idx = i - 1, own = own }
                                if own then table.insert(e.sources, 1, src) else e.sources[#e.sources + 1] = src end
                            end
                        end
                    end
                end
            end
        end
    end
    table.sort(list, function(a, b) return a.row < b.row end)
    return list
end

local function getVirt()
    if valid(S.virt) then return S.virt end

    local gi = FindFirstOf("GameInstance")
    S.virt = construct(INVCOMP, gi, ROOTSET)

    pcall(function() S.virt.InventorySlotType = 1 end)
    pcall(function() S.virt.DisplayName = FText(titleText()) end)
    pcall(function() S.virt.CustomDisplayName = true end)
    return S.virt
end

local function sourceSlot(src)
    if not valid(src.comp) then return nil end
    local inv = src.comp.CurrentInventory
    if src.idx + 1 > #inv then return nil end
    return inv[src.idx + 1]
end

local function fillVirt(v, list)
    local slots = math.max(24, math.ceil(#list / 6) * 6)

    pcall(function() v:RevertInventoryToEmpty() end)
    v:UpdateInventorySlotCount(slots, false, { X = 0, Y = 0, Z = 0 })
    for i, e in ipairs(list) do
        local s
        for _, src in ipairs(e.sources) do s = sourceSlot(src); if s then break end end
        if s then
            v:UpdateInventorySlot(i - 1, s)
            local vs = v.CurrentInventory[i]
            vs.ChangeableData.CurrentStack = e.total
        end
    end
    pcall(function() v:OnInventoryUpdated() end)
end

local function unlockedSet(p)
    local set = {}
    pcall(function()
        local arr = p.CharacterProgressionComponent.RecipesUnlockedArray
        for i = 1, #arr do set[arr[i]:ToString()] = true end
    end)
    return set
end

local function soupRows()
    local rows = {}
    for _, r in ipairs(DATA.soups) do rows[#rows + 1] = r end
    table.sort(rows)
    return rows
end

local function loadTex(path)
    local t = StaticFindObject(path)
    if not valid(t) then pcall(LoadAsset, path:match("^(.-)%.") or path); t = StaticFindObject(path) end
    return t
end

local function buildPanel(p)
    local gi = FindFirstOf("GameInstance")
    local root = construct("/Script/UMG.UserWidget", gi, ROOTSET)
    root.WidgetTree = construct("/Script/UMG.WidgetTree", root)
    local tree = root.WidgetTree
    local canvas = construct("/Script/UMG.CanvasPanel", tree)
    tree.RootWidget = canvas

    local frame = construct("/Script/UMG.Overlay", tree, ROOTSET)

    local bg = construct("/Script/UMG.Image", tree)
    local tex = loadTex(PDA_BG)
    if valid(tex) then bg:SetBrushFromTexture(tex, false) else bg:SetColorAndOpacity({ R = 0.05, G = 0.06, B = 0.07, A = 0.95 }) end
    local bs = frame:AddChildToOverlay(bg)
    bs:SetHorizontalAlignment(0); bs:SetVerticalAlignment(0)

    local vb = construct("/Script/UMG.VerticalBox", tree)
    local vs = frame:AddChildToOverlay(vb)
    vs:SetHorizontalAlignment(0); vs:SetVerticalAlignment(0)

    vs:SetPadding({ Left = settings.padl, Top = settings.padt, Right = settings.padr, Bottom = settings.padb })

    local title = construct("/Script/UMG.TextBlock", tree)
    title:SetText(FText("SOUP RECIPES"))
    pcall(function() title:SetJustification(1) end)
    title:SetColorAndOpacity({ SpecifiedColor = { R = 0.03, G = 0.03, B = 0.03, A = 1 }, ColorUseRule = 0 })

    local head = construct("/Script/UMG.HorizontalBox", tree)
    local hs = vb:AddChildToVerticalBox(head)
    hs:SetPadding({ Left = 0, Top = 0, Right = 0, Bottom = 10 })
    local tsl = head:AddChildToHorizontalBox(title)
    tsl:SetSize({ Value = 1.0, SizeRule = 1 })
    tsl:SetVerticalAlignment(2)
    pcall(function() title:SetJustification(0) end)

    local ph = construct("/Script/UMG.SizeBox", tree)
    ph:SetWidthOverride(settings.searchw)
    ph:SetHeightOverride(settings.searchh)
    local phs = head:AddChildToHorizontalBox(ph)
    phs:SetVerticalAlignment(2)
    local sroot = construct("/Script/UMG.UserWidget", gi, ROOTSET)
    sroot.WidgetTree = construct("/Script/UMG.WidgetTree", sroot)
    local stree = sroot.WidgetTree
    local scanvas = construct("/Script/UMG.CanvasPanel", stree)
    stree.RootWidget = scanvas
    local sb = construct("/Script/UMG.VerticalBox", stree)
    local scs = scanvas:AddChildToCanvas(sb)
    scs:SetAutoSize(true)
    sb:SetRenderTransformPivot({ X = 0, Y = 0 })
    local function searchBox(hint)
        local size = construct("/Script/UMG.SizeBox", tree)
        size:SetWidthOverride(settings.searchw)

        local box
        pcall(function()
            local donor = cls(WBL):Create(p, cls(CRAFTAREA), p:GetController())
            donors[#donors + 1] = donor
            local b = donor.EditableTextBox_0
            if valid(b) then b:RemoveFromParent(); box = b end
        end)
        if not valid(box) then
            log("game search box not available, using a plain one")
            box = construct("/Script/UMG.EditableTextBox", tree)
        end
        pcall(function() box:SetHintText(FText(hint)) end)
        pcall(function() box:SetText(FText("")) end)
        size:AddChild(box)
        local sl = sb:AddChildToVerticalBox(size)
        sl:SetPadding({ Left = 0, Top = 2, Right = 0, Bottom = 2 })
        return box
    end
    local recipeBox = searchBox("Search recipes...")
    local ingBox = searchBox("Ingredients (up to 3, space between)")

    local tabRow = construct("/Script/UMG.HorizontalBox", tree)
    local trs = vb:AddChildToVerticalBox(tabRow)
    trs:SetPadding({ Left = 0, Top = 0, Right = 0, Bottom = 8 })
    local tabCls = cls(TABCLASS)
    if not valid(tabCls) then pcall(LoadAsset, TABPKG); tabCls = cls(TABCLASS) end
    local function makeTab(tex, text, isFav)
        local t
        local ok, err = pcall(function()
            t = cls(WBL):Create(p, tabCls, p:GetController())
            local tx = loadTex(tex)
            if valid(tx) then t.Icon_Texture = tx end
            t.DisplayText = FText(text)
            t.Favorites = isFav
            local size = construct("/Script/UMG.SizeBox", tree)
            size:SetWidthOverride(settings.tabsize); size:SetHeightOverride(settings.tabsize)
            size:AddChild(t)
            local sl = tabRow:AddChildToHorizontalBox(size)
            sl:SetPadding({ Left = 0, Top = 0, Right = 6, Bottom = 0 })
        end)
        if not ok then log("tab '%s' failed: %s", text, tostring(err)); return nil end
        return t
    end
    local tabAll = valid(tabCls) and makeTab("/Game/Textures/GUI/icon_allrecipes.icon_allrecipes", "All Recipes", false) or nil
    local tabFav = valid(tabCls) and makeTab("/Game/Textures/GUI/icon_star.icon_star", "Favorites", true) or nil
    if not valid(tabCls) then log("W_RecipeFilterTab_C not found, no tabs") end
    local tabLabel = construct("/Script/UMG.TextBlock", tree)
    tabLabel:SetText(FText("ALL RECIPES"))
    tabLabel:SetColorAndOpacity({ SpecifiedColor = { R = 0.03, G = 0.03, B = 0.03, A = 1 }, ColorUseRule = 0 })
    local tls = tabRow:AddChildToHorizontalBox(tabLabel)
    tls:SetVerticalAlignment(2); tls:SetPadding({ Left = 10, Top = 0, Right = 0, Bottom = 0 })

    local empty = construct("/Script/UMG.TextBlock", tree)
    empty:SetText(FText(""))
    empty:SetColorAndOpacity({ SpecifiedColor = { R = 0.03, G = 0.03, B = 0.03, A = 1 }, ColorUseRule = 0 })
    pcall(function() empty:SetAutoWrapText(true) end)
    empty:SetVisibility(1)
    local es = vb:AddChildToVerticalBox(empty)
    es:SetPadding({ Left = 6, Top = 10, Right = 6, Bottom = 0 })

    local scroll = construct("/Script/UMG.ScrollBox", tree)
    local ss = vb:AddChildToVerticalBox(scroll)
    ss:SetSize({ Value = 1.0, SizeRule = 1 })

    local grid = construct("/Script/UMG.UniformGridPanel", tree)
    pcall(function() grid:SetSlotPadding({ Left = 6, Top = 4, Right = 6, Bottom = 4 }) end)
    scroll:AddChild(grid)

    S.panel = { root = root, frame = frame, scroll = scroll, grid = grid, entries = {},
        ph = ph, sroot = sroot, scs = scs, sb = sb,
        recipeBox = recipeBox, ingBox = ingBox, lastQ = nil,
        tabAll = tabAll, tabFav = tabFav, tabLabel = tabLabel, empty = empty, mode = "all", tabsInit = false }
    return S.panel
end

local CRAFT_PKG = "/Game/Blueprints/Widgets/Inventory/W_Inventory_CraftingArea"
local FAV_ARCH  = CRAFT_PKG .. ".W_Inventory_CraftingArea_C:WidgetTree.Checkbox_AddToFavorites"
local STAR_TEX  = "/Game/Textures/GUI/icon_star.icon_star"
local starLogged = false
local function makeStar(p, tree)
    local arch = StaticFindObject(FAV_ARCH)
    if not valid(arch) then pcall(LoadAsset, CRAFT_PKG); arch = StaticFindObject(FAV_ARCH) end
    local cb, how
    if valid(arch) then
        pcall(function()
            seq = seq + 1
            cb = StaticConstructObject(cls("/Script/UMG.CheckBox"), tree, FName("CookingRadiusStar_" .. LOADTAG .. "_" .. seq),
                0, 0, false, false, arch)
        end)
        local ok = false
        pcall(function() ok = valid(cb) and addr(cb.WidgetStyle.CheckedImage.ResourceObject) == addr(arch.WidgetStyle.CheckedImage.ResourceObject)
            and addr(cb.WidgetStyle.CheckedImage.ResourceObject) ~= 0 end)
        how = ok and "crafting favourite checkbox" or nil
        if not ok then cb = nil end
    end
    if not cb then

        cb = construct("/Script/UMG.CheckBox", tree)
        local star = loadTex(STAR_TEX)
        local tints = { UncheckedImage = { 0.356, 0.356, 0.356, 1 }, UncheckedHoveredImage = { 1, 0.78, 0.2, 1 },
            UncheckedPressedImage = { 1, 1, 1, 1 }, CheckedImage = { 1, 0.78, 0.15, 1 },
            CheckedHoveredImage = { 1, 0.9, 0.5, 1 }, CheckedPressedImage = { 1, 1, 1, 1 } }
        pcall(function() cb.WidgetStyle.CheckBoxType = 1 end)
        for k, c in pairs(tints) do
            pcall(function()
                local br = cb.WidgetStyle[k]
                br.ResourceObject = star
                br.DrawAs = 3
                br.TintColor = { SpecifiedColor = { R = c[1], G = c[2], B = c[3], A = c[4] }, ColorUseRule = 0 }
            end)
        end
        how = "fallback star (archetype " .. (valid(arch) and "found" or "missing") .. ")"
    end
    pcall(function() cb.IsFocusable = false end)

    pcall(function() cb:SetVisibility(0) end)
    pcall(function() cb:SetRenderOpacity(1.0) end)
    if not starLogged then starLogged = true end
    return cb
end
local function recipeName(row) return ((DATA.recipeNames or {})[row] or row):lower() end

local function showPanel(p)
    local pn = (S.panel and valid(S.panel.root)) and S.panel or buildPanel(p)
    local unlocked = unlockedSet(p)

    pcall(function() pn.grid:ClearChildren() end)
    pn.entries = {}
    local main = p.InventoryReference
    pcall(function() pn.frame:RemoveFromParent() end)
    pn.frame:SetVisibility(0)
    local cs = main.Panel_Primary:AddChildToCanvas(pn.frame)
    local x = (1920 - settings.containerw - settings.gap - settings.recipew) / 2 + settings.containerw + settings.gap
    cs:SetPosition({ X = x, Y = settings.top })
    cs:SetSize({ X = settings.recipew, Y = settings.height })
    pcall(function() cs:SetZOrder(50) end)
    local entryClass = cls(SOUPENTRY)
    if not valid(entryClass) then pcall(LoadAsset, "/Game/Blueprints/Widgets/Journal/W_Compendium_SoupEntry"); entryClass = cls(SOUPENTRY) end
    if not valid(entryClass) then log("W_Compendium_SoupEntry_C not found"); return end
    local n = 0
    for _, row in ipairs(soupRows()) do
        local ok, err = pcall(function()
            local e = cls(WBL):Create(p, entryClass, p:GetController())
            e.SoupRecipeRow = FName(row)
            e.Unlocked = unlocked[row] == true
            local cols = math.max(1, math.floor(settings.columns))

            local tree = pn.root.WidgetTree
            local box = construct("/Script/UMG.Overlay", tree)
            local es = box:AddChildToOverlay(e)
            es:SetHorizontalAlignment(0); es:SetVerticalAlignment(0)
            local star
            do
                star = makeStar(p, tree)
                pcall(function() star:SetIsChecked(favs[row] == true) end)
                local size = construct("/Script/UMG.SizeBox", tree)
                size:SetWidthOverride(settings.favsize); size:SetHeightOverride(settings.favsize)
                size:AddChild(star)
                local ss = box:AddChildToOverlay(size)
                ss:SetHorizontalAlignment(3); ss:SetVerticalAlignment(1)
                ss:SetPadding({ Left = 0, Top = settings.favy, Right = settings.favx, Bottom = 0 })
            end
            local sl = pn.grid:AddChildToUniformGrid(box, n // cols, n % cols)
            pcall(function() sl:SetHorizontalAlignment(0) end)
            pn.entries[#pn.entries + 1] = { w = e, box = box, star = star, slot = sl, row = row,
                unlocked = unlocked[row] == true }
            n = n + 1
        end)
    end
    local stars = 0
    for _, en in ipairs(pn.entries) do if en.star and valid(en.star) then stars = stars + 1 end end
    pn.lastQ = nil
end

local function hidePanel()
    if S.panel and valid(S.panel.frame) then
        local f = S.panel.frame
        pcall(function() f:SetVisibility(1) end)
        local ok, err = pcall(function() f:RemoveFromParent() end)
        if not ok then log("recipe panel remove failed: %s", tostring(err)) end
    end
end

local function removeStalePanels()
    local cur = S.panel and addr(S.panel.frame) or 0
    local n = 0
    for _, w in ipairs(FindAllOf("Overlay") or {}) do
        if valid(w) and addr(w) ~= cur then
            local ok, name = pcall(function() return w:GetFName():ToString() end)
            if ok and name:find("^CookingRadius_") then
                pcall(function() w:SetVisibility(1) end)
                pcall(function() w:RemoveFromParent() end)
                n = n + 1
            end
        end
    end
end

local saved = nil
local function applyLayout(main)
    if saved then return end
    saved = { vis = {}, pos = nil }
    local hide = {}
    pcall(function() hide[#hide + 1] = main.W_Inventory_EquipSlots end)
    pcall(function() hide[#hide + 1] = main.CharacterBGGlow end)
    pcall(function() hide[#hide + 1] = main.W_Inventory_PlayerBackpack:GetParent() end)
    pcall(function() hide[#hide + 1] = main.W_InventoryGenericDropArea end)
    pcall(function() hide[#hide + 1] = main.TestTube_BG end)
    pcall(function() hide[#hide + 1] = main.W_PlayerHUD_Hotbar end)
    pcall(function() hide[#hide + 1] = main.HotbarTipIcon end)
    pcall(function() hide[#hide + 1] = main.W_Inventory_NavBar end)
    for _, w in ipairs(hide) do
        if valid(w) then
            saved.vis[#saved.vis + 1] = { w = w, v = w:GetVisibility() }
            w:SetVisibility(1)
        end
    end
    pcall(function()
        local sl = main.WS_PrimaryRightPanel.Slot
        local pos = sl:GetPosition()
        saved.pos = { X = pos.X, Y = pos.Y }
        saved.slot = sl
        sl:SetPosition({ X = (1920 - settings.containerw - settings.gap - settings.recipew) / 2, Y = pos.Y })
    end)
end
local function restoreLayout()
    if not saved then return end
    for _, e in ipairs(saved.vis) do
        if valid(e.w) then pcall(function() e.w:SetVisibility(e.v) end) end
    end
    if saved.pos and valid(saved.slot) then pcall(function() saved.slot:SetPosition(saved.pos) end) end
    saved = nil
end

local addToPot
local isCookingPot
local queue = {}
local flick = {}
local iconOwner = {}
local slotByIdx = {}
local hl = { key = "", idx = {} }

local function setOutline(idx, on)
    local w = slotByIdx[idx]
    if not valid(w) then return end
    local ok = pcall(function() w["Toggle Bounce Outline"](w, on, on) end)
    if not ok and on then
        pcall(function() w.ParentInventoryGrid:HighlightSlot(idx, true) end)
    end
end
local function ingredientRows(en, row)
    local rows = { row }
    for _, g in ipairs((DATA.recipes or {})[en.row] or {}) do
        local inGroup = false
        for _, r in ipairs(g) do if r == row then inGroup = true; break end end
        if inGroup then rows = g; break end
    end
    return rows
end
local function hoverTick(pn)
    local rows
    for _, en in ipairs(pn.entries) do
        local w = en.w
        if valid(w) and (not en.box or en.box:IsVisible()) then
            for _, k in ipairs({ "Item1", "Item2", "Item3", "Item4" }) do
                local sl = w[k]
                if valid(sl) and sl:IsHovered() then
                    local ok, r = pcall(function() return sl.ItemInSlot.ItemDataTable.RowName:ToString() end)
                    if ok and r and r ~= "" and r ~= "None" then rows = ingredientRows(en, r) end
                    break
                end
            end
        end
        if rows then break end
    end
    local want = {}
    if rows then
        for _, r in ipairs(rows) do
            for i, e in ipairs(S.items) do if e.row == r and e.total > 0 then want[#want + 1] = i - 1 end end
        end
    end
    table.sort(want)
    local key = table.concat(want, ",")
    if key == hl.key then return end
    for _, idx in ipairs(hl.idx) do setOutline(idx, false) end
    for _, idx in ipairs(want) do setOutline(idx, true) end
    hl.key, hl.idx = key, want
end

local function pretty(row) return (row:gsub("^food_", ""):gsub("^gib_", ""):gsub("_", " ")) end
local function warn(text)
    pcall(function() S.p:Client_DisplayWarningMessage(FText(text), 1, false) end)
end

local function cookRecipe(row)
    local groups = DATA.recipes and DATA.recipes[row]
    if not groups then warn("No ingredient list for " .. row); return end
    local have, missing, used, picks = {}, {}, {}, {}
    for _, e in ipairs(S.items) do have[e.row] = e.total end
    for _, g in ipairs(groups) do
        local pick
        for _, r in ipairs(g) do
            if (have[r] or 0) - (used[r] or 0) > 0 then pick = r; break end
        end
        if pick then used[pick] = (used[pick] or 0) + 1; picks[#picks + 1] = pick
        else missing[#missing + 1] = pretty(g[1]) end
    end

    if #missing > 0 then
        warn(string.format("Missing %d ingredient(s): %s", #missing, table.concat(missing, ", ")))
        return false
    end
    for _, r in ipairs(picks) do queue[#queue + 1] = r end
    return true
end

local function slotIndexOf(row)
    for i, e in ipairs(S.items) do if e.row == row and e.total > 0 then return i - 1 end end
end

local function lower(s) return (s or ""):lower() end
local function boxText(b)
    local ok, t = pcall(function() return b:GetText():ToString() end)
    return ok and t or ""
end
local function recipeMatches(en, rq, toks)
    if rq == "" and #toks == 0 then return true end
    if not en.unlocked then return false end
    if rq ~= "" then
        local name = lower((DATA.recipeNames or {})[en.row] or en.row)
        if not name:find(rq, 1, true) then return false end
    end
    local groups = (DATA.recipes or {})[en.row] or {}
    for _, t in ipairs(toks) do
        local hit = false
        for _, g in ipairs(groups) do
            for _, r in ipairs(g) do
                local nm = lower((DATA.itemNames or {})[r] or r)
                if nm:find(t, 1, true) or lower(r):find(t, 1, true) then hit = true; break end
            end
            if hit then break end
        end
        if not hit then return false end
    end
    return true
end
local function applySearch(pn)
    local rq = lower(boxText(pn.recipeBox)):gsub("^%s+", ""):gsub("%s+$", "")
    local iq = lower(boxText(pn.ingBox))
    local favMode = pn.mode == "fav"
    local key = rq .. "|" .. iq .. "|" .. (favMode and "fav" or "all")
    if key == pn.lastQ and not pn.refilter then return end

    local jump = key ~= pn.lastQ
    pn.lastQ = key
    pn.refilter = false
    local toks = {}
    for w in iq:gmatch("%S+") do if #toks < 3 then toks[#toks + 1] = w end end

    local order = {}
    for i, en in ipairs(pn.entries) do
        local fav = favs[en.row] == true
        order[#order + 1] = { en = en, i = i, show = (not favMode) or fav }
    end
    if favMode then
        table.sort(order, function(a, b)
            if a.show ~= b.show then return a.show end
            return recipeName(a.en.row) < recipeName(b.en.row)
        end)
    end
    local cols = math.max(1, math.floor(settings.columns))
    local n = 0
    for _, o in ipairs(order) do
        local en = o.en
        local cell = en.box or en.w
        if valid(cell) then
            if o.show and recipeMatches(en, rq, toks) then
                pcall(function()
                    en.slot:SetRow(n // cols)
                    en.slot:SetColumn(n % cols)
                end)
                pcall(function() cell:SetVisibility(0) end)
                n = n + 1
            else
                pcall(function() cell:SetVisibility(1) end)
            end
        end
    end
    if jump then
        pcall(function() pn.scroll:ScrollToStart() end)
        pn.holdTicks = 0
    elseif pn.holdTicks and pn.holdTicks > 0 then
        pcall(function() pn.scroll:SetScrollOffset(pn.holdOffset) end)
    end
    if valid(pn.empty) then
        pcall(function() pn.empty:SetVisibility((favMode and n == 0) and 4 or 1) end)
        pcall(function()
            local nothing = 0
            for _, en in ipairs(pn.entries) do if favs[en.row] then nothing = nothing + 1 end end
            pn.empty:SetText(FText(nothing == 0 and "No favorites yet. Click the star on a recipe to add it here."
                or "No favorite recipes match the search."))
        end)
    end
end

local typing = false
local SBL = "/Script/UMG.Default__SlateBlueprintLibrary"
local WLL = "/Script/UMG.Default__WidgetLayoutLibrary"

local placeErr = false
local function placeSearch(pn)
    if not valid(pn.sroot) then return end
    if not pn.sroot:IsInViewport() then pn.sroot:AddToViewport(settings.searchz) end
    local ok, err = pcall(function()

        local wll = cls(WLL)
        local px = wll:GetViewportSize(S.p)
        local dpi = wll:GetViewportScale(S.p)
        local vw, vh = px.X / dpi, px.Y / dpi
        local k = math.min(vw / 1920, vh / 1080)
        local ox, oy = (vw - 1920 * k) / 2, (vh - 1080 * k) / 2
        local frameX = (1920 - settings.containerw - settings.gap - settings.recipew) / 2 + settings.containerw + settings.gap
        local dx = frameX + settings.recipew - settings.padr - settings.searchw
        local dy = settings.top + settings.padt
        pn.scs:SetPosition({ X = ox + dx * k, Y = oy + dy * k })
        pn.sb:SetRenderScale({ X = k, Y = k })
    end)
    if not ok and not placeErr then placeErr = true; log("search placement failed: %s", tostring(err)) end
end
local function hideSearch(pn)
    if pn and valid(pn.sroot) then pcall(function() pn.sroot:RemoveFromParent() end) end
end

local function searchFocusTick(pn)
    local focused = false
    pcall(function() focused = pn.recipeBox:HasKeyboardFocus() or pn.ingBox:HasKeyboardFocus() end)
    if focused == typing then return end
    typing = focused
    local p = S.p
    pcall(function()
        local pc = p:GetController()
        if focused then

            cls(WBL):SetInputMode_UIOnlyEx(pc, pn.recipeBox:HasKeyboardFocus() and pn.recipeBox or pn.ingBox, 0, false)
            pcall(function() p:DisableInput(pc) end)
            pcall(function() pc.bShowMouseCursor = true end)
        else
            pcall(function() p:EnableInput(pc) end)
            cls(WBL):SetInputMode_GameAndUIEx(pc, p.InventoryReference, 0, true, false)
        end
    end)
end

local function cardsTick()
    local pn = S.panel
    if not pn then return end
    iconOwner = {}

    local off
    pcall(function() off = pn.scroll:GetScrollOffset() end)
    if pn.holdTicks and pn.holdTicks > 0 then
        pn.holdTicks = pn.holdTicks - 1
        if off ~= pn.holdOffset then pcall(function() pn.scroll:SetScrollOffset(pn.holdOffset) end) end
    elseif off then
        pn.lastOffset = off
    end

    local changed = false
    for _, en in ipairs(pn.entries) do
        if en.star and valid(en.star) then
            local ok, on = pcall(function() return en.star:IsChecked() end)
            if ok and type(on) == "boolean" and on ~= (favs[en.row] == true) then
                favs[en.row] = on or nil
                changed = true
            end
        end
    end
    if changed then
        saveFavs(); pn.refilter = true
        if pn.lastOffset then
            pn.holdOffset = pn.lastOffset; pn.holdTicks = 4
            pcall(function() pn.scroll:SetScrollOffset(pn.holdOffset) end)
        end
    end

    if valid(pn.tabAll) and valid(pn.tabFav) then
        local function on(t) local ok, v = pcall(function() return t.CheckBox:IsChecked() end); return ok and v == true end
        local function set(t, v) pcall(function() t:SetNewCheckState(v and 1 or 0) end) end
        if not pn.tabsInit then
            pn.tabsInit = true
            set(pn.tabAll, pn.mode == "all"); set(pn.tabFav, pn.mode == "fav")
        else
            local a, f = on(pn.tabAll), on(pn.tabFav)
            local want = pn.mode
            if pn.mode == "all" and f then want = "fav" elseif pn.mode == "fav" and a then want = "all" end
            if want ~= pn.mode then pn.mode = want; pn.lastQ = nil end
            if a ~= (pn.mode == "all") then set(pn.tabAll, pn.mode == "all") end
            if f ~= (pn.mode == "fav") then set(pn.tabFav, pn.mode == "fav") end
            pcall(function() pn.tabLabel:SetText(FText(pn.mode == "fav" and "FAVORITES" or "ALL RECIPES")) end)
        end
    end
    for _, en in ipairs(pn.entries) do
        local w = en.w
        if valid(w) then
            pcall(function()
                local icon = w.PrimarySoupItem
                if not valid(icon) then return end
                iconOwner[addr(icon)] = en
                for _, k in ipairs({ "PrimarySoupItem", "Item1", "Item2", "Item3", "Item4" }) do
                    local sl = w[k]
                    if valid(sl) and not sl.RepresentationOnly then sl.RepresentationOnly = true end
                end
                local f = flick[en]
                if f and f > 0 then

                    icon:SetRenderOpacity((f % 2 == 0) and 0.25 or 1.0)
                    icon:SetRenderScale({ X = 1.12, Y = 1.12 })
                    flick[en] = f - 1
                elseif icon:IsHovered() then
                    icon:SetRenderOpacity(1.0)
                    icon:SetRenderScale({ X = 1.12, Y = 1.12 })
                    pcall(function() icon:SetColorAndOpacity({ R = 1.0, G = 0.95, B = 0.55, A = 1.0 }) end)
                else
                    icon:SetRenderOpacity(1.0)
                    icon:SetRenderScale({ X = 1.0, Y = 1.0 })
                    pcall(function() icon:SetColorAndOpacity({ R = 1.0, G = 1.0, B = 1.0, A = 1.0 }) end)
                end
            end)
        end
    end
end

local function onRecipeIconClick(en)
    flick[en] = 6
    cookRecipe(en.row)
end

local function ourGrid()
    local p = S.p
    if not valid(p) then return nil end
    local main = p.InventoryReference
    if not valid(main) then return nil end
    local cw = main.CurrentContainerWidget
    if not valid(cw) then return nil end
    local g = cw.W_InventoryGrid
    if not valid(g) or addr(g.MainInventoryComponent) ~= addr(S.virt) then return nil end
    return g, cw, main
end

local ourSlots = {}
local lockErr = false
local function lockSlots(g)

    local ok, err = pcall(function()
        local panel = g.UGrid_InventorySlots
        local n = panel:GetChildrenCount()
        local map, byIdx = {}, {}
        for i = 0, n - 1 do
            local s = panel:GetChildAt(i)
            if valid(s) then
                if s.RepresentationOnly ~= nil and not s.RepresentationOnly then s.RepresentationOnly = true end
                local idx = i
                pcall(function() idx = s.SlotIndex end)
                map[addr(s)] = idx
                byIdx[idx] = s
            end
        end

        if addr(byIdx[0]) ~= addr(slotByIdx[0]) then hl.key = ""; hl.idx = {} end
        ourSlots = map
        slotByIdx = byIdx
    end)
    if not ok and not lockErr then lockErr = true; log("slot lock failed: %s", tostring(err)) end
    return ok
end

local function resetInteract(p, why)
    if not valid(p) then return end
    local before = ""
    pcall(function()
        before = string.format("keyHeld=%s performing=%s lastA=%s", tostring(p.Local_KeyHeld_Interact),
            tostring(p.PerformingInteraction), tostring(p.LastInteractionWasTypeA))
    end)
    pcall(function() p:Local_Try_EndInteraction_Safe(true, true, true) end)
    pcall(function() p.Local_KeyHeld_Interact = false end)
    pcall(function() p.PerformingInteraction = false end)
    pcall(function() p:Toggle_HUDHoldInteract(false, true) end)
end

local function close(reason)
    if not S.open then return end
    S.open = false
    pcall(resetInteract, S.p, "close")
    ourSlots = {}
    for _, idx in ipairs(hl.idx) do setOutline(idx, false) end

    for _, sl in pairs(slotByIdx) do
        pcall(function() if valid(sl) and sl.RepresentationOnly then sl.RepresentationOnly = false end end)
    end
    slotByIdx, hl = {}, { key = "", idx = {} }
    hidePanel()
    restoreLayout()
    queue, flick, iconOwner = {}, {}, {}
    hideSearch(S.panel)
    if typing then
        typing = false
        pcall(function() S.p:EnableInput(S.p:GetController()) end)
        pcall(function() cls(WBL):SetInputMode_GameOnly(S.p:GetController(), false) end)
    end

    pcall(function()
        local m = S.p.InventoryReference
        if valid(m) and m.InventoryMode == CONTAINER_VIEW and addr(m.ActiveContainer) == addr(S.virt) or not valid(m.ActiveContainer) then
            m.InventoryMode = 0
        end
    end)
    pcall(function() if valid(S.virt) then S.virt:RevertInventoryToEmpty() end end)
    S.items = {}
end

local function watch()
    if not S.open then return end
    local g, cw, main = ourGrid()
    local shown = g and main:IsVisible() and cw:IsVisible() and main.InventoryMode == CONTAINER_VIEW
    if not shown then
        S.misses = (S.misses or 0) + 1
        if S.misses > 3 then
            local why = "inventory closed"
            pcall(function()
                local m = S.p.InventoryReference
                why = string.format("grid=%s mainVisible=%s mode=%s activeIsOurs=%s", tostring(g ~= nil),
                    tostring(m:IsVisible()), tostring(m.InventoryMode), tostring(addr(m.ActiveContainer) == addr(S.virt)))
            end)
            close(why)
        end
        return
    end
    S.misses = 0
    lockSlots(g)
    pcall(cardsTick)
    if S.panel then
        local ok, err = pcall(hoverTick, S.panel)
        if not ok and not S.hoverErr then S.hoverErr = true; log("ingredient hover failed: %s", tostring(err)) end
    end
    if S.panel then pcall(placeSearch, S.panel); pcall(applySearch, S.panel); pcall(searchFocusTick, S.panel) end
    if #queue > 0 and (not S.busy or os.clock() - (S.busyAt or 0) >= 2) then
        local row = table.remove(queue, 1)
        local idx = slotIndexOf(row)
        if idx then addToPot(idx) else warn("Ran out of " .. pretty(row)) end
    end
    if not S.named then
        pcall(function() cw.ContainerNameText:SetText(FText(titleText())) end)
        pcall(function() cw.Button_EditContainerName:SetVisibility(1) end)
        S.named = true
    end
end

local function startLoop()
    if S.loop then return end
    S.loop = true
    gtLoop(100, function()
        if not S.open then S.loop = false; return true end
        pcall(watch)
        if not S.open then S.loop = false; return true end
        return false
    end)
end

local function refresh()
    if not S.open or not valid(S.p) then return end
    S.items = scan(S.p)
    fillVirt(getVirt(), S.items)
    local g = ourGrid()
    if g then lockSlots(g) end
end

local function openCooking(p, pot, potComp)
    S.p, S.pot, S.potComp = p, pot, potComp
    S.quantum = isQuantumPot(pot)
    S.items = scan(p)
    local v = getVirt()
    if not valid(v) then log("could not create the virtual inventory"); return end
    pcall(function() v.DisplayName = FText(titleText()) end)
    fillVirt(v, S.items)
    S.open, S.named, S.misses = true, false, -10
    pcall(function() v.InventorySlotType = 1 end)
    local main = p.InventoryReference
    if valid(main) then pcall(function() main.ActiveContainer = v end) end
    p:ToggleInventory(false, CONTAINER_VIEW, {}, v, false)
    if valid(main) and addr(main.ActiveContainer) ~= addr(v) then
        main.ActiveContainer = v
        main.InventoryMode = CONTAINER_VIEW
        pcall(function() main:RefreshInventoryMode() end)
    end
    pcall(removeStalePanels)
    if valid(main) then pcall(applyLayout, main) end
    showPanel(p)
    startLoop()
end

function addToPot(slotIndex)
    if not S.open then return end

    local e = S.items[slotIndex + 1]

    if S.busy and os.clock() - (S.busyAt or 0) < 2 then
        if e and e.total > 0 then queue[#queue + 1] = e.row end
        return
    end
    local p, pot = S.p, S.pot
    if not e or e.total <= 0 then return end
    if not valid(p) or not valid(pot) then log("pot or player gone"); return end
    local src
    for _, s in ipairs(e.sources) do
        local sl = sourceSlot(s)
        if sl and sl.ItemDataTable.RowName:ToString() == e.row and sl.ChangeableData.CurrentStack > 0 then src = s; break end
    end
    if not src then refresh(); return end
    S.busy = true
    S.busyAt = os.clock()
    local rowName = FName(e.row)
    local function cook()
        local ok, err = pcall(function() p:Request_RadialWheelSelectionInteract(pot, S.potComp, rowName) end)
        if not ok then log("pot add failed: %s", tostring(err)) end
        gtDelay(350, function() S.busy = false; pcall(refresh) end)
    end
    if src.own then cook(); return end

    local ok, err = pcall(function()
        if p:HasAuthority() then
            local sl = sourceSlot(src)
            src.comp:Server_TransferItemsToCharacterByRowName(p, sl.ItemDataTable, 1)
        else

            p:Request_TryQuickMoveItem(src.comp, p, src.idx, false, p.CharacterInventory, true, false)
        end
    end)
    if not ok then log("take from container failed: %s", tostring(err)); S.busy = false; return end
    gtDelay(120, cook)
end

local function rowOf(h)
    local ok, r = pcall(function() return h.RowName:ToString() end)
    return ok and r or ""
end
function isCookingPot(proxy)
    if not valid(proxy) or not nameOfClass(proxy):find("CookingProxy", 1, true) then return false end
    local cw, orig = "", ""
    pcall(function() cw = rowOf(proxy.CookwareItem) end)
    pcall(function() orig = rowOf(proxy.OriginalItem) end)
    local pot = cw:find("^cookingpot") ~= nil or orig:find("^cookingpot") ~= nil

    pcall(function()
        local out = {}
        cls("/Game/Blueprints/Libraries/AbioticFunctionLibrary.Default__AbioticFunctionLibrary_C")
            :IsItemCookingPot(proxy.CookwareItem, proxy, out)
        if out.IsCookingPot ~= nil then pot = pot or out.IsCookingPot == true end
    end)
    return pot
end

local function hookAll()
    local ok1, e1 = pcall(RegisterHook, ENTER_WHEEL, function(ctx, classParam)
        local p = ctx:get()
        local c = classParam:get()
        local n = valid(c) and c:GetFName():ToString() or ""
        if not n:find("CookingItems", 1, true) then return end
        local pot, comp = p.BestInteractable_InteractA, p.BestInteractableComponent

        if not isCookingPot(pot) then return end
        ExecuteInGameThread(function()
            pcall(function() p:TryCloseRadialWheel(false, c, {}) end)
            if not valid(pot) then log("no pot in front of you"); return end
            local ok, err = pcall(openCooking, p, pot, comp)
            if not ok then log("open failed: %s", tostring(err)) end
            pcall(resetInteract, p, "open")
        end)
    end)
    if not ok1 then log("hook EnterRadialWheel failed: %s", tostring(e1)) end

    local ok2, e2 = pcall(RegisterHook, SLOT_DOWN, function(ctx)
        if not S.open then return end
        local s = ctx:get()
        local en = iconOwner[addr(s)]
        if en then ExecuteInGameThread(function() pcall(onRecipeIconClick, en) end); return end
        local idx = ourSlots[addr(s)]
        if idx == nil then return end
        ExecuteInGameThread(function()

            if typing then pcall(function() S.p.InventoryReference:SetKeyboardFocus() end) end
            local ok, err = pcall(addToPot, idx)
            if not ok then log("add to pot failed: %s", tostring(err)) end
        end)
    end)
    if not ok2 then log("hook PerformMouseButtonDown failed: %s", tostring(e2)) end
end

local hooked = false
local function tryHook()
    if hooked then return true end
    if not valid(StaticFindObject("/Game/Blueprints/Characters/Abiotic_PlayerCharacter.Abiotic_PlayerCharacter_C"))
        or not valid(StaticFindObject("/Game/Blueprints/Widgets/Inventory/W_InventoryItemSlot.W_InventoryItemSlot_C")) then
        return false
    end
    hooked = true
    pcall(removeStalePanels)
    hookAll()
    return true
end
gtLoop(2000, function()
    if hooked then return true end
    pcall(tryHook)
    return hooked
end)

local POT_TEX   = "/Game/Models/Items/Food/Cooking/T_CookingPot.T_CookingPot"
local POT_SPEC  = "/Game/Models/Items/Food/Cooking/T_CookingPot_Spec.T_CookingPot_Spec"
local INHIB = "/Game/Models/Items/Deployable/M_Inhibitor_Exor_ON.M_Inhibitor_Exor_ON"
local PORTAL = "/Game/Models/Furniture/Crafting/CraftingBench/M_PortalSuppressionField_ON.M_PortalSuppressionField_ON"

local LOOKS = {
    { name = "Exor inhibitor", parent = INHIB, potTex = true, glowParam = "EmissiveIntensity", base = 1 },
    { name = "Exor veins", parent = INHIB, potTex = true, glowTex = "/Game/Models/Characters/NPCs/Exor/T_Exor_01_EM.T_Exor_01_EM", glowParam = "EmissiveIntensity", base = 1 },
    { name = "Exor goo", parent = INHIB, potTex = true, glowTex = "/Game/Models/Items/Misc/T_Goo_Exor_EM.T_Goo_Exor_EM", glowParam = "EmissiveIntensity", base = 1 },
    { name = "Exor heart flesh", parent = INHIB, potTex = true, glowTex = "/Game/Models/Characters/NPCs/Exor/T_ExorHeart_01.T_ExorHeart_01", glowParam = "EmissiveIntensity", base = 1 },
    { name = "Exor volatile", parent = INHIB, potTex = true, glowTex = "/Game/Models/Characters/NPCs/ExorVolatile/T_Exor_Volatile_03_Emissive.T_Exor_Volatile_03_Emissive", glowParam = "EmissiveIntensity", base = 1 },
    { name = "Portal field", parent = PORTAL, potTex = true, glowParam = "EmissiveIntensity", base = 10 },
    { name = "Plain cooking pot (off)", off = true },
}

local DENSITY = { 1, 2, 3, 4, 6, 8 }
local GLOWS = { 0.1, 0.25, 0.5, 1.0, 2.0 }

local look = { i = 5, g = 4, d = 4, p = 6, pg = 8, c = 4 }
local PGLOWS = { 0.5, 1, 2, 3, 5, 8, 12, 20 }

local PURPLES = {
    { name = "off" },
    { name = "vines", tex = "/Game/Models/Environment/Overgrowth/T_Vine_Overgrowth.T_Vine_Overgrowth" },
    { name = "void cracks", tex = "/Game/Prototypes/Boss/T_Boss_Void_Crack.T_Boss_Void_Crack" },

    { name = "glowing void cracks", tex = "/Game/Prototypes/Boss/T_Boss_Void_Crack.T_Boss_Void_Crack",
      glow = true },
    { name = "goo", tex = "/Game/Particles/Textures/T_Goo.T_Goo" },

    { name = "crisp glowing void cracks", tex = "/Game/Prototypes/Boss/T_Boss_Void_Crack.T_Boss_Void_Crack", crisp = true },
}
local MASKED = "/Game/Textures/M_AbioticMasked_Master.M_AbioticMasked_Master"

local GLOWMASK = "/Game/Models/Characters/NPCs/Peccary/M_Peccary_Mushrooms_PurpGlow.M_Peccary_Mushrooms_PurpGlow"
local SHELL_SCALE = 1.02
local SHELL_Z = -0.6
local lookMat, lookKey, lookErr = nil, nil, false
local function loadObj(path)
    local o = StaticFindObject(path)
    if not valid(o) then pcall(LoadAsset, path); o = StaticFindObject(path) end
    return valid(o) and o or nil
end

local MODDIR = "ue4ss/Mods/CookingRadius"
pcall(function() MODDIR = (debug.getinfo(1, "S").source:gsub("^@", ""):gsub("[/\\]Scripts[/\\][^/\\]+$", "")) end)
local QS = { matHolds = {}, mc = {}, cleaned = {}, handComps = {}, previews = {}, previewAt = -1, traceLeft = 0, curFP = false, fpOn = true }
local function ours(m)
    if not valid(m) then return false end
    local ok, n = pcall(function() return m:GetFName():ToString() end)
    return ok and n:find("CookingRadius_Quantum", 1, true) ~= nil
end
local function keep(mid)
    local ok, err = pcall(function()
        local h = construct("/Script/UMG.Image", FindFirstOf("GameInstance"), ROOTSET)
        h:SetBrushFromMaterial(mid)
        QS.matHolds[#QS.matHolds + 1] = h
    end)
    if not ok then log("could not hold material: %s", tostring(err)) end
end

local function fpKey(key)
    local fp = QS.fpOn and QS.curFP
    return key .. (fp and ":fp" or ""), fp
end
local function fpSet(mid, fp) if fp then mid:SetScalarParameterValue(FName("FirstPerson"), 1.0) end end
local BAKED_GLOW = 40
local function bakedTex(file)
    QS.baked = QS.baked or {}
    local t = QS.baked[file]
    if valid(t) then return t end
    local ok, r = pcall(function()
        return StaticFindObject("/Script/Engine.Default__KismetRenderingLibrary")
            :ImportFileAsTexture2D(FindFirstOf("GameInstance"), MODDIR .. "/" .. file)
    end)
    if ok and valid(r) then QS.baked[file] = r; return r end
    log("%s could not be loaded: %s", file, tostring(r))
    return nil
end
local function quantumMaterial()
    local L = LOOKS[look.i]
    if L.off then return nil end
    local key = look.i .. ":" .. look.g .. ":" .. look.d .. ":" .. look.p
    local fp
    key, fp = fpKey(key)
    if ours(QS.mc["l" .. key]) then return QS.mc["l" .. key] end
    local parent = loadObj(L.parent)
    if not parent then error("material not found: " .. L.parent) end
    local gi = FindFirstOf("GameInstance")
    local mid = StaticFindObject("/Script/Engine.Default__KismetMaterialLibrary")
        :CreateDynamicMaterialInstance(gi, parent, FName("CookingRadius_QuantumPot_" .. LOADTAG .. "_" .. key:gsub(":", "_")), 0)
    if not valid(mid) then error("could not create the material") end
    local tex, spec = loadObj(POT_TEX), loadObj(POT_SPEC)
    if L.potTex and tex then mid:SetTextureParameterValue(FName("Texture"), tex) end
    if L.glowTex then
        local gt = loadObj(L.glowTex)
        if gt then mid:SetTextureParameterValue(FName("EmissiveTexture"), gt) else log("glow texture not found: %s", L.glowTex) end
    end
    mid:SetScalarParameterValue(FName("EmissiveScale"), DENSITY[look.d])
    if spec then pcall(function() mid:SetTextureParameterValue(FName("Specular"), spec) end) end
    pcall(function() mid:SetScalarParameterValue(FName("Metallic"), 1.244) end)
    pcall(function() mid:SetScalarParameterValue(FName("Roughness"), 0.408) end)
    mid:SetScalarParameterValue(FName(L.glowParam), L.base * GLOWS[look.g])

    local bd, be = bakedTex("quantum_diffuse.png"), bakedTex("quantum_emissive.png")
    if bd and be then
        mid:SetTextureParameterValue(FName("Texture"), bd)
        mid:SetTextureParameterValue(FName("EmissiveTexture"), be)
        mid:SetScalarParameterValue(FName("EmissiveScale"), 1.0)
        mid:SetScalarParameterValue(FName("EmissiveIntensity"), BAKED_GLOW)
    end
    fpSet(mid, fp); keep(mid); QS.mc["l" .. key] = mid; lookMat, lookKey = mid, key
    return mid
end

local purpleMat, purpleKey, shellErr = nil, nil, false
local function purpleMaterial()
    local P = PURPLES[look.p]
    if not P.tex then return nil end
    local key = look.p .. ":" .. look.d .. ":" .. look.pg
    local fp
    key, fp = fpKey(key)
    if ours(QS.mc["p" .. key]) then return QS.mc["p" .. key] end
    local parent = loadObj(P.glow and GLOWMASK or MASKED)
    local tex = loadObj(P.tex)
    if not parent or not tex then error("purple material/texture not found") end
    local mid = StaticFindObject("/Script/Engine.Default__KismetMaterialLibrary")
        :CreateDynamicMaterialInstance(FindFirstOf("GameInstance"), parent, FName("CookingRadius_QuantumPurple_" .. LOADTAG .. "_" .. key:gsub(":", "_")), 0)
    mid:SetTextureParameterValue(FName("Texture"), tex)
    if P.glow then
        mid:SetTextureParameterValue(FName("MaskedTexture"), tex)

        local white = loadObj("/Game/Models/Environment/Walls/T_ABF_WhiteGeneric.T_ABF_WhiteGeneric")
        mid:SetTextureParameterValue(FName("EmissiveTexture"), white or tex)
        if not white then log("white texture not found") end
        pcall(function() mid:SetVectorParameterValue(FName("Color"), { R = 0.6, G = 0.1, B = 1.0, A = 1.0 }) end)
        pcall(function() mid:SetVectorParameterValue(FName("EmissiveColor"), { R = 0.83, G = 0.0, B = 5.0, A = 1.0 }) end)
        mid:SetScalarParameterValue(FName("EmissiveIntensity"), PGLOWS[look.pg])
        pcall(function() mid:SetScalarParameterValue(FName("EmissiveMultiplier"), 1.0) end)

        local par = "?"
        pcall(function() par = mid.Parent:GetFName():ToString() end)
        fpSet(mid, fp); keep(mid); QS.mc["p" .. key] = mid; purpleMat, purpleKey = mid, key
        return mid
    end
    if P.crisp then
        local white = loadObj("/Game/Models/Environment/Walls/T_ABF_WhiteGeneric.T_ABF_WhiteGeneric")
        mid:SetTextureParameterValue(FName("EmissiveTexture"), white or tex)
        pcall(function() mid:SetVectorParameterValue(FName("DiffuseColor"), { R = 0.6, G = 0.05, B = 1.4, A = 1.0 }) end)
        mid:SetScalarParameterValue(FName("EmissiveIntensity"), PGLOWS[look.pg])
        pcall(function() mid:SetScalarParameterValue(FName("Scale"), 1.0) end)
        fpSet(mid, fp); keep(mid); QS.mc["p" .. key] = mid; purpleMat, purpleKey = mid, key
        return mid
    end
    pcall(function() mid:SetTextureParameterValue(FName("EmissiveTexture"), tex) end)
    pcall(function() mid:SetVectorParameterValue(FName("DiffuseColor"), { R = 0.6, G = 0.05, B = 1.4, A = 1.0 }) end)
    pcall(function() mid:SetScalarParameterValue(FName("DiffuseIntensity"), 1.5) end)
    pcall(function() mid:SetScalarParameterValue(FName("EmissiveIntensity"), 0.6) end)
    pcall(function() mid:SetScalarParameterValue(FName("Scale"), DENSITY[look.d]) end)
    pcall(function() mid:SetScalarParameterValue(FName("Opacity"), 1.0) end)
    fpSet(mid, fp); keep(mid); QS.mc["p" .. key] = mid; purpleMat, purpleKey = mid, key
    return mid
end

local CORES = { 0, 0.7, 0.5, 0.35, 0.25 }
local coreMat, coreKey = nil, nil
local CORE_BOOST = 10
local function coreMaterial()
    local o = CORES[look.c]
    if o == 0 then return nil end
    local key = look.pg .. ":" .. look.c
    local fp
    key, fp = fpKey(key)
    if ours(QS.mc["c" .. key]) then return QS.mc["c" .. key] end
    local mid = StaticFindObject("/Script/Engine.Default__KismetMaterialLibrary")
        :CreateDynamicMaterialInstance(FindFirstOf("GameInstance"), loadObj(MASKED), FName("CookingRadius_QuantumPurple_core_" .. LOADTAG .. "_" .. key:gsub("[:.]", "_")), 0)
    mid:SetTextureParameterValue(FName("Texture"), loadObj(PURPLES[6].tex))
    mid:SetTextureParameterValue(FName("EmissiveTexture"), loadObj("/Game/Models/Environment/Walls/T_ABF_WhiteGeneric.T_ABF_WhiteGeneric"))

    pcall(function() mid:SetVectorParameterValue(FName("DiffuseColor"), { R = 0.45, G = 0.0, B = 1.0, A = 1.0 }) end)
    mid:SetScalarParameterValue(FName("EmissiveIntensity"), PGLOWS[look.pg] * CORE_BOOST)
    pcall(function() mid:SetScalarParameterValue(FName("Scale"), 1.0) end)
    pcall(function() mid:SetScalarParameterValue(FName("Opacity"), o) end)
    fpSet(mid, fp); keep(mid); QS.mc["c" .. key] = mid; coreMat, coreKey = mid, key
    return mid
end

local shells = {}
local SMC_CLASS = "/Script/Engine.StaticMeshComponent"

local CRACKS = 5

local function isSMC(o)
    if not valid(o) then return false end
    if not valid(QS.smcClass) then QS.smcClass = StaticFindObject(SMC_CLASS) end
    local ok, r = pcall(function() return o:IsA(QS.smcClass) end)
    return ok and r == true
end
local function removeStrayShells(c, keep)
    local kids = c.AttachChildren
    for i = #kids, 1, -1 do
        local k = kids[i]
        if not keep[addr(k)] and isSMC(k) then
            local okm, m = pcall(function() return k:GetMaterial(0) end)
            if okm and valid(m) and m:GetFName():ToString():find("CookingRadius_QuantumPurple", 1, true) then
                k:K2_DestroyComponent(k)
            end
        end
    end
end
local function setShell(c, on)
    local a = addr(c)

    local list = {}
    for _, sh in ipairs(shells[a] or {}) do
        local okp, par = pcall(function() return sh.AttachParent end)
        if isSMC(sh) and okp and addr(par) == a then list[#list + 1] = sh end
    end
    shells[a] = list
    local mat = on and purpleMaterial() or nil
    local n = mat and ((PURPLES[look.p].glow or PURPLES[look.p].crisp) and CRACKS or 1) or 0
    local core = mat and PURPLES[look.p].crisp and coreMaterial() or nil
    if core then n = CRACKS * 2 end

    for i = #list, n + 1, -1 do
        local sh = list[i]
        pcall(function() if valid(sh) then sh:K2_DestroyComponent(sh) end end)
        list[i] = nil
    end
    local keep = {}
    for i = 1, #list do keep[addr(list[i])] = true end
    pcall(removeStrayShells, c, keep)
    if n == 0 then shells[a] = nil; return end
    for i = 1, n do
        local sh = list[i]
        if not valid(sh) then
            local owner = c:GetOwner()
            sh = owner:AddComponentByClass(StaticFindObject(SMC_CLASS), true,
                { Rotation = { X = 0, Y = 0, Z = 0, W = 1 }, Translation = { X = 0, Y = 0, Z = 0 }, Scale3D = { X = 1, Y = 1, Z = 1 } }, false)
            if not valid(sh) then error("could not add the purple shell") end
            sh:K2_AttachToComponent(c, FName("None"), 2, 2, 2, false)

            pcall(function() sh:SetCollisionEnabled(0) end)
            pcall(function() sh:SetCastShadow(false) end)
            list[i] = sh
        end

        local k = core and i > CRACKS and i - CRACKS or i
        local sc = SHELL_SCALE + (k - 1) * 0.002 + (k ~= i and 0.001 or 0)
        sh:SetRelativeScale3D({ X = sc, Y = sc, Z = 1.0 })
        sh:K2_SetRelativeLocation({ X = 0, Y = 0, Z = SHELL_Z }, false, {}, false)
        local m = core and CRACKS or n
        sh:K2_SetRelativeRotation({ Pitch = 0, Yaw = (k - 1) * (360 / m) + 17 * (k - 1), Roll = 0 }, false, {}, false)
        local want = (k ~= i) and core or mat
        if addr(sh.StaticMesh) ~= addr(c.StaticMesh) then sh:SetStaticMesh(c.StaticMesh) end
        if addr(sh:GetMaterial(0)) ~= addr(want) then sh:SetMaterial(0, want) end
        pcall(function() sh:SetVisibility(c:IsVisible(), false) end)

        pcall(function()
            if sh.bOnlyOwnerSee ~= c.bOnlyOwnerSee then sh:SetOnlyOwnerSee(c.bOnlyOwnerSee) end
            if sh.bOwnerNoSee ~= c.bOwnerNoSee then sh:SetOwnerNoSee(c.bOwnerNoSee) end
            if sh.bHiddenInGame ~= c.bHiddenInGame then sh:SetHiddenInGame(c.bHiddenInGame, false) end
        end)
    end
    shells[a] = list
end

local MESH_PROPS = { "PanMesh", "World_StaticMesh", "WorldMesh", "StaticMesh" }
local function isPotMesh(c)
    local m = c.StaticMesh
    local n = valid(m) and m:GetFName():ToString() or ""
    return n:find("^SM_CookingPot") ~= nil and not n:find("Liquid", 1, true)
end
local function skinComp(c, on, mat)
    if not isSMC(c) then return end
    if not isPotMesh(c) then

        if shells[addr(c)] then pcall(setShell, c, false) end
        pcall(function()
            local cur = c:GetMaterial(0)
            if valid(cur) and cur:GetFName():ToString():find("CookingRadius_QuantumPot", 1, true) then c:EmptyOverrideMaterials() end
        end)
        return
    end
    if mat and QS.fpOn and QS.curFP then mat = quantumMaterial() end
    local cur = c:GetMaterial(0)
    if on and mat then
        if addr(cur) ~= addr(mat) then c:SetMaterial(0, mat) end
    elseif valid(cur) and cur:GetFName():ToString():find("CookingRadius_QuantumPot", 1, true) then
        c:SetMaterial(0, c.StaticMesh:GetMaterial(0))
    end

    if not QS.cleaned[addr(c)] then
        QS.cleaned[addr(c)] = true
        local ok, err = pcall(setShell, c, false)
        if not ok and not shellErr then shellErr = true; log("old shell cleanup: %s", tostring(err)) end
    end
end
local function skin(actor, on, mat)
    for _, prop in ipairs(MESH_PROPS) do
        local ok, c = pcall(function() return actor[prop] end)
        if ok and valid(c) then skinComp(c, on, mat) end
    end
end
local function itemIsQuantum(a)
    if qRow(a.ItemDataRow) == QROW then return true end
    local props = a.ChangeableData.DynamicProperties
    for i = 1, #props do
        if props[i].Key == 22 then return props[i].Value == QINDEX end
    end
    return false
end

local fastProxies, fastPlayers, fastAt = {}, {}, -1
skinProxyNow = function(pr)
    if not valid(pr) then return end
    local a = addr(pr)
    local found = false
    for _, p in ipairs(fastProxies) do if addr(p) == a then found = true end end
    if not found then fastProxies[#fastProxies + 1] = pr end
    if quantumRows then skin(pr, isQuantumPot(pr), quantumMaterial()) end
end
local heldLogged, heldErr = nil, false

local function skinHands(pl, mat)
    if not valid(pl) then return end
    local a = pl.ItemInHand_BP
    local q = false
    if valid(a) then
        local okq, r = pcall(itemIsQuantum, a)
        q = okq and r == true
    end
    if q and heldLogged ~= addr(a) then heldLogged = addr(a) end
    for _, prop in ipairs({ "CurrentFPItemMesh", "TP_ItemInHand" }) do
        local okc, c = pcall(function() return pl[prop] end)

        local key = addr(pl) .. prop
        local old = QS.handComps[key]
        if old and addr(old) ~= addr(c) then
            QS.handComps[key] = nil
            QS.curFP = prop == "CurrentFPItemMesh"
            if valid(old) then pcall(skinComp, old, false, mat) end
            QS.curFP = false
        end
        if okc and valid(c) then
            QS.handComps[key] = c
            QS.curFP = prop == "CurrentFPItemMesh"
            local ok, err = pcall(skinComp, c, q, mat)
            QS.curFP = false
            if not ok and not heldErr then heldErr = true; log("held Quantum Pot look: %s", tostring(err)) end
        end
    end
end
local function skinFast()
    if not quantumRows then return end
    if os.clock() - fastAt > 2 or fastAt < 0 then
        fastAt = os.clock()
        fastProxies = FindAllOf("CookingProxy_BP_C") or {}
        fastPlayers = FindAllOf("Abiotic_PlayerCharacter_C") or {}
        QS.proxyAt = os.clock()
    elseif os.clock() - (QS.proxyAt or 0) > 0.25 then

        local inWorld = false
        for _, pl in ipairs(fastPlayers) do if valid(pl) then inWorld = true end end
        if inWorld then
            QS.proxyAt = os.clock()
            fastProxies = FindAllOf("CookingProxy_BP_C") or {}
        end
    end
    local mat = quantumMaterial()
    if not QS.fpReady then QS.fpReady = true; QS.curFP = true; pcall(quantumMaterial); QS.curFP = false end
    for _, pr in ipairs(fastProxies) do
        if valid(pr) then skin(pr, isQuantumPot(pr), mat) end
    end
    for _, pl in ipairs(fastPlayers) do skinHands(pl, mat) end
end

local okm, em = pcall(RegisterHook, "/Script/Engine.StaticMeshComponent:SetStaticMesh", function() end, function(ctx)
    if not quantumRows then return end
    pcall(function()
        local c = ctx:get()
        if not (valid(c) and isPotMesh(c)) then return end
        local owner = c:GetOuter()
        if not valid(owner) then return end
        local cn = owner:GetClass():GetFName():ToString()
        if cn == "CookingProxy_BP_C" then
            skinProxyNow(owner)
        elseif cn == "Abiotic_PlayerCharacter_C" then
            skinHands(owner, quantumMaterial())
        end
    end)
end)
if not okm then log("hook SetStaticMesh failed: %s", tostring(em)) end
gtLoop(100, function()
    local ok, err = pcall(skinFast)
    if not ok and not lookErr then lookErr = true; log("Quantum Pot look (fast): %s", tostring(err)) end
    return false
end)
local function skinAll()
    if not quantumRows then return end
    local mat = quantumMaterial()
    for _, cn in ipairs({ "Abiotic_Item_ParentBP_C", "Abiotic_Item_Dropped_C" }) do
        for _, a in ipairs(FindAllOf(cn) or {}) do
            if valid(a) then
                local okq, q = pcall(itemIsQuantum, a)
                skin(a, okq and q, mat)
            end
        end
    end
end

local lastPreview = nil
local function skinPreview()
    if not quantumRows then return end
    local mat = quantumMaterial()
    if os.clock() - QS.previewAt > 2 or QS.previewAt < 0 then
        QS.previewAt = os.clock()
        QS.previews = FindAllOf("3D_ItemDisplay_BP_C") or {}
    end
    for _, a in ipairs(QS.previews) do
        if valid(a) then
            local r = qRow(a.CosmeticRow)
            if r ~= lastPreview then
                lastPreview = r
                local m = ""
                pcall(function() m = a.StaticMesh.StaticMesh:GetFName():ToString() end)
            end
            skin(a, r == QROW, mat)
        end
    end
end

local function clearPreview(a)
    local c = a.StaticMesh
    if not valid(c) then return end
    pcall(setShell, c, false)
    local cur = c:GetMaterial(0)
    if valid(cur) and cur:GetFName():ToString():find("CookingRadius_QuantumPot", 1, true) then pcall(function() c:EmptyOverrideMaterials() end) end
end
local previewHooked = false
gtLoop(1000, function()
    if previewHooked then return true end
    local inst = FindFirstOf("3D_ItemDisplay_BP_C")
    if not valid(inst) then return false end
    previewHooked = true
    local cls = inst:GetClass():GetFullName():gsub("^%S+%s+", "")
    local ok, err = pcall(RegisterHook, cls .. ":Set3DPreviewMesh", function(ctx)
        local ok2, e2 = pcall(clearPreview, ctx:get())
        if not ok2 then log("preview clear: %s", tostring(e2)) end
    end)
    if not ok then log("hook Set3DPreviewMesh failed: %s", tostring(err)) end
    return true
end)
gtLoop(200, function()
    local ok, err = pcall(skinPreview)
    if not ok and not lookErr then lookErr = true; log("Quantum Pot preview look: %s", tostring(err)) end
    return false
end)
gtLoop(1000, function()
    local ok, err = pcall(skinAll)
    if not ok and not lookErr then lookErr = true; log("Quantum Pot look: %s", tostring(err)) end
    return false
end)

local iconTex, iconHold, iconErr = nil, nil, false
local function quantumIcon()
    if valid(iconTex) then return iconTex end
    local krl = StaticFindObject("/Script/Engine.Default__KismetRenderingLibrary")
    local t = krl:ImportFileAsTexture2D(FindFirstOf("GameInstance"), MODDIR .. "/quantum_icon.png")
    if not valid(t) then error("quantum_icon.png not loaded from " .. MODDIR) end

    iconHold = construct("/Script/UMG.Image", FindFirstOf("GameInstance"), ROOTSET)
    iconHold:SetBrushFromTexture(t, false)
    iconTex = t
    return t
end
local iconSlots, iconScanAt, iconPopups = {}, -1, {}
QS.iconNew = {}
local function iconOn(w, tex)
    local ok, r = pcall(function()
        if not w:GetClass():GetFName():ToString():find("W_InventoryItemSlot", 1, true) then return nil end
        return w.ItemInSlot.ItemDataTable.RowName:ToString()
    end)
    if not (ok and r == QROW) then return false end
    local img = w.Icon
    if not valid(img) then return true end

    local res = img.Brush.ResourceObject
    if addr(res) == addr(tex) or not valid(res) then

        local base = loadObj("/Game/Textures/GUI/M_IconImage.M_IconImage")
        if base then img:SetBrushFromMaterial(base) end
    end
    local m = img:GetDynamicMaterial()
    if valid(m) then m:SetTextureParameterValue(FName("IconImage"), tex) end
    return true
end

local function skinIcons()
    if not quantumRows then return end
    local tex = quantumIcon()
    if os.clock() - iconScanAt > 3 or iconScanAt < 0 then
        iconScanAt = os.clock()
        for _, w in ipairs(FindAllOf("W_InventoryItemSlot_C") or {}) do
            if valid(w) and iconOn(w, tex) then iconSlots[addr(w)] = w end
        end
    end
    for k, w in pairs(iconSlots) do
        if not (valid(w) and iconOn(w, tex)) then iconSlots[k] = nil end
    end
    for k, e in pairs(QS.iconNew) do
        local w = e[1]
        if not valid(w) or os.clock() - e[2] > 5 then QS.iconNew[k] = nil
        elseif iconOn(w, tex) then iconSlots[k] = w; QS.iconNew[k] = nil end
    end
    for k, e in pairs(iconPopups) do
        local w = e[1]
        if not valid(w) or os.clock() - e[2] > 6 then iconPopups[k] = nil
        elseif w.ItemRowName:ToString() == QROW then
            local m = w.Icon:GetDynamicMaterial()
            if valid(m) then m:SetTextureParameterValue(FName("IconImage"), tex) end
        end
    end
end

NotifyOnNewObject("/Game/Blueprints/Widgets/W_HUD_ItemPickupNotify.W_HUD_ItemPickupNotify_C", function(w)
    iconPopups[addr(w)] = { w, os.clock() }
end)

NotifyOnNewObject("/Game/Blueprints/Widgets/Inventory/W_InventoryItemSlot.W_InventoryItemSlot_C", function(w)
    QS.iconNew[addr(w)] = { w, os.clock() }
end)
gtLoop(150, function()
    local ok, err = pcall(skinIcons)
    if not ok and not iconErr then iconErr = true; log("Quantum Pot icon: %s", tostring(err)) end
    return false
end)

gtLoop(2000, function()
    if not hooked then return false end
    local okh, eh = pcall(RegisterHook, "/Game/Blueprints/Widgets/Inventory/W_InventoryItemSlot.W_InventoryItemSlot_C:UpdateSlot_UI", function() end, function(ctx)
        pcall(function()
            local w = ctx:get()
            if quantumRows and valid(w) and iconOn(w, quantumIcon()) then iconSlots[addr(w)] = w end
        end)
    end)
    if not okh then log("hook UpdateSlot_UI failed: %s", tostring(eh)) end
    return true
end)

log("loaded (radius %d m)", settings.radius)
