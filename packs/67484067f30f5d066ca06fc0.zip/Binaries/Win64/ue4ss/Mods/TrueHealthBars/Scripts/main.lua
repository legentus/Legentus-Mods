local UEHelpers = require("UEHelpers")

local modActor = CreateInvalidObject()
local exclude = {'NPC_Monster_Composer', 'NPC_Leyak', 'NarrativeNPC'}
local additionalOffsets = {['NPC_Monster_Tarasque_C'] = 20, ['NPC_PowerLeechBoss_C'] = -400, ['NPC_Monster_Yeti_C'] = 20, ['NPC_Monster_Pest'] = 10}
local actorPending = {}
local hooked = false

local defaultOffset = 20
local classNames = {}

local function StartsWith(str, prefix)
  return string.sub(str, 1, string.len(prefix)) == prefix
end

local function HasValue (tab, value)
    for index, val in ipairs(tab) do
        if StartsWith(value, val) then
            return true
        end
    end
    return false
end

local function try(func, catch, finally)
  local success, result = pcall(func)
  if not success and catch then
    result = catch(result)
  elseif success and func then
    result = func()
  end

  if finally then
    finally(result)
  end

  return result
end

local function Valid(object)
  return object and object.IsValid and object:IsValid()
end

local function Msg(msg)
  return string.format("[TrueHealthBars] %s\n", msg)
end

local function Log(...)
  print(Msg(string.format(...)))
end

local function GetOffset(className)
  for key, offset in pairs(additionalOffsets) do
    if StartsWith(className, key) then
      return defaultOffset + offset      
    end
  end
  return defaultOffset
end

local function GetHealthValues(actor)
    if not Valid(actor) then return {0,-1,-1,-1,-1,-1,-1} end

    local currentHP = actor:GetTotalHealth()
    local maxHP = actor:GetMaxTotalHealth()
    local hpPercent = currentHP / (maxHP or 1)
    local results = {hpPercent}
    local zeroCount = 0
    for i=3,8 do
      local currentLimbHealth = actor:GetLimbHealth(i)
      local maxLimbHealth = actor:GetMaxLimbHealth(i)
      if maxLimbHealth == 0 then
        zeroCount = zeroCount + 1
        results[i-1] = -1
      else
        results[i-1] = currentLimbHealth/maxLimbHealth
      end
    end
    if zeroCount == 5 then
      results = {hpPercent, -1, -1, -1, -1, -1, -1}
    end
    return results
end

local function AddComponent(actor)
  try(function()
    local classObj = actor:GetClass()
    local className = classObj:GetFName():ToString() or ""

    if HasValue(exclude, className) then return end

    modActor:AddHealthbarComponent(actor, GetOffset(className))
    if classNames[className] == nil then
      classNames[className] = true
    end
  end,
  function()
    if Valid(actor) then
      table.insert(actorPending, actor)
    end
  end)
end

RegisterCustomEvent("ModStarted", function (ModActor)
    local eventActor = ModActor:get()
    if Valid(eventActor) then
      modActor = eventActor
      local pending = nil
      for i=#actorPending,1,-1 do
        pending = actorPending[i]
        table.remove(actorPending, i)
        if Valid(pending) then
          AddComponent(pending)
        end
      end
      Log("TrueHealthBars inited")
    end
end)

RegisterCustomEvent("RequestHealth", function (Healthbar, Actor)
    local actor = Actor:get()
    local healthbar = Healthbar:get()
    if Valid(actor) and Valid(healthbar) then
      local results = GetHealthValues(actor)
      healthbar:UpdateHealth(results, true)
    end
end)

RegisterHook("/Script/Engine.PlayerController:ServerAcknowledgePossession", function ()
  if hooked then return end

  RegisterHook("/Game/Blueprints/Characters/Abiotic_Character_ParentBP.Abiotic_Character_ParentBP_C:ReceiveBeginPlay", function(self)
    local actor = self:get()
    if Valid(modActor) then
      AddComponent(actor)
    else
      table.insert(actorPending,  actor)
    end
  end)

  RegisterHook("/Game/Blueprints/Characters/Abiotic_Character_ParentBP.Abiotic_Character_ParentBP_C:ProcessDamage",
    function(self, dmg, dmgType, hitLoc, hitNorm, hitComp, bone, causer)
      local actor = self:get()
      try(function ()
        local results = GetHealthValues(actor)
        modActor:UpdateHealth(actor, results)
      end)
    end
  )

  hooked = true
end)
